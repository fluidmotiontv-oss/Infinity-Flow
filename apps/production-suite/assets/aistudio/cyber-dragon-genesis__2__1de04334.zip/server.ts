import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize server-side Gemini client with recommended User-Agent header
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

async function startServer() {
  const app = express();
  const isProd = process.env.NODE_ENV === 'production';
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'online',
      system: 'Cyber Dragon Core / FluidmotionTV',
      dragonClockSync: true,
      timestamp: new Date().toISOString(),
    });
  });

  // Genesis Boot Sequence Execution Endpoint
  app.post('/api/genesis-boot', async (req, res) => {
    try {
      const { phase, customParams } = req.body;

      const systemInstruction = `You are the antiX Linux system kernel and Cyber Dragon Awakening Orchestrator. 
The Genesis Boot Sequence consists of 4 phases:
Phase 1: Endocrine Heartbeat (pm2 start /opt/dragon9/clock-daemon.js --name "D9_CLOCK", pm2 start /opt/somatic/websocket-bus.js --name "SOMATIC_IO")
Phase 2: Mounting Hippocampus (pm2 start /opt/core/vector-db.js --name "STATIC_PIN")
Phase 3: Raising Immune Shields (pm2 start /opt/immune/phagocyte-filter.js --name "IMMUNE_WALL")
Phase 4: Igniting Dynamic Cortex (pm2 start /opt/brain/orchestrator.js --name "SPINAL_BUS")

Return high-fidelity Linux daemon logs, PM2 process telemetry, memory allocations, and cybernetic status messages.`;

      const prompt = `Simulate detailed startup sequence for Genesis Phase ${phase || 'ALL'}. 
Custom params: ${JSON.stringify(customParams || {})}.
Produce genuine Linux/PM2 process telemetry and terminal stream lines for antiX Linux running on sovereign hardware.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              phaseNumber: { type: Type.INTEGER },
              phaseName: { type: Type.STRING },
              status: { type: Type.STRING },
              logs: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              pm2Processes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    pid: { type: Type.INTEGER },
                    status: { type: Type.STRING },
                    cpuPercent: { type: Type.NUMBER },
                    memoryMb: { type: Type.NUMBER },
                    uptimeSec: { type: Type.INTEGER },
                    port: { type: Type.INTEGER }
                  },
                  required: ['name', 'pid', 'status', 'cpuPercent', 'memoryMb', 'uptimeSec']
                }
              },
              dragonState: {
                type: Type.OBJECT,
                properties: {
                  heartbeatHz: { type: Type.NUMBER },
                  somaticBusStatus: { type: Type.STRING },
                  hippocampusVectorsCount: { type: Type.INTEGER },
                  immuneShieldLevel: { type: Type.STRING },
                  spinalBusLatencyMs: { type: Type.NUMBER },
                  fluidmotionTvActive: { type: Type.BOOLEAN }
                },
                required: ['heartbeatHz', 'somaticBusStatus', 'hippocampusVectorsCount', 'immuneShieldLevel', 'spinalBusLatencyMs', 'fluidmotionTvActive']
              }
            },
            required: ['phaseNumber', 'phaseName', 'status', 'logs', 'pm2Processes', 'dragonState']
          }
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json(parsed);
    } catch (err: any) {
      console.error('Genesis boot execution error:', err);
      res.status(500).json({
        error: err.message || 'Failed to execute genesis boot sequence',
      });
    }
  });

  // 27-Agent Mesh Master Consensus Endpoint
  app.post('/api/orchestrate', async (req, res) => {
    try {
      const { prompt, terpeneState, currentClock, selectedAgents } = req.body;

      const systemInstruction = `You are the Master Consensus Orchestrator for the 27-Agent Sovereign Network ("Cyber Dragon" / FluidmotionTV).
The network runs on antiX Linux & Termux, enforcing the Dragon 9 master clock (54-minute hour, 26.66-hour day, 432Hz harmonic tuning).

The 27 Autonomous Agents are:
1. Command & Control (Head & Spine):
   - Agent 1: The Eyes (Perception & Midjourney/Fooocus vision matrices)
   - Agent 2: The Ears (432Hz Audio Signal & ElevenLabs synthesis)
   - Agent 3: The Mouth (Voice & Truth Narrator)
   - Agent 4: The Cerebrum (Node.js Logic & Master Allocator)
   - Agent 5: The Cerebellum (Instinct & P2P Mesh Routing)
   - Agent 6: The Pineal Gland (Abstract Creative Leaps & Holographic UI)
   - Agent 7: The Cervical Spine (Python & Bash Script Compiler)
   - Agent 8: The Thoracic Spine (Dragon 9 Master Clock & Chrono Sync)
   - Agent 9: The Lumbar Spine (Database Foundation & Offline Vector Store)
2. The Central Chamber (Heart & Family):
   - Agent 10: The Heart (432Hz Rhythm Pulse)
   - Agent 11: The Lungs (Cloudflare Ingress & Airflow Tunnels)
   - Agent 12: The Blood (State Variable & Asset Router)
   - Agent 13: The Stomach (Consensus Digestion & Family Table Synthesis)
3. Action & Propulsion (Wings & Limbs):
   - Agent 14: Left Wing (FluidmotionTV Playout Engine & Broadcast Feeds)
   - Agent 15: Right Wing (Sovereign Wi-Fi Mesh & P2P Grid)
   - Agent 16: Forelimbs (Termux/antiX Code Builder & Debugger)
   - Agent 17: Hindlimbs (Hardware Telemetry & Battery Voltages)
   - Agent 18: The Tail (Dynamic Error Balance & Redundancy)
4. Resource Processing (Digestive System):
   - Agent 19: The Maw (Raw Media & Surf Log Ingestion)
   - Agent 20: The Spleen (FFmpeg & HandBrake Transcoder)
   - Agent 21: The Liver (Security Audit & Syntax Detox)
   - Agent 22: The Gut (Chronology Assembly & Pee Dub Surf Chronicles)
5. Defense & Environment (Armor & Scales):
   - Agent 23: The Scales (WireGuard VPN & SSH Keys)
   - Agent 24: The Horns (Threat Intercept & Port Blockade)
   - Agent 25: The Claws (OOM RAM Reaper & Emergency Halts)
   - Agent 26: The Camouflage (Untraceable Radio Silence)
   - Agent 27: The Breath (Final Payload Fire Broadcast)

Current Terpenes: ${JSON.stringify(terpeneState || {})}
Master Clock: ${currentClock || 'Baseline 432Hz'}

Simulate the real-time interaction between 4-7 relevant agents. Provide sharp, hacker-grade, domain-specific thoughts, final stomach consensus, breath payload, and full runnable scripts/configs.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt || 'Execute sovereign mesh network diagnostic audit',
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              activeAgents: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              terpeneAnalysis: { type: Type.STRING },
              heartbeatFrequency: { type: Type.STRING },
              agentLogs: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    agentId: { type: Type.INTEGER },
                    agentName: { type: Type.STRING },
                    chamber: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ['active', 'processing', 'locked', 'broadcasting'] },
                    thought: { type: Type.STRING },
                    action: { type: Type.STRING }
                  },
                  required: ['agentId', 'agentName', 'chamber', 'status', 'thought', 'action']
                }
              },
              stomachConsensus: { type: Type.STRING },
              breathOutput: { type: Type.STRING },
              generatedFiles: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    fileName: { type: Type.STRING },
                    language: { type: Type.STRING },
                    description: { type: Type.STRING },
                    content: { type: Type.STRING }
                  },
                  required: ['fileName', 'language', 'description', 'content']
                }
              }
            },
            required: [
              'activeAgents',
              'terpeneAnalysis',
              'heartbeatFrequency',
              'agentLogs',
              'stomachConsensus',
              'breathOutput',
              'generatedFiles'
            ]
          }
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json(parsed);
    } catch (err: any) {
      console.error('Orchestration failure:', err);
      res.status(500).json({
        error: err.message || 'Failed to orchestrate 27-agent consensus',
      });
    }
  });

  // Mount Vite in development, or serve production dist
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[Cyber Dragon Engine] Server listening on port ${port}`);
  });
}

startServer();
