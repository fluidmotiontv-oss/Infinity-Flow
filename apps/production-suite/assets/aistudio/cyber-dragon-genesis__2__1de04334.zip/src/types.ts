export type ChamberType =
  | 'Command & Control'
  | 'The Central Chamber'
  | 'Action & Propulsion'
  | 'Resource Processing'
  | 'Defense & Environment';

export interface AgentInfo {
  id: number;
  name: string;
  codename: string;
  chamber: ChamberType;
  role: string;
  subsystem: string;
  description: string;
  metricLabel: string;
  metricUnit: string;
  baseMetric: number;
  terminalCommand: string;
  color: string;
}

export interface TerpeneState {
  myrcene: number; // Heavy focus / transcode / compute
  limonene: number; // Fast logical loops / routing
  linalool: number; // Ambient creative drift / pineal holograms
  pinene: number; // Alertness / packet inspection
  caryophyllene: number; // Stress relief / RAM load-balancing
}

export interface PM2Process {
  name: string;
  pid: number;
  status: 'online' | 'starting' | 'stopped' | 'errored';
  cpuPercent: number;
  memoryMb: number;
  uptimeSec: number;
  port?: number;
  description: string;
}

export interface GenesisPhase {
  phase: number;
  name: string;
  command: string;
  serviceName: string;
  description: string;
  durationMs: number;
  status: 'pending' | 'running' | 'completed' | 'error';
  logs: string[];
}

export interface GeneratedFile {
  fileName: string;
  language: string;
  description: string;
  content: string;
}

export interface AgentLog {
  agentId: number;
  agentName: string;
  chamber: string;
  status: 'active' | 'processing' | 'locked' | 'broadcasting';
  thought: string;
  action: string;
}

export interface OrchestrationResult {
  activeAgents: string[];
  terpeneAnalysis: string;
  heartbeatFrequency: string;
  agentLogs: AgentLog[];
  stomachConsensus: string;
  breathOutput: string;
  generatedFiles: GeneratedFile[];
}
