import React, { useState } from 'react';
import { GenesisPhase, PM2Process } from '../types';
import { soundFx } from '../utils/audioSynth';
import { Play, RotateCcw, CheckCircle2, AlertTriangle, Terminal, Cpu, HardDrive, ShieldCheck, Zap, Activity } from 'lucide-react';

interface Props {
  onBootComplete: () => void;
  onAddLog: (msg: string) => void;
}

const INITIAL_PHASES: GenesisPhase[] = [
  {
    phase: 1,
    name: 'Endocrine Heartbeat',
    command: 'pm2 start /opt/dragon9/clock-daemon.js --name "D9_CLOCK"\npm2 start /opt/somatic/websocket-bus.js --name "SOMATIC_IO"',
    serviceName: 'D9_CLOCK & SOMATIC_IO',
    description: 'Mounting 54-minute hour master clock daemon and low-latency somatic WebSocket event bus.',
    durationMs: 3000,
    status: 'pending',
    logs: [],
  },
  {
    phase: 2,
    name: 'Mounting Hippocampus',
    command: 'pm2 start /opt/core/vector-db.js --name "STATIC_PIN"',
    serviceName: 'STATIC_PIN',
    description: 'Loading high-dimensional vector embeddings, sovereign chronicles, and persistent episodic memory.',
    durationMs: 3000,
    status: 'pending',
    logs: [],
  },
  {
    phase: 3,
    name: 'Raising Immune Shields',
    command: 'pm2 start /opt/immune/phagocyte-filter.js --name "IMMUNE_WALL"',
    serviceName: 'IMMUNE_WALL',
    description: 'Initializing phagocyte packet inspection, WireGuard VPN tunneling, and untraceable MAC camouflage.',
    durationMs: 2000,
    status: 'pending',
    logs: [],
  },
  {
    phase: 4,
    name: 'Igniting Dynamic Cortex',
    command: 'pm2 start /opt/brain/orchestrator.js --name "SPINAL_BUS"',
    serviceName: 'SPINAL_BUS',
    description: 'Spawning the 27-Agent master consensus orchestrator and activating the FluidmotionTV playout core.',
    durationMs: 2500,
    status: 'pending',
    logs: [],
  },
];

const INITIAL_PM2: PM2Process[] = [
  { name: 'D9_CLOCK', pid: 1042, status: 'online', cpuPercent: 0.4, memoryMb: 24.2, uptimeSec: 3600, port: 4320, description: 'Dragon 9 Master Chronometer Daemon' },
  { name: 'SOMATIC_IO', pid: 1043, status: 'online', cpuPercent: 1.1, memoryMb: 38.6, uptimeSec: 3600, port: 8080, description: 'Somatic WebSocket Mesh Bus' },
  { name: 'STATIC_PIN', pid: 1089, status: 'online', cpuPercent: 0.8, memoryMb: 72.4, uptimeSec: 3590, port: 6379, description: 'Hippocampus Vector Store' },
  { name: 'IMMUNE_WALL', pid: 1114, status: 'online', cpuPercent: 1.5, memoryMb: 42.1, uptimeSec: 3580, port: 51820, description: 'Phagocyte Filter & WireGuard Armor' },
  { name: 'SPINAL_BUS', pid: 1142, status: 'online', cpuPercent: 2.8, memoryMb: 86.5, uptimeSec: 3570, port: 3000, description: '27-Agent Cortex Orchestrator' },
  { name: 'FLUIDMOTION_TV', pid: 1205, status: 'online', cpuPercent: 4.2, memoryMb: 128.0, uptimeSec: 3560, port: 8000, description: '60fps Media Playout Core' },
];

export const GenesisBootSequence: React.FC<Props> = ({ onBootComplete, onAddLog }) => {
  const [phases, setPhases] = useState<GenesisPhase[]>(INITIAL_PHASES);
  const [pm2List, setPm2List] = useState<PM2Process[]>(INITIAL_PM2);
  const [isBooting, setIsBooting] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number | null>(null);
  const [bootOutput, setBootOutput] = useState<string[]>([
    '# genesis-boot.sh - Cyber Dragon Awakening Sequence on antiX Linux',
    'Ready for sequence execution...',
  ]);

  const runGenesisBoot = async () => {
    setIsBooting(true);
    soundFx.playTone(300, 'sawtooth', 0.2);
    onAddLog('Initiating Cyber Dragon Genesis Boot Sequence (antiX Linux kernel)...');

    const updatedPhases = [...INITIAL_PHASES];
    setPhases(updatedPhases);

    for (let i = 0; i < updatedPhases.length; i++) {
      setCurrentStepIndex(i);
      updatedPhases[i].status = 'running';
      setPhases([...updatedPhases]);
      soundFx.playTone(400 + i * 80, 'triangle', 0.15);

      setBootOutput((prev) => [
        ...prev,
        `>>> Initiating Phase ${i + 1}: ${updatedPhases[i].name}...`,
        `$ ${updatedPhases[i].command}`,
      ]);

      try {
        // Trigger server-side genesis simulation via Gemini API
        const res = await fetch('/api/genesis-boot', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phase: i + 1 }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.logs && data.logs.length > 0) {
            setBootOutput((prev) => [...prev, ...data.logs]);
          }
          if (data.pm2Processes) {
            setPm2List(data.pm2Processes.map((p: any, idx: number) => ({
              ...p,
              description: INITIAL_PM2[idx]?.description || 'Sovereign Process Daemon',
            })));
          }
        }
      } catch (e) {
        setBootOutput((prev) => [...prev, `[KERNEL] Daemon spawn confirmed via local socket fallback.`]);
      }

      // Small delay for sequence realism
      await new Promise((resolve) => setTimeout(resolve, 1400));

      updatedPhases[i].status = 'completed';
      setPhases([...updatedPhases]);
      soundFx.playTone(520 + i * 60, 'sine', 0.12);
    }

    setBootOutput((prev) => [
      ...prev,
      '====================================================',
      'Cyber Dragon is online. FluidmotionTV core is active.',
      'Sovereign 27-Agent Brain Trust locked in 432Hz harmony.',
      '====================================================',
    ]);

    setIsBooting(false);
    setCurrentStepIndex(null);
    onBootComplete();
    onAddLog('Genesis Awakening Sequence completed: Cyber Dragon is 100% ONLINE.');
    soundFx.playTone(432, 'triangle', 0.4);
  };

  const restartProcess = (name: string) => {
    soundFx.playTone(600, 'sine', 0.08);
    onAddLog(`PM2: Restarting daemon service '${name}'...`);
    setPm2List((prev) =>
      prev.map((p) =>
        p.name === name ? { ...p, uptimeSec: 0, status: 'starting' } : p
      )
    );
    setTimeout(() => {
      setPm2List((prev) =>
        prev.map((p) =>
          p.name === name ? { ...p, status: 'online' } : p
        )
      );
      onAddLog(`PM2: Daemon '${name}' restarted successfully.`);
    }, 800);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Sequence Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-emerald-950/40 p-5 rounded-2xl border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
            <h2 className="text-sm font-bold font-orbitron text-emerald-400 tracking-wider uppercase">
              genesis-boot.sh  Awakening Sequence
            </h2>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed font-sans">
            Executes the 4-phase cybernetic boot protocol on antiX Linux: Endocrine Heartbeat, Hippocampus Vector Store, Phagocyte Immune Shields, and Dynamic Cortex Orchestration.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={runGenesisBoot}
            disabled={isBooting}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold font-orbitron tracking-wider rounded-xl transition flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20 disabled:opacity-50"
          >
            <Play size={14} className="fill-current" />
            {isBooting ? 'AWAKENING IN PROGRESS...' : 'EXECUTE GENESIS BOOT'}
          </button>
        </div>
      </div>

      {/* 4 Phases Visual Progression */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {phases.map((phase, idx) => {
          const isRunning = phase.status === 'running';
          const isDone = phase.status === 'completed';

          return (
            <div
              key={phase.phase}
              className={`p-4 rounded-xl border transition flex flex-col justify-between ${
                isRunning
                  ? 'bg-emerald-500/10 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                  : isDone
                  ? 'bg-slate-900/40 border-emerald-500/30 text-slate-200'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-400'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold font-orbitron tracking-widest text-emerald-400">
                    PHASE 0{phase.phase}
                  </span>
                  {isDone && <CheckCircle2 size={15} className="text-emerald-400" />}
                  {isRunning && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>}
                </div>
                <h3 className="font-bold text-xs text-slate-100 mb-1">{phase.name}</h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">{phase.description}</p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/80 font-mono text-[10px] flex items-center justify-between">
                <span className="text-slate-500 truncate max-w-[140px]">{phase.serviceName}</span>
                <span
                  className={`uppercase font-bold text-[9px] px-1.5 py-0.5 rounded ${
                    isDone
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : isRunning
                      ? 'bg-amber-500/20 text-amber-300 animate-pulse'
                      : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {phase.status}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Two Column Layout: PM2 Daemon Table & Boot Output Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* PM2 Process Monitor Table */}
        <div className="lg:col-span-7 bg-slate-950/60 p-5 rounded-2xl border border-slate-800/80 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Cpu size={16} className="text-emerald-400" />
              <h3 className="font-bold text-xs font-orbitron text-slate-200 tracking-wider uppercase">
                PM2 Daemon Process Table
              </h3>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Kernel: antiX-6.1.0-sovereign</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-[11px]">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 text-[10px] uppercase">
                  <th className="pb-2">Daemon</th>
                  <th className="pb-2">PID</th>
                  <th className="pb-2">Status</th>
                  <th className="pb-2">CPU</th>
                  <th className="pb-2">RAM</th>
                  <th className="pb-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900">
                {pm2List.map((proc) => (
                  <tr key={proc.name} className="hover:bg-slate-900/40 transition">
                    <td className="py-2.5 font-bold text-slate-200">
                      <div>{proc.name}</div>
                      <div className="text-[9px] text-slate-500 font-normal">{proc.description}</div>
                    </td>
                    <td className="py-2.5 text-slate-400">{proc.pid}</td>
                    <td className="py-2.5">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/30 px-2 py-0.5 rounded border border-emerald-500/20">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        {proc.status}
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-300">{proc.cpuPercent}%</td>
                    <td className="py-2.5 text-slate-300">{proc.memoryMb} MB</td>
                    <td className="py-2.5 text-right">
                      <button
                        onClick={() => restartProcess(proc.name)}
                        className="p-1.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-800 transition cursor-pointer"
                        title="Restart PM2 process"
                      >
                        <RotateCcw size={12} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Terminal Stream from Boot Shell */}
        <div className="lg:col-span-5 bg-slate-950 p-5 rounded-2xl border border-slate-800/80 flex flex-col justify-between font-mono">
          <div className="flex items-center justify-between border-b border-slate-900 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Terminal size={14} className="text-emerald-400" />
              <span className="text-[11px] font-bold text-slate-300">antiX Live Kernel Output</span>
            </div>
            <span className="text-[9px] text-emerald-400/80 uppercase">STREAM // /dev/ttyS0</span>
          </div>

          <div className="flex-1 bg-black/60 p-3.5 rounded-xl border border-slate-900/90 text-[10.5px] text-slate-300 space-y-1.5 overflow-y-auto max-h-[260px] custom-scrollbar leading-relaxed">
            {bootOutput.map((line, idx) => (
              <div key={idx} className={line.startsWith('>>>') ? 'text-emerald-400 font-bold' : line.startsWith('$') ? 'text-cyan-400' : 'text-slate-400'}>
                {line}
              </div>
            ))}
          </div>

          <div className="mt-3 pt-2 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-500">
            <span>Somatic Socket: ws://127.0.0.1:8080</span>
            <span className="text-emerald-400">432Hz LOCK ACTIVE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
