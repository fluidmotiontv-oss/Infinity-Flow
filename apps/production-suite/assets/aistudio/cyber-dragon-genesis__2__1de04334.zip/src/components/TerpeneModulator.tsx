import React from 'react';
import { TerpeneState } from '../types';
import { soundFx } from '../utils/audioSynth';
import { Sliders, Zap, Sparkles, Shield, Cpu, Activity, RefreshCw } from 'lucide-react';

interface Props {
  terpenes: TerpeneState;
  onChangeTerpenes: (newTerpenes: TerpeneState) => void;
  onAddLog: (msg: string) => void;
  harmonicHz: number;
}

const RECEPTOR_CELLS = Array.from({ length: 64 }, (_, i) => ({
  id: i,
  x: i % 8,
  y: Math.floor(i / 8),
}));

export const TerpeneModulator: React.FC<Props> = ({
  terpenes,
  onChangeTerpenes,
  onAddLog,
  harmonicHz,
}) => {
  const applyPreset = (mode: 'compute' | 'logic' | 'creative' | 'defensive' | 'balanced') => {
    let preset: TerpeneState;
    switch (mode) {
      case 'compute':
        preset = { myrcene: 96, limonene: 60, linalool: 15, pinene: 70, caryophyllene: 40 };
        onAddLog('Receptor Grid: Calibrated for High-Focus Heavy Compute (Myrcene 96% saturated).');
        break;
      case 'logic':
        preset = { myrcene: 45, limonene: 94, linalool: 20, pinene: 85, caryophyllene: 50 };
        onAddLog('Receptor Grid: Calibrated for Rapid Logic Loops & Kernel Audit (Limonene 94% saturated).');
        break;
      case 'creative':
        preset = { myrcene: 20, limonene: 35, linalool: 95, pinene: 30, caryophyllene: 80 };
        onAddLog('Receptor Grid: Calibrated for Ambient Generative Drift (Linalool 95% saturated).');
        break;
      case 'defensive':
        preset = { myrcene: 50, limonene: 40, linalool: 10, pinene: 92, caryophyllene: 90 };
        onAddLog('Receptor Grid: Calibrated for Sovereign Shield Firewall Lockdown (Pinene & Caryophyllene).');
        break;
      case 'balanced':
        preset = { myrcene: 54, limonene: 54, linalool: 54, pinene: 54, caryophyllene: 54 };
        onAddLog('Receptor Grid: Synchronized to 54-minute hour absolute harmonic balance.');
        break;
    }
    onChangeTerpenes(preset);
    soundFx.playTone(540, 'triangle', 0.1);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Intro explanation banner */}
      <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 text-xs text-slate-300 flex items-start gap-3">
        <Sliders size={18} className="text-emerald-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-bold text-slate-100 block mb-1">ENDOCANNABINOID & TERPENE MODULATION LAYER</span>
          Adjusting these biochemical and operational ratios modulates the execution speed, transcode caching, and creative reasoning bandwidth of the 27 Agents. Myrcene speeds heavy compiling, Limonene sharpens logic routing, and Linalool opens generative holographic projection.
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Card */}
        <div className="lg:col-span-7 bg-slate-950/70 p-6 rounded-2xl border border-slate-800/80 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h3 className="text-xs font-bold font-orbitron tracking-wider text-slate-200 uppercase">
              Active Terpene Balancers
            </h3>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/30 px-2 py-0.5 rounded border border-emerald-500/20 uppercase font-mono">
              DYNAMIC MODULATION
            </span>
          </div>

          <div className="space-y-4">
            {/* Myrcene */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-rose-300">Myrcene (Heavy Focus / Video Transcode)</span>
                <span className="text-rose-400 font-bold font-mono">{terpenes.myrcene}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={terpenes.myrcene}
                onChange={(e) => {
                  onChangeTerpenes({ ...terpenes, myrcene: parseInt(e.target.value) });
                  soundFx.playTone(350 + terpenes.myrcene, 'sine', 0.02);
                }}
                className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-slate-500 font-sans">
                Accelerates FFmpeg transcode presets, compiles HandBrake buffers, and grounds compute focus.
              </p>
            </div>

            {/* Limonene */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-amber-300">Limonene (Fast Logic Loops & Audits)</span>
                <span className="text-amber-400 font-bold font-mono">{terpenes.limonene}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={terpenes.limonene}
                onChange={(e) => {
                  onChangeTerpenes({ ...terpenes, limonene: parseInt(e.target.value) });
                  soundFx.playTone(400 + terpenes.limonene, 'sine', 0.02);
                }}
                className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-slate-500 font-sans">
                Accelerates Agent 4/21 security audits, script debugging, and mesh route optimization.
              </p>
            </div>

            {/* Linalool */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-cyan-300">Linalool (Generative Ambient Drift)</span>
                <span className="text-cyan-400 font-bold font-mono">{terpenes.linalool}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={terpenes.linalool}
                onChange={(e) => {
                  onChangeTerpenes({ ...terpenes, linalool: parseInt(e.target.value) });
                  soundFx.playTone(450 + terpenes.linalool, 'sine', 0.02);
                }}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-slate-500 font-sans">
                Enhances Agent 6 (Pineal Gland) creative leap synthesis, holographic UI, and conceptual art prompts.
              </p>
            </div>

            {/* Pinene */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-300">Pinene (Security & Packet Tracking)</span>
                <span className="text-emerald-400 font-bold font-mono">{terpenes.pinene}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={terpenes.pinene}
                onChange={(e) => {
                  onChangeTerpenes({ ...terpenes, pinene: parseInt(e.target.value) });
                  soundFx.playTone(500 + terpenes.pinene, 'sine', 0.02);
                }}
                className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-slate-500 font-sans">
                Aids packet inspection, security filtering, and threat detection loops on the WireGuard tunnel.
              </p>
            </div>

            {/* Caryophyllene */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-teal-300">Caryophyllene (Thermal & RAM Load Balance)</span>
                <span className="text-teal-400 font-bold font-mono">{terpenes.caryophyllene}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={terpenes.caryophyllene}
                onChange={(e) => {
                  onChangeTerpenes({ ...terpenes, caryophyllene: parseInt(e.target.value) });
                  soundFx.playTone(550 + terpenes.caryophyllene, 'sine', 0.02);
                }}
                className="w-full accent-teal-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-slate-500 font-sans">
                Throttles system temperatures on mobile/Termux chips, stabilizes loads, and optimizes local RAM.
              </p>
            </div>
          </div>
        </div>

        {/* Receptor Grid Visualizer Card */}
        <div className="lg:col-span-5 bg-slate-950/70 p-6 rounded-2xl border border-slate-800/80 flex flex-col justify-between gap-5">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4">
              <h3 className="text-xs font-bold font-orbitron tracking-wider text-slate-200 uppercase">
                64-Receptor Matrix
              </h3>
              <span className="text-[11px] font-bold text-emerald-400 font-mono">
                {harmonicHz.toFixed(1)} HZ RESONANCE
              </span>
            </div>

            {/* Quick preset selector buttons */}
            <div className="grid grid-cols-2 gap-2 mb-4 text-[10px] font-bold font-orbitron">
              <button
                onClick={() => applyPreset('compute')}
                className="p-2 border border-slate-800 bg-slate-900/60 hover:bg-slate-900 text-rose-300 rounded-lg transition cursor-pointer"
              >
                HEAVY COMPUTE
              </button>
              <button
                onClick={() => applyPreset('logic')}
                className="p-2 border border-slate-800 bg-slate-900/60 hover:bg-slate-900 text-amber-300 rounded-lg transition cursor-pointer"
              >
                FAST LOGIC AUDIT
              </button>
              <button
                onClick={() => applyPreset('creative')}
                className="p-2 border border-slate-800 bg-slate-900/60 hover:bg-slate-900 text-cyan-300 rounded-lg transition cursor-pointer"
              >
                AMBIENT DRIFT
              </button>
              <button
                onClick={() => applyPreset('defensive')}
                className="p-2 border border-slate-800 bg-slate-900/60 hover:bg-slate-900 text-teal-300 rounded-lg transition cursor-pointer"
              >
                PORT LOCKDOWN
              </button>
            </div>

            {/* 8x8 Visual Receptor Grid */}
            <div className="bg-slate-950 border border-slate-900 rounded-xl p-4 flex items-center justify-center min-h-[170px]">
              <div className="grid grid-cols-8 gap-2">
                {RECEPTOR_CELLS.map((cell) => {
                  const isLit = (cell.x + cell.y) % 2 === 0;
                  const speed = (100 - terpenes.myrcene) / 15 + 0.6;

                  let cellColor = 'bg-slate-800/60';
                  if (isLit) {
                    if (cell.y < 3) cellColor = 'bg-rose-500 shadow-sm shadow-rose-500/40';
                    else if (cell.y < 5) cellColor = 'bg-amber-500 shadow-sm shadow-amber-500/40';
                    else cellColor = 'bg-cyan-500 shadow-sm shadow-cyan-500/40';
                  }

                  return (
                    <div
                      key={cell.id}
                      style={{ animationDuration: `${speed}s` }}
                      className={`w-3.5 h-3.5 rounded-sm transition-all duration-300 ${cellColor} ${
                        isLit ? 'animate-pulse' : 'opacity-35'
                      }`}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          <button
            onClick={() => applyPreset('balanced')}
            className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded-xl text-xs font-bold transition font-mono flex items-center justify-center gap-2 cursor-pointer"
          >
            <RefreshCw size={12} />
            HARMONIC 54-MIN CYCLE BALANCED
          </button>
        </div>
      </div>
    </div>
  );
};
