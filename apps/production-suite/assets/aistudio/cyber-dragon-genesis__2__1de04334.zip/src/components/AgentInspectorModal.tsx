import React from 'react';
import { AgentInfo, TerpeneState } from '../types';
import { soundFx } from '../utils/audioSynth';
import { X, Play, Cpu, Zap, Shield, Terminal, Activity, FileCode } from 'lucide-react';

interface Props {
  agent: AgentInfo | null;
  onClose: () => void;
  onExecuteCommand: (command: string) => void;
  terpenes: TerpeneState;
  harmonicHz: number;
}

export const AgentInspectorModal: React.FC<Props> = ({
  agent,
  onClose,
  onExecuteCommand,
  terpenes,
  harmonicHz,
}) => {
  if (!agent) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl max-w-xl w-full space-y-5 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white border border-slate-800 transition cursor-pointer"
        >
          <X size={16} />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center border text-xl font-bold font-orbitron"
            style={{
              backgroundColor: `${agent.color}15`,
              borderColor: `${agent.color}40`,
              color: agent.color,
            }}
          >
            {agent.id}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold font-orbitron text-slate-400">{agent.name}</span>
              <span
                className="text-[10px] font-bold px-2 py-0.5 rounded border"
                style={{
                  color: agent.color,
                  borderColor: `${agent.color}30`,
                  backgroundColor: `${agent.color}10`,
                }}
              >
                {agent.chamber}
              </span>
            </div>
            <h3 className="text-base font-bold font-orbitron text-white">{agent.codename}</h3>
          </div>
        </div>

        {/* Info Blocks */}
        <div className="space-y-3.5 text-xs font-mono">
          <div>
            <span className="text-[10px] uppercase text-slate-500 font-bold block mb-1">
              Role & Function
            </span>
            <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 text-slate-200 font-bold">
              {agent.role}
            </div>
          </div>

          <div>
            <span className="text-[10px] uppercase text-slate-500 font-bold block mb-1">
              Subsystem Schematic
            </span>
            <div className="p-3 bg-slate-900/40 rounded-xl border border-slate-800/60 text-slate-300 text-[11px]">
              {agent.subsystem}
            </div>
          </div>

          <div>
            <span className="text-[10px] uppercase text-slate-500 font-bold block mb-1">
              Anatomical Description & Directives
            </span>
            <p className="p-3 bg-slate-900/20 rounded-xl border border-slate-800/40 text-slate-400 font-sans leading-relaxed text-xs">
              {agent.description}
            </p>
          </div>

          {/* Live Telemetry Bar */}
          <div>
            <span className="text-[10px] uppercase text-slate-500 font-bold block mb-1">
              Real-time Hardware Telemetry
            </span>
            <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">{agent.metricLabel}:</span>
              <span className="text-emerald-400 font-bold font-orbitron text-sm">
                {(agent.baseMetric * (0.96 + Math.sin(agent.id * 2) * 0.06)).toFixed(2)} {agent.metricUnit}
              </span>
            </div>
          </div>

          {/* Executable Terminal Trigger */}
          <div>
            <span className="text-[10px] uppercase text-slate-500 font-bold block mb-1">
              Native Terminal Trigger
            </span>
            <div className="p-2.5 bg-black rounded-xl border border-slate-900 flex items-center justify-between gap-2 text-[11px] text-cyan-400 font-mono overflow-hidden">
              <span className="truncate">$ {agent.terminalCommand}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold font-mono transition cursor-pointer border border-slate-800"
          >
            Close
          </button>
          <button
            onClick={() => {
              onExecuteCommand(`Diagnostic override dispatched on ${agent.name} (${agent.codename}) - ${agent.role}`);
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold font-orbitron transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/20"
          >
            <Play size={12} className="fill-current" />
            DISPATCH DIRECTIVE
          </button>
        </div>
      </div>
    </div>
  );
};
