import React, { useState, useRef, useEffect } from 'react';
import { OrchestrationResult, GeneratedFile } from '../types';
import { soundFx } from '../utils/audioSynth';
import { Terminal, Play, Check, Copy, Download, Radio, ShieldCheck, FileCode, Binary, Sparkles, AlertCircle } from 'lucide-react';

interface Props {
  onExecuteOrchestration: (command: string) => Promise<void>;
  orchestrationResult: OrchestrationResult | null;
  isOrchestrating: boolean;
  terminalLogs: string[];
}

export const OrchestratorTerminal: React.FC<Props> = ({
  onExecuteOrchestration,
  orchestrationResult,
  isOrchestrating,
  terminalLogs,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [copiedFileIndex, setCopiedFileIndex] = useState<number | null>(null);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalLogs, isOrchestrating]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim() || isOrchestrating) return;
    onExecuteOrchestration(commandInput);
    setCommandInput('');
  };

  const runPreset = (missionName: string, promptText: string) => {
    soundFx.playTone(480, 'triangle', 0.1);
    onExecuteOrchestration(promptText);
  };

  const copyToClipboard = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedFileIndex(index);
    soundFx.playTone(700, 'sine', 0.05);
    setTimeout(() => setCopiedFileIndex(null), 2000);
  };

  const downloadFile = (file: GeneratedFile) => {
    const blob = new Blob([file.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    soundFx.playTone(620, 'triangle', 0.08);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Preset Missions Header */}
      <div className="bg-slate-900/40 p-4 rounded-2xl border border-slate-800 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold font-orbitron text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles size={14} /> Preset Autonomous Missions
          </span>
          <span className="text-[10px] text-slate-500 font-mono">Select a mission to dispatch across 27 agents</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          <button
            onClick={() =>
              runPreset(
                'Surf Chronicles',
                'Agent 19 (The Maw) ingest latest surf raw logs. Trigger Agent 20 for FFmpeg transcode presets, and assemble into Pee Dub Surf Chronicles chronology via Agent 22 (The Gut).'
              )
            }
            disabled={isOrchestrating}
            className="p-3 bg-slate-950/80 hover:bg-slate-900 text-left border border-slate-800/80 hover:border-emerald-500/40 rounded-xl transition cursor-pointer text-xs font-bold text-slate-200 truncate disabled:opacity-50"
          >
            <div className="text-emerald-400 font-orbitron text-[10px] mb-1">MISSION 01</div>
            <div>Pee Dub Surf Chronicles</div>
            <div className="text-[10px] text-slate-500 font-normal font-sans">FFmpeg ingestion & gut assembly</div>
          </button>

          <button
            onClick={() =>
              runPreset(
                'WireGuard Armor',
                'Agent 23 (The Scales) configure WireGuard VPN tunnels and SSH keys. Trigger Agent 11 (The Lungs) for Cloudflare routing, and Agent 24 (The Horns) to raise phagocyte firewall shields.'
              )
            }
            disabled={isOrchestrating}
            className="p-3 bg-slate-950/80 hover:bg-slate-900 text-left border border-slate-800/80 hover:border-emerald-500/40 rounded-xl transition cursor-pointer text-xs font-bold text-slate-200 truncate disabled:opacity-50"
          >
            <div className="text-cyan-400 font-orbitron text-[10px] mb-1">MISSION 02</div>
            <div>WireGuard Shield Lockdown</div>
            <div className="text-[10px] text-slate-500 font-normal font-sans">VPN tunnels & port protection</div>
          </button>

          <button
            onClick={() =>
              runPreset(
                'FluidmotionTV Burst',
                'Agent 14 (Left Wing) engage FluidmotionTV 60fps playout engine. Coordinate with Agent 27 (The Breath) to push live stream burst across sovereign peer mesh.'
              )
            }
            disabled={isOrchestrating}
            className="p-3 bg-slate-950/80 hover:bg-slate-900 text-left border border-slate-800/80 hover:border-emerald-500/40 rounded-xl transition cursor-pointer text-xs font-bold text-slate-200 truncate disabled:opacity-50"
          >
            <div className="text-rose-400 font-orbitron text-[10px] mb-1">MISSION 03</div>
            <div>FluidmotionTV Playout</div>
            <div className="text-[10px] text-slate-500 font-normal font-sans">60fps video engine broadcast</div>
          </button>

          <button
            onClick={() =>
              runPreset(
                'Harmonic 432Hz Grid',
                'Agent 2 (The Ears) calibrate ElevenLabs and 432Hz harmonic acoustic synthesis. Agent 8 (Thoracic Spine) sync Dragon 9 clock, and Agent 10 (The Heart) pulse endocrine heartbeat.'
              )
            }
            disabled={isOrchestrating}
            className="p-3 bg-slate-950/80 hover:bg-slate-900 text-left border border-slate-800/80 hover:border-emerald-500/40 rounded-xl transition cursor-pointer text-xs font-bold text-slate-200 truncate disabled:opacity-50"
          >
            <div className="text-amber-400 font-orbitron text-[10px] mb-1">MISSION 04</div>
            <div>432Hz Harmonic Resonant Sync</div>
            <div className="text-[10px] text-slate-500 font-normal font-sans">Acoustic & clock lockstep</div>
          </button>
        </div>
      </div>

      {/* Terminal Shell Box */}
      <div className="flex flex-col border border-slate-900 rounded-2xl bg-slate-950/90 overflow-hidden shadow-2xl">
        <div className="px-4 py-2.5 border-b border-slate-900 bg-slate-900/60 flex items-center justify-between text-[11px] font-bold text-slate-400 font-mono">
          <span className="flex items-center gap-2 text-emerald-400">
            <Terminal size={13} />
            cyber-dragon@antiX:~$ 27_agent_orchestrator
          </span>
          <span className="text-slate-500">TTY // 432Hz MESH // READY</span>
        </div>

        {/* Output Stream */}
        <div className="p-4 font-mono text-[11px] space-y-2 overflow-y-auto max-h-[300px] bg-black/50 text-slate-300 leading-relaxed custom-scrollbar">
          {terminalLogs.map((log, idx) => (
            <div key={idx} className="whitespace-pre-wrap">
              {log.startsWith('[') ? (
                <>
                  <span className="text-slate-500">{log.substring(0, 11)}</span>
                  <span className="text-emerald-400"> sovereign-cortex $</span>
                  <span>{log.substring(11)}</span>
                </>
              ) : (
                <span className="text-slate-300">{log}</span>
              )}
            </div>
          ))}

          {isOrchestrating && (
            <div className="text-emerald-400 flex items-center gap-2 animate-pulse py-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>[Gemini Orchestrator] Arbitrating 27-agent consensus & compiling scripts...</span>
            </div>
          )}
          <div ref={terminalEndRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="border-t border-slate-900 bg-slate-950 px-4 py-3 flex items-center gap-2">
          <span className="text-emerald-500 font-bold font-mono">$</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder="Type directive (e.g., 'Transcode 4K footage and raise WireGuard tunnels on antiX node 14')"
            disabled={isOrchestrating}
            className="flex-1 bg-transparent border-none text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-0 text-[12px] font-mono"
          />
          <button
            type="submit"
            disabled={isOrchestrating || !commandInput.trim()}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold font-orbitron transition flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
          >
            DISPATCH
            <Play size={11} className="fill-current" />
          </button>
        </form>
      </div>

      {/* Gemini Consensus Results Output (Agent Thoughts, Stomach Consensus, Breath Payload, Generated Scripts) */}
      {orchestrationResult && (
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-sm font-bold font-orbitron text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <Binary size={16} /> Latest 27-Agent Consensus Synthesis
              </h3>
              <p className="text-xs text-slate-500 font-sans">
                Digested by Agent 13 (The Stomach) and broadcast live by Agent 27 (The Breath).
              </p>
            </div>
            <div className="text-right font-mono">
              <span className="text-[10px] text-slate-500 block uppercase">Resonance Rate</span>
              <span className="text-xs font-bold text-rose-400">{orchestrationResult.heartbeatFrequency}</span>
            </div>
          </div>

          {/* Terpene Analysis */}
          <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 text-xs text-slate-300">
            <span className="font-bold text-slate-100 block mb-1 font-orbitron text-[11px]">
              TERPENE MODULATION STATE
            </span>
            <p className="leading-relaxed font-sans">{orchestrationResult.terpeneAnalysis}</p>
          </div>

          {/* Active Agent Log Cards */}
          <div className="space-y-3">
            <span className="text-xs font-bold font-orbitron text-slate-400 uppercase tracking-wider block">
              Dispatched Agents Telemetry & Internal Monologues
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {orchestrationResult.agentLogs.map((log, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-300 font-orbitron">
                      {log.agentName}
                    </span>
                    <span className="text-[9px] font-bold uppercase tracking-wider bg-slate-900 px-2 py-0.5 text-emerald-400 border border-emerald-500/20 rounded font-mono">
                      {log.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed italic font-sans">
                    "{log.thought}"
                  </p>
                  <div className="text-[11px] text-emerald-400 font-bold bg-emerald-950/30 px-2.5 py-1 rounded border border-emerald-500/15 font-mono truncate">
                    ACTION: {log.action}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Stomach Consensus */}
          <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/5 space-y-2">
            <span className="text-xs font-bold font-orbitron text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck size={15} /> Agent 13 (The Stomach) Consensus Synthesis
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-sans italic">
              "{orchestrationResult.stomachConsensus}"
            </p>
          </div>

          {/* Breath Live Output */}
          <div className="p-4 rounded-xl border border-cyan-500/30 bg-cyan-500/5 space-y-2">
            <span className="text-xs font-bold font-orbitron text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Radio size={15} /> Agent 27 (The Breath) Live Payload Output
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {orchestrationResult.breathOutput}
            </p>
          </div>

          {/* Generated Code & Config Files */}
          {orchestrationResult.generatedFiles && orchestrationResult.generatedFiles.length > 0 && (
            <div className="space-y-4">
              <span className="text-xs font-bold font-orbitron text-slate-300 uppercase tracking-wider block">
                Generated antiX / Termux Executable Scripts & Manifests
              </span>
              <div className="space-y-4">
                {orchestrationResult.generatedFiles.map((file, idx) => (
                  <div key={idx} className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden font-mono text-xs">
                    <div className="bg-slate-900/80 px-4 py-2.5 border-b border-slate-900 flex items-center justify-between text-slate-300">
                      <div className="flex items-center gap-2">
                        <FileCode size={14} className="text-emerald-400" />
                        <span className="font-bold text-emerald-400">{file.fileName}</span>
                        <span className="text-[10px] text-slate-500">({file.language})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => copyToClipboard(file.content, idx)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          {copiedFileIndex === idx ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
                          {copiedFileIndex === idx ? 'COPIED' : 'COPY'}
                        </button>
                        <button
                          onClick={() => downloadFile(file)}
                          className="px-2.5 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer border border-emerald-500/30"
                        >
                          <Download size={11} />
                          DOWNLOAD
                        </button>
                      </div>
                    </div>
                    <div className="px-4 py-2 text-[11px] text-slate-400 bg-slate-950/60 border-b border-slate-900 font-sans">
                      {file.description}
                    </div>
                    <pre className="p-4 bg-black/70 text-slate-200 overflow-x-auto max-h-60 whitespace-pre font-mono leading-relaxed text-[11px]">
                      {file.content}
                    </pre>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
