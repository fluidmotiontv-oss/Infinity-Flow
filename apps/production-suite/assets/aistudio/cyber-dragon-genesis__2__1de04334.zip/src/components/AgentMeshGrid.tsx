import React, { useState } from 'react';
import { AgentInfo, ChamberType } from '../types';
import { AGENTS_DATA } from '../data/agents';
import { soundFx } from '../utils/audioSynth';
import { Eye, Volume2, Radio, Cpu, Binary, Sparkles, FileCode, Clock, HardDrive, RefreshCw, Wifi, ShieldCheck, Plus, Sliders, Trash2, Lock, AlertCircle } from 'lucide-react';

interface Props {
  selectedAgent: AgentInfo | null;
  onSelectAgent: (agent: AgentInfo) => void;
  onExecuteAgentAction: (agent: AgentInfo) => void;
  activeAgents?: string[];
  isOrchestrating: boolean;
}

const CHAMBERS_LIST: ChamberType[] = [
  'Command & Control',
  'The Central Chamber',
  'Action & Propulsion',
  'Resource Processing',
  'Defense & Environment',
];

export const AgentMeshGrid: React.FC<Props> = ({
  selectedAgent,
  onSelectAgent,
  onExecuteAgentAction,
  activeAgents = [],
  isOrchestrating,
}) => {
  const [selectedChamberFilter, setSelectedChamberFilter] = useState<string>('ALL');

  const filteredAgents =
    selectedChamberFilter === 'ALL'
      ? AGENTS_DATA
      : AGENTS_DATA.filter((a) => a.chamber === selectedChamberFilter);

  const getAgentIcon = (id: number) => {
    switch (id) {
      case 1: return <Eye size={16} />;
      case 2: return <Volume2 size={16} />;
      case 3: return <Radio size={16} />;
      case 4: return <Cpu size={16} />;
      case 5: return <Binary size={16} />;
      case 6: return <Sparkles size={16} />;
      case 7: return <FileCode size={16} />;
      case 8: return <Clock size={16} />;
      case 9: return <HardDrive size={16} />;
      case 10: return <RefreshCw size={16} />;
      case 11: return <Wifi size={16} />;
      case 12: return <Plus size={16} />;
      case 13: return <ShieldCheck size={16} />;
      case 14: return <Radio size={16} />;
      case 15: return <Wifi size={16} />;
      case 16: return <FileCode size={16} />;
      case 17: return <ActivityIcon size={16} />;
      case 18: return <Sliders size={16} />;
      case 19: return <Plus size={16} />;
      case 20: return <Sliders size={16} />;
      case 21: return <ShieldCheck size={16} />;
      case 22: return <Binary size={16} />;
      case 23: return <Lock size={16} />;
      case 24: return <AlertCircle size={16} />;
      case 25: return <Trash2 size={16} />;
      case 26: return <Eye size={16} />;
      case 27: return <Radio size={16} />;
      default: return <Cpu size={16} />;
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Filter Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/50 p-3 rounded-2xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            onClick={() => {
              setSelectedChamberFilter('ALL');
              soundFx.playTone(400, 'sine', 0.04);
            }}
            className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              selectedChamberFilter === 'ALL'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            ALL 27 NODES
          </button>
          {CHAMBERS_LIST.map((chamber) => {
            const isSelected = selectedChamberFilter === chamber;
            return (
              <button
                key={chamber}
                onClick={() => {
                  setSelectedChamberFilter(chamber);
                  soundFx.playTone(440, 'sine', 0.04);
                }}
                className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-[11px] ${
                  isSelected
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-950 text-slate-400 border border-slate-800/80 hover:text-slate-200'
                }`}
              >
                {chamber}
              </button>
            );
          })}
        </div>

        <div className="text-[11px] font-bold text-slate-400 flex items-center gap-2">
          <span>Active Nodes:</span>
          <span className="text-emerald-400 font-mono">27 / 27 Online</span>
        </div>
      </div>

      {/* Agents Grid List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredAgents.map((agent) => {
          const isSelected = selectedAgent?.id === agent.id;
          const isCurrentlyActive = activeAgents.some(
            (name) =>
              name.toLowerCase().includes(agent.codename.toLowerCase()) ||
              name.toLowerCase().includes(agent.name.toLowerCase())
          );

          return (
            <div
              key={agent.id}
              onClick={() => {
                onSelectAgent(agent);
                soundFx.playTone(500, 'sine', 0.04);
              }}
              className={`p-4 rounded-xl border text-left flex flex-col justify-between gap-3 transition cursor-pointer relative overflow-hidden group ${
                isSelected
                  ? 'bg-slate-900 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/40'
              }`}
            >
              {/* Card top */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div
                    className="p-2 rounded-lg border text-slate-100"
                    style={{
                      backgroundColor: `${agent.color}20`,
                      borderColor: `${agent.color}40`,
                      color: agent.color,
                    }}
                  >
                    {getAgentIcon(agent.id)}
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 font-orbitron block">
                      {agent.name}
                    </span>
                    <h4 className="text-xs font-bold text-slate-100 group-hover:text-emerald-400 transition">
                      {agent.codename}
                    </h4>
                  </div>
                </div>

                <span
                  className="text-[9px] font-bold px-2 py-0.5 rounded border"
                  style={{
                    color: agent.color,
                    borderColor: `${agent.color}30`,
                    backgroundColor: `${agent.color}10`,
                  }}
                >
                  {agent.chamber.split(' ')[0]}
                </span>
              </div>

              {/* Description */}
              <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">
                {agent.description}
              </p>

              {/* Subsystem & Live Metric */}
              <div className="pt-2 border-t border-slate-900 font-mono text-[10px] flex items-center justify-between text-slate-400">
                <span className="truncate max-w-[130px]">{agent.metricLabel}:</span>
                <span className="font-bold text-emerald-400">
                  {(agent.baseMetric * (0.95 + Math.sin(agent.id) * 0.08)).toFixed(1)} {agent.metricUnit}
                </span>
              </div>

              {/* Ping badge if actively computing in Gemini consensus */}
              {isCurrentlyActive && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

function ActivityIcon(props: any) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
  );
}
