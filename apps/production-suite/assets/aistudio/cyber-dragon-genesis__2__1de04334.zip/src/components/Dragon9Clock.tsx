import React from 'react';
import { Clock, Sun, Moon, Zap, Volume2, VolumeX, Radio } from 'lucide-react';
import { soundFx } from '../utils/audioSynth';

interface Props {
  d9Hour: number;
  d9Minute: number;
  d9Second: number;
  stdTime: string;
  harmonicHz: number;
  audioActive: boolean;
  onToggleAudio: () => void;
}

export const Dragon9Clock: React.FC<Props> = ({
  d9Hour,
  d9Minute,
  d9Second,
  stdTime,
  harmonicHz,
  audioActive,
  onToggleAudio,
}) => {
  // Calculate day cycle phase
  const totalMinutes = d9Hour * 54 + d9Minute;
  const cyclePercent = Math.min(100, Math.max(0, (totalMinutes / 1440) * 100));

  let stage = 'Solar Dawn Ascendant';
  if (cyclePercent > 25 && cyclePercent <= 50) stage = 'Midday Apex Combustion';
  else if (cyclePercent > 50 && cyclePercent <= 75) stage = 'Egress Evening Descent';
  else if (cyclePercent > 75) stage = 'Sovereign Night Mesh Shift';

  return (
    <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800/80 flex flex-col justify-between gap-4">
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-amber-400" />
          <h3 className="text-xs font-bold font-orbitron text-slate-200 tracking-wider uppercase">
            Dragon 9 Master Chronometer
          </h3>
        </div>
        <button
          onClick={onToggleAudio}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold font-mono transition cursor-pointer border ${
            audioActive
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
          title="Toggles real-time 432Hz harmonic sound generator"
        >
          {audioActive ? <Volume2 size={12} /> : <VolumeX size={12} />}
          <span>432Hz Synth {audioActive ? 'ON' : 'MUTED'}</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {/* Dragon 9 Clock */}
        <div className="p-3.5 bg-slate-900/60 rounded-xl border border-amber-500/20 flex flex-col">
          <span className="text-[10px] font-bold text-amber-400 font-orbitron uppercase tracking-wider">
            DRAGON 9 TIME
          </span>
          <span className="text-xl font-bold font-mono text-white tracking-widest my-1">
            {d9Hour.toString().padStart(2, '0')}:{d9Minute.toString().padStart(2, '0')}:{d9Second.toString().padStart(2, '0')}
          </span>
          <span className="text-[9px] text-slate-400 font-mono">
            54 Min/Hour  26.66H Cycle
          </span>
        </div>

        {/* Standard Clock */}
        <div className="p-3.5 bg-slate-900/40 rounded-xl border border-slate-800 flex flex-col">
          <span className="text-[10px] font-bold text-slate-400 font-orbitron uppercase tracking-wider">
            STANDARD UTC
          </span>
          <span className="text-xl font-bold font-mono text-slate-300 tracking-widest my-1">
            {stdTime || '00:00:00'}
          </span>
          <span className="text-[9px] text-slate-500 font-mono">
            60 Min/Hour  24.00H Earth
          </span>
        </div>
      </div>

      {/* Harmonic Hz Indicator */}
      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
        <div className="flex items-center gap-2">
          <Zap size={14} className="text-rose-400" />
          <span className="text-slate-400">HARMONIC RESONANCE:</span>
        </div>
        <span className="font-bold text-rose-400 font-orbitron">{harmonicHz.toFixed(2)} Hz</span>
      </div>

      {/* Cycle Progress bar */}
      <div className="space-y-1.5 font-mono text-[10px]">
        <div className="flex justify-between text-slate-400">
          <span>CYCLE: {stage}</span>
          <span>{cyclePercent.toFixed(1)}%</span>
        </div>
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500 transition-all duration-1000"
            style={{ width: `${cyclePercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
