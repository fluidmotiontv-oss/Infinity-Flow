import React, { useRef, useEffect, useState } from 'react';
import { AgentInfo } from '../types';
import { AGENTS_DATA } from '../data/agents';
import { soundFx } from '../utils/audioSynth';
import { RotateCw, ZoomIn, ZoomOut, Compass, Eye, Shield, Cpu, Activity, Play } from 'lucide-react';

interface Props {
  selectedAgent: AgentInfo | null;
  onSelectAgent: (agent: AgentInfo) => void;
  activeAgents?: string[];
  isOrchestrating: boolean;
  heartbeatHz: number;
}

export const CyberDragonCanvas: React.FC<Props> = ({
  selectedAgent,
  onSelectAgent,
  activeAgents = [],
  isOrchestrating,
  heartbeatHz,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [rotationAngle, setRotationAngle] = useState(0.4);
  const [pitchAngle, setPitchAngle] = useState(0.35);
  const [zoomScale, setZoomScale] = useState(1.0);
  const [isAutoRotate, setIsAutoRotate] = useState(true);
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let localRot = rotationAngle;

    // Build 3D dragon anatomical spine & chamber structure
    // Head (1-6), Cervical/Thoracic/Lumbar Spine (7-9), Heart/Lungs/Blood/Stomach (10-13),
    // Wings & Limbs (14-18), Digestive Maw/Spleen/Liver/Gut (19-22), Armor & Scales/Breath (23-27)
    const nodeCoords = AGENTS_DATA.map((agent) => {
      let x = 0, y = 0, z = 0;
      const id = agent.id;

      if (id <= 6) {
        // Head / Brain Trust cluster
        const angle = (id / 6) * Math.PI * 2;
        x = Math.cos(angle) * 0.35;
        y = -0.65 + (id === 6 ? -0.15 : 0); // Pineal elevated
        z = Math.sin(angle) * 0.25;
      } else if (id <= 9) {
        // Spine vertebrae (7, 8, 9)
        const spineStep = (id - 6);
        x = (id % 2 === 0 ? 0.08 : -0.08);
        y = -0.45 + spineStep * 0.22;
        z = -0.1 + spineStep * 0.05;
      } else if (id <= 13) {
        // Central Chamber (Heart, Lungs, Blood, Stomach)
        const cAngle = ((id - 10) / 4) * Math.PI * 2;
        x = Math.sin(cAngle) * 0.45;
        y = -0.05 + ((id - 10) * 0.08);
        z = Math.cos(cAngle) * 0.35;
      } else if (id <= 18) {
        // Wings & Limbs (Left/Right Wings wide, Limbs below, Tail behind)
        if (id === 14) { x = -0.85; y = -0.15; z = 0.1; } // Left Wing
        else if (id === 15) { x = 0.85; y = -0.15; z = 0.1; } // Right Wing
        else if (id === 16) { x = -0.4; y = 0.45; z = 0.35; } // Forelimbs
        else if (id === 17) { x = 0.4; y = 0.55; z = -0.2; } // Hindlimbs
        else { x = 0.0; y = 0.75; z = -0.6; } // Tail
      } else if (id <= 22) {
        // Digestive System (Maw, Spleen, Liver, Gut)
        const dAngle = ((id - 19) / 4) * Math.PI * 2;
        x = Math.cos(dAngle) * 0.4;
        y = 0.25 + ((id - 19) * 0.1);
        z = Math.sin(dAngle) * 0.3;
      } else {
        // Armor & Scales & Breath (23-27)
        if (id === 23) { x = -0.55; y = 0.1; z = -0.45; } // Scales
        else if (id === 24) { x = 0.35; y = -0.75; z = 0.2; } // Horns
        else if (id === 25) { x = -0.2; y = 0.6; z = 0.45; } // Claws
        else if (id === 26) { x = 0.6; y = 0.2; z = -0.35; } // Camouflage
        else { x = 0.0; y = -0.85; z = 0.4; } // Breath (front exhale)
      }

      return { agent, x, y, z };
    });

    const project = (x: number, y: number, z: number, rY: number, rX: number, scaleFactor: number, width: number, height: number) => {
      // Y-axis rotation
      const cosY = Math.cos(rY);
      const sinY = Math.sin(rY);
      const x1 = x * cosY - z * sinY;
      const z1 = x * sinY + z * cosY;

      // X-axis pitch rotation
      const cosX = Math.cos(rX);
      const sinX = Math.sin(rX);
      const y2 = y * cosX - z1 * sinX;
      const z2 = y * sinX + z1 * cosX;

      const fov = 400;
      const p = fov / (fov + z2 * 250);
      const cx = width / 2;
      const cy = height / 2;

      return {
        px: cx + x1 * 220 * scaleFactor * p,
        py: cy + y2 * 220 * scaleFactor * p,
        zDepth: z2,
        scale: p,
      };
    };

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      if (isAutoRotate) {
        localRot += 0.006 * (isOrchestrating ? 2.2 : 1.0);
      }

      // Draw subtle background cybernetic grid
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let gx = 0; gx < width; gx += gridSize) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, height);
        ctx.stroke();
      }
      for (let gy = 0; gy < height; gy += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(width, gy);
        ctx.stroke();
      }

      // Project all nodes
      const projected = nodeCoords.map((item) => {
        const p = project(item.x, item.y, item.z, localRot, pitchAngle, zoomScale, width, height);
        return {
          ...item,
          ...p,
        };
      });

      // Sort by depth (painter's algorithm)
      projected.sort((a, b) => b.zDepth - a.zDepth);

      // 1. Draw Mesh connections across same chamber and spinal column
      ctx.lineWidth = 1.2;
      for (let i = 0; i < projected.length; i++) {
        for (let j = i + 1; j < projected.length; j++) {
          const a = projected[i];
          const b = projected[j];
          const sameChamber = a.agent.chamber === b.agent.chamber;
          const isSpineLink = (a.agent.id >= 7 && a.agent.id <= 9 && b.agent.id >= 7 && b.agent.id <= 9);
          const isSpinalBus = (a.agent.id === 4 && b.agent.id === 8) || (a.agent.id === 8 && b.agent.id === 13) || (a.agent.id === 13 && b.agent.id === 27);

          if (sameChamber || isSpineLink || isSpinalBus) {
            const alpha = isSpinalBus ? 0.4 : sameChamber ? 0.2 : 0.1;
            ctx.strokeStyle = isSpinalBus
              ? 'rgba(244, 63, 94, 0.6)'
              : a.agent.color + (Math.floor(alpha * 255).toString(16).padStart(2, '0'));

            ctx.beginPath();
            ctx.moveTo(a.px, a.py);
            ctx.lineTo(b.px, b.py);
            ctx.stroke();
          }
        }
      }

      // 2. Draw Dynamic Dragon Energy Arc looping through nodes
      const now = Date.now();
      const pulsePhase = (now % 3000) / 3000;
      ctx.lineWidth = isOrchestrating ? 2.5 : 1.5;
      ctx.strokeStyle = isOrchestrating ? 'rgba(16, 185, 129, 0.7)' : 'rgba(6, 182, 212, 0.35)';
      ctx.beginPath();
      
      const spinalChain = projected.filter(p => [1, 4, 6, 7, 8, 9, 10, 13, 14, 15, 19, 22, 23, 27].includes(p.agent.id));
      if (spinalChain.length > 1) {
        ctx.moveTo(spinalChain[0].px, spinalChain[0].py);
        for (let i = 1; i < spinalChain.length; i++) {
          ctx.lineTo(spinalChain[i].px, spinalChain[i].py);
        }
        ctx.stroke();

        // Pulsing spark on highway
        const sparkIndex = Math.floor(pulsePhase * (spinalChain.length - 1));
        const nextSpark = Math.min(sparkIndex + 1, spinalChain.length - 1);
        const subRatio = (pulsePhase * (spinalChain.length - 1)) - sparkIndex;
        const sparkX = spinalChain[sparkIndex].px + (spinalChain[nextSpark].px - spinalChain[sparkIndex].px) * subRatio;
        const sparkY = spinalChain[sparkIndex].py + (spinalChain[nextSpark].py - spinalChain[sparkIndex].py) * subRatio;

        ctx.fillStyle = '#10b981';
        ctx.shadowColor = '#10b981';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(sparkX, sparkY, isOrchestrating ? 6 : 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // 3. Draw Nodes
      projected.forEach((node) => {
        const isSelected = selectedAgent?.id === node.agent.id;
        const isCurrentlyActive = activeAgents.some(
          (name) => name.toLowerCase().includes(node.agent.codename.toLowerCase()) || name.includes(node.agent.name)
        );

        const radius = (isSelected ? 9 : isCurrentlyActive ? 7.5 : 5) * node.scale;

        // Outer glow
        if (isSelected || isCurrentlyActive) {
          ctx.beginPath();
          ctx.arc(node.px, node.py, radius * 2.2, 0, Math.PI * 2);
          ctx.fillStyle = isSelected ? `${node.agent.color}33` : 'rgba(16, 185, 129, 0.25)';
          ctx.fill();
        }

        // Base circle
        ctx.beginPath();
        ctx.arc(node.px, node.py, radius, 0, Math.PI * 2);
        ctx.fillStyle = isSelected ? '#ffffff' : isCurrentlyActive ? '#10b981' : node.agent.color;
        ctx.shadowColor = node.agent.color;
        ctx.shadowBlur = isSelected ? 15 : 6;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Border ring
        ctx.strokeStyle = isSelected ? node.agent.color : '#0f172a';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Node Label if selected or highlighted
        if (isSelected || isCurrentlyActive || node.scale > 1.1) {
          ctx.fillStyle = isSelected ? '#38bdf8' : '#e2e8f0';
          ctx.font = 'bold 9px "JetBrains Mono", monospace';
          ctx.textAlign = 'center';
          ctx.fillText(`AG-${node.agent.id}`, node.px, node.py - radius - 5);
          ctx.font = '8px "JetBrains Mono", monospace';
          ctx.fillStyle = '#94a3b8';
          ctx.fillText(node.agent.codename, node.px, node.py - radius - 15);
        }
      });

      // HUD Overlay metrics
      ctx.fillStyle = 'rgba(148, 163, 184, 0.6)';
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`ORBIT: ${(localRot % (Math.PI * 2)).toFixed(2)} RAD | PITCH: ${pitchAngle.toFixed(2)}`, 14, height - 24);
      ctx.fillText(`CYBER_DRAGON_SYNTH: ${heartbeatHz.toFixed(1)}Hz | NODES_SYNC: 27/27`, 14, height - 12);

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [rotationAngle, pitchAngle, zoomScale, isAutoRotate, selectedAgent, activeAgents, isOrchestrating, heartbeatHz]);

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
    setIsAutoRotate(false);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMousePosRef.current.x;
    const dy = e.clientY - lastMousePosRef.current.y;

    setRotationAngle((prev) => prev + dx * 0.008);
    setPitchAngle((prev) => Math.max(-1.0, Math.min(1.0, prev + dy * 0.006)));
    lastMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleCanvasMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Find closest node in projected space
    const width = canvas.width;
    const height = canvas.height;
    let closest: AgentInfo | null = null;
    let minDist = 35; // px

    AGENTS_DATA.forEach((agent) => {
      let x = 0, y = 0, z = 0;
      const id = agent.id;
      if (id <= 6) {
        const angle = (id / 6) * Math.PI * 2;
        x = Math.cos(angle) * 0.35;
        y = -0.65 + (id === 6 ? -0.15 : 0);
        z = Math.sin(angle) * 0.25;
      } else if (id <= 9) {
        const spineStep = (id - 6);
        x = (id % 2 === 0 ? 0.08 : -0.08);
        y = -0.45 + spineStep * 0.22;
        z = -0.1 + spineStep * 0.05;
      } else if (id <= 13) {
        const cAngle = ((id - 10) / 4) * Math.PI * 2;
        x = Math.sin(cAngle) * 0.45;
        y = -0.05 + ((id - 10) * 0.08);
        z = Math.cos(cAngle) * 0.35;
      } else if (id <= 18) {
        if (id === 14) { x = -0.85; y = -0.15; z = 0.1; }
        else if (id === 15) { x = 0.85; y = -0.15; z = 0.1; }
        else if (id === 16) { x = -0.4; y = 0.45; z = 0.35; }
        else if (id === 17) { x = 0.4; y = 0.55; z = -0.2; }
        else { x = 0.0; y = 0.75; z = -0.6; }
      } else if (id <= 22) {
        const dAngle = ((id - 19) / 4) * Math.PI * 2;
        x = Math.cos(dAngle) * 0.4;
        y = 0.25 + ((id - 19) * 0.1);
        z = Math.sin(dAngle) * 0.3;
      } else {
        if (id === 23) { x = -0.55; y = 0.1; z = -0.45; }
        else if (id === 24) { x = 0.35; y = -0.75; z = 0.2; }
        else if (id === 25) { x = -0.2; y = 0.6; z = 0.45; }
        else if (id === 26) { x = 0.6; y = 0.2; z = -0.35; }
        else { x = 0.0; y = -0.85; z = 0.4; }
      }

      const cosY = Math.cos(rotationAngle);
      const sinY = Math.sin(rotationAngle);
      const x1 = x * cosY - z * sinY;
      const z1 = x * sinY + z * cosY;
      const cosX = Math.cos(pitchAngle);
      const sinX = Math.sin(pitchAngle);
      const y2 = y * cosX - z1 * sinX;
      const z2 = y * sinX + z1 * cosX;
      const fov = 400;
      const p = fov / (fov + z2 * 250);

      const px = width / 2 + x1 * 220 * zoomScale * p;
      const py = height / 2 + y2 * 220 * zoomScale * p;

      const dist = Math.hypot(px - clickX, py - clickY);
      if (dist < minDist) {
        minDist = dist;
        closest = agent;
      }
    });

    if (closest) {
      onSelectAgent(closest);
      soundFx.playTone(520, 'sine', 0.05);
    }
  };

  return (
    <div className="relative w-full h-full bg-slate-950/80 rounded-2xl border border-slate-800/80 overflow-hidden flex flex-col group">
      {/* Top HUD overlay */}
      <div className="absolute top-3 left-4 right-4 flex items-center justify-between z-10 pointer-events-none">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider bg-slate-900/90 px-2.5 py-1 rounded border border-slate-800">
            3D Cyber Dragon Spine & Node Mesh
          </span>
        </div>
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setIsAutoRotate(!isAutoRotate)}
            className={`px-2 py-1 rounded border text-[10px] font-bold transition ${
              isAutoRotate
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <RotateCw size={11} className={`inline mr-1 ${isAutoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            {isAutoRotate ? 'AUTO-ORBIT' : 'LOCKED'}
          </button>
          <button
            onClick={() => setZoomScale((z) => Math.min(1.8, z + 0.15))}
            className="p-1 rounded bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200"
            title="Zoom in"
          >
            <ZoomIn size={12} />
          </button>
          <button
            onClick={() => setZoomScale((z) => Math.max(0.6, z - 0.15))}
            className="p-1 rounded bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200"
            title="Zoom out"
          >
            <ZoomOut size={12} />
          </button>
        </div>
      </div>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={700}
        height={460}
        onMouseDown={handleCanvasMouseDown}
        onMouseMove={handleCanvasMouseMove}
        onMouseUp={handleCanvasMouseUp}
        onMouseLeave={handleCanvasMouseUp}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-grab active:cursor-grabbing block"
      />

      {/* Bottom Hint */}
      <div className="absolute bottom-2 left-4 right-4 flex items-center justify-between text-[10px] text-slate-500 pointer-events-none font-mono">
        <span>Click node to inspect | Drag to rotate 3D axis</span>
        <span className="text-cyan-400/80">FluidmotionTV Core Online</span>
      </div>
    </div>
  );
};
