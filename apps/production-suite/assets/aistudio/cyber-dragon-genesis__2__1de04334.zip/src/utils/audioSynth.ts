// Web Audio API Synthesizer for 432Hz Harmonic Frequency & Cybernetic Feedback

class CyberAudioSynth {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientOsc: OscillatorNode | null = null;
  private ambientGain: GainNode | null = null;
  private isMuted: boolean = true;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.3, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggleMute(): boolean {
    this.initContext();
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stopAmbientHum();
    } else {
      this.startAmbientHum(432);
      this.playTone(432, 'triangle', 0.2, 0.08);
    }
    return !this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public playTone(freq: number = 432, type: OscillatorType = 'sine', duration: number = 0.08, volume: number = 0.05) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      // Audio might be constrained by browser autoplay policy
    }
  }

  public startAmbientHum(baseFreq: number = 432) {
    if (this.isMuted) return;
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    if (this.ambientOsc) {
      this.stopAmbientHum();
    }

    try {
      this.ambientOsc = this.ctx.createOscillator();
      this.ambientGain = this.ctx.createGain();

      // Sub-octave 108Hz harmonic hum of 432Hz
      this.ambientOsc.type = 'sine';
      this.ambientOsc.frequency.setValueAtTime(baseFreq / 4, this.ctx.currentTime);

      this.ambientGain.gain.setValueAtTime(0.02, this.ctx.currentTime);

      this.ambientOsc.connect(this.ambientGain);
      this.ambientGain.connect(this.masterGain);

      this.ambientOsc.start();
    } catch (e) {
      console.warn('Ambient audio error:', e);
    }
  }

  public updateAmbientFrequency(freq: number) {
    if (!this.ambientOsc || !this.ctx) return;
    try {
      this.ambientOsc.frequency.setTargetAtTime(freq / 4, this.ctx.currentTime, 0.2);
    } catch (e) {}
  }

  public stopAmbientHum() {
    if (this.ambientOsc) {
      try {
        this.ambientOsc.stop();
        this.ambientOsc.disconnect();
      } catch (e) {}
      this.ambientOsc = null;
    }
  }
}

export const soundFx = new CyberAudioSynth();
