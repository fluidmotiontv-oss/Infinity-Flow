import React, { useState, useEffect } from 'react';
import { AgentInfo, TerpeneState, OrchestrationResult } from './types';
import { AGENTS_DATA } from './data/agents';
import { soundFx } from './utils/audioSynth';
import { CyberDragonCanvas } from './components/CyberDragonCanvas';
import { GenesisBootSequence } from './components/GenesisBootSequence';
import { AgentMeshGrid } from './components/AgentMeshGrid';
import { TerpeneModulator } from './components/TerpeneModulator';
import { Dragon9Clock } from './components/Dragon9Clock';
import { OrchestratorTerminal } from './components/OrchestratorTerminal';
import { AgentInspectorModal } from './components/AgentInspectorModal';
import {
  Network,
  Terminal,
  Sliders,
  Cpu,
  Zap,
  Activity,
  Shield,
  Volume2,
  VolumeX,
  Play,
  RotateCw,
  Clock,
  Sparkles,
  Layers,
  Flame,
  Radio,
} from 'lucide-react';

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'mesh3d' | 'agents' | 'genesis' | 'terminal' | 'terpenes'>('mesh3d');

  // Selected agent for inspection
  const [selectedAgent, setSelectedAgent] = useState<AgentInfo | null>(AGENTS_DATA[3]); // Default Agent 4 (The Cerebrum)
  const [inspectorModalAgent, setInspectorModalAgent] = useState<AgentInfo | null>(null);

  // Terpenes state (%)
  const [terpenes, setTerpenes] = useState<TerpeneState>({
    myrcene: 82, // Heavy compute / transcode
    limonene: 68, // Fast logic
    linalool: 35, // Ambient drift
    pinene: 55, // Alertness
    caryophyllene: 45, // Thermal load
  });

  // Master Dragon 9 clock calculations
  const [d9Clock, setD9Clock] = useState({
    hour: 0,
    minute: 0,
    second: 0,
    stdTime: '',
    harmonicHz: 432,
  });

  // Sound Synth state
  const [audioActive, setAudioActive] = useState<boolean>(false);

  // Terminal Logs & Orchestration State
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    '# genesis-boot.sh - Cyber Dragon Awakening Sequence on antiX Linux',
    'Phase 1: Endocrine Heartbeat initialized (D9_CLOCK, SOMATIC_IO)...',
    'Phase 2: Mounting Hippocampus (STATIC_PIN vector database)...',
    'Phase 3: Raising Immune Shields (IMMUNE_WALL phagocyte filter)...',
    'Phase 4: Igniting Dynamic Cortex (SPINAL_BUS 27-agent orchestrator)...',
    'Cyber Dragon is online. FluidmotionTV core is active.',
  ]);

  const [orchestrationResult, setOrchestrationResult] = useState<OrchestrationResult | null>(null);
  const [isOrchestrating, setIsOrchestrating] = useState<boolean>(false);

  // Add line to terminal log
  const addLog = (msg: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setTerminalLogs((prev) => [...prev, `[${timestamp}] ${msg}`]);
  };

  // Dragon 9 Clock tick
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const stdH = now.getHours();
      const stdM = now.getMinutes();
      const stdS = now.getSeconds();
      const stdStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

      const totalElapsedMinutes = stdH * 60 + stdM;
      const dHour = Math.floor(totalElapsedMinutes / 54);
      const dMin = totalElapsedMinutes % 54;
      const dSec = stdS;

      // Base Frequency modulated by Terpenes
      const baseHz = 432;
      const computedHz = baseHz + (terpenes.myrcene * 0.12) + (terpenes.limonene * 0.08) - (terpenes.linalool * 0.15);

      setD9Clock({
        hour: dHour,
        minute: dMin,
        second: dSec,
        stdTime: stdStr,
        harmonicHz: parseFloat(computedHz.toFixed(2)),
      });

      if (audioActive) {
        soundFx.updateAmbientFrequency(computedHz);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [terpenes, audioActive]);

  // Execute server-side 27-agent master orchestration
  const executeOrchestration = async (commandText: string) => {
    setIsOrchestrating(true);
    soundFx.playTone(320, 'sawtooth', 0.15);
    addLog(`C2 Cortex: Transmitting directive -> "${commandText}"`);
    addLog(`Arbitrating Quorum through Agent 13 (The Stomach) at ${d9Clock.harmonicHz}Hz harmonic rate...`);

    try {
      const res = await fetch('/api/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: commandText,
          terpeneState: terpenes,
          currentClock: `${d9Clock.hour}:${d9Clock.minute}:${d9Clock.second} Dragon Time`,
        }),
      });

      if (!res.ok) {
        throw new Error(`Orchestrator server returned status ${res.status}`);
      }

      const data: OrchestrationResult = await res.json();
      setOrchestrationResult(data);

      addLog(`Consensus resolved by ${data.agentLogs?.length || 0} active brain trust nodes.`);
      addLog(`Stomach Synthesis: "${data.stomachConsensus.substring(0, 90)}..."`);
      addLog(`Breath Broadcast Live: ${data.breathOutput.substring(0, 70)}...`);

      if (data.generatedFiles && data.generatedFiles.length > 0) {
        addLog(`Generated ${data.generatedFiles.length} runnable shell/config payload(s) for antiX Linux.`);
      }
      soundFx.playTone(600, 'sine', 0.2);
    } catch (err: any) {
      addLog(`C2 Failure: ${err.message}`);
      console.error(err);
    } finally {
      setIsOrchestrating(false);
    }
  };

  const handleToggleAudio = () => {
    const isNowPlaying = soundFx.toggleMute();
    setAudioActive(isNowPlaying);
    addLog(`432Hz Harmonic Synthesizer ${isNowPlaying ? 'ENGAGED' : 'MUTED'}`);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col font-mono text-sm antialiased relative selection:bg-emerald-500 selection:text-black">
      {/* Background Cybernetic Grid & Radial Glow */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#090d16_1px,transparent_1px),linear-gradient(to_bottom,#090d16_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none opacity-50 z-0"></div>

      {/* Top Header */}
      <header className="border-b border-slate-900 bg-slate-950/90 backdrop-blur-md px-6 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4 z-20 sticky top-0">
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-cyan-500 to-rose-500 flex items-center justify-center text-slate-950 font-black text-lg shadow-lg shadow-emerald-500/20 font-orbitron">
              <Zap size={20} className="fill-current text-slate-950" />
            </div>
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-950"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base tracking-wider font-orbitron bg-gradient-to-r from-emerald-400 via-cyan-400 to-rose-400 bg-clip-text text-transparent">
                CYBER DRAGON GENESIS
              </h1>
              <span className="text-[10px] px-2 py-0.5 rounded border border-emerald-500/40 text-emerald-300 bg-emerald-500/10 uppercase font-bold font-mono">
                antiX Linux v6.1
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans">
              27-Agent Sovereign Network & FluidmotionTV Core Orchestrator
            </p>
          </div>
        </div>

        {/* Global Telemetry Bar */}
        <div className="flex flex-wrap items-center gap-3 text-xs bg-slate-900/80 p-2 rounded-xl border border-slate-800 font-mono">
          <div className="flex items-center gap-1.5 px-2 py-0.5">
            <Clock className="text-amber-400" size={14} />
            <span className="text-slate-400">DRAGON 9:</span>
            <span className="text-amber-300 font-bold tracking-wider">
              {d9Clock.hour.toString().padStart(2, '0')}:{d9Clock.minute.toString().padStart(2, '0')}:{d9Clock.second.toString().padStart(2, '0')}
            </span>
          </div>
          <div className="h-4 w-px bg-slate-800"></div>
          <div className="flex items-center gap-1.5 px-2 py-0.5">
            <Activity className="text-rose-400 animate-pulse" size={14} />
            <span className="text-slate-400">FREQUENCY:</span>
            <span className="text-rose-300 font-bold">{d9Clock.harmonicHz} Hz</span>
          </div>
          <div className="h-4 w-px bg-slate-800"></div>
          <button
            onClick={handleToggleAudio}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition cursor-pointer font-bold ${
              audioActive
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {audioActive ? <Volume2 size={13} /> : <VolumeX size={13} />}
            <span>{audioActive ? '432Hz Synth ON' : 'Synth Muted'}</span>
          </button>
        </div>
      </header>

      {/* Navigation Bar */}
      <div className="border-b border-slate-900 bg-slate-950/60 px-6 py-2 flex items-center justify-between overflow-x-auto z-10">
        <nav className="flex items-center gap-2">
          <button
            onClick={() => {
              setActiveTab('mesh3d');
              soundFx.playTone(400, 'sine', 0.03);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-bold font-orbitron text-xs transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'mesh3d'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200'
            }`}
          >
            <Network size={13} />
            3D CYBER DRAGON MESH
          </button>

          <button
            onClick={() => {
              setActiveTab('agents');
              soundFx.playTone(440, 'sine', 0.03);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-bold font-orbitron text-xs transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'agents'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200'
            }`}
          >
            <Cpu size={13} />
            27-AGENT CORTEX
          </button>

          <button
            onClick={() => {
              setActiveTab('genesis');
              soundFx.playTone(480, 'sine', 0.03);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-bold font-orbitron text-xs transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'genesis'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200'
            }`}
          >
            <Play size={13} className="fill-current" />
            GENESIS AWAKENING
          </button>

          <button
            onClick={() => {
              setActiveTab('terminal');
              soundFx.playTone(520, 'sine', 0.03);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-bold font-orbitron text-xs transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'terminal'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200'
            }`}
          >
            <Terminal size={13} />
            C2 ORCHESTRATOR TERMINAL
          </button>

          <button
            onClick={() => {
              setActiveTab('terpenes');
              soundFx.playTone(560, 'sine', 0.03);
            }}
            className={`px-3.5 py-1.5 rounded-xl font-bold font-orbitron text-xs transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'terpenes'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900/60 text-slate-400 border border-slate-800/80 hover:text-slate-200'
            }`}
          >
            <Sliders size={13} />
            TERPENE MODULATION
          </button>
        </nav>

        <div className="hidden lg:flex items-center gap-2 text-xs font-mono text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>FluidmotionTV Core: Streaming Ready</span>
        </div>
      </div>

      {/* Main Viewport Content */}
      <main className="flex-1 p-6 z-10 max-w-7xl mx-auto w-full flex flex-col gap-6">
        {/* TAB 1: 3D CYBER DRAGON MESH VIEW */}
        {activeTab === 'mesh3d' && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* 3D Canvas Box */}
              <div className="lg:col-span-8 min-h-[460px] h-[520px]">
                <CyberDragonCanvas
                  selectedAgent={selectedAgent}
                  onSelectAgent={(agent) => {
                    setSelectedAgent(agent);
                  }}
                  activeAgents={orchestrationResult?.activeAgents}
                  isOrchestrating={isOrchestrating}
                  heartbeatHz={d9Clock.harmonicHz}
                />
              </div>

              {/* Right Column: Dragon 9 Clock & Selected Node Inspector */}
              <div className="lg:col-span-4 flex flex-col gap-5">
                <Dragon9Clock
                  d9Hour={d9Clock.hour}
                  d9Minute={d9Clock.minute}
                  d9Second={d9Clock.second}
                  stdTime={d9Clock.stdTime}
                  harmonicHz={d9Clock.harmonicHz}
                  audioActive={audioActive}
                  onToggleAudio={handleToggleAudio}
                />

                {/* Selected Agent Quick Card */}
                {selectedAgent && (
                  <div className="bg-slate-950/70 p-5 rounded-2xl border border-slate-800/80 flex flex-col justify-between gap-4 flex-1">
                    <div>
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
                        <div className="flex items-center gap-2">
                          <Cpu size={15} className="text-emerald-400" />
                          <span className="text-xs font-bold font-orbitron text-slate-200">
                            {selectedAgent.name}   {selectedAgent.codename}
                          </span>
                        </div>
                        <span
                          className="text-[9px] font-bold px-2 py-0.5 rounded border"
                          style={{
                            color: selectedAgent.color,
                            borderColor: `${selectedAgent.color}40`,
                            backgroundColor: `${selectedAgent.color}15`,
                          }}
                        >
                          {selectedAgent.chamber.split(' ')[0]}
                        </span>
                      </div>

                      <p className="text-xs text-slate-300 font-bold mb-1">{selectedAgent.role}</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-3 font-sans">
                        {selectedAgent.description}
                      </p>

                      <div className="mt-3 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 text-[10px] font-mono flex items-center justify-between">
                        <span className="text-slate-400">{selectedAgent.metricLabel}:</span>
                        <span className="text-emerald-400 font-bold font-orbitron">
                          {(selectedAgent.baseMetric * (0.97 + Math.sin(selectedAgent.id) * 0.05)).toFixed(1)} {selectedAgent.metricUnit}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setInspectorModalAgent(selectedAgent)}
                        className="flex-1 py-2 rounded-xl bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-800 text-xs font-bold font-mono transition cursor-pointer text-center"
                      >
                        Deep Diagnostics
                      </button>
                      <button
                        onClick={() => {
                          setActiveTab('terminal');
                          executeOrchestration(`Execute specialized operation on ${selectedAgent.name} (${selectedAgent.codename}) - ${selectedAgent.role}`);
                        }}
                        className="flex-1 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold font-orbitron transition cursor-pointer text-center"
                      >
                        Direct Task
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: 27-AGENT CORTEX MATRIX */}
        {activeTab === 'agents' && (
          <AgentMeshGrid
            selectedAgent={selectedAgent}
            onSelectAgent={(agent) => {
              setSelectedAgent(agent);
              setInspectorModalAgent(agent);
            }}
            onExecuteAgentAction={(agent) => {
              executeOrchestration(`Execute focused mission for ${agent.name} (${agent.codename}) - ${agent.role}`);
            }}
            activeAgents={orchestrationResult?.activeAgents}
            isOrchestrating={isOrchestrating}
          />
        )}

        {/* TAB 3: GENESIS AWAKENING SEQUENCE */}
        {activeTab === 'genesis' && (
          <GenesisBootSequence
            onBootComplete={() => {
              addLog('Cyber Dragon awakening sequence complete. Ready for high-velocity consensus.');
            }}
            onAddLog={addLog}
          />
        )}

        {/* TAB 4: C2 ORCHESTRATOR TERMINAL */}
        {activeTab === 'terminal' && (
          <OrchestratorTerminal
            onExecuteOrchestration={executeOrchestration}
            orchestrationResult={orchestrationResult}
            isOrchestrating={isOrchestrating}
            terminalLogs={terminalLogs}
          />
        )}

        {/* TAB 5: TERPENE MODULATION LAYER */}
        {activeTab === 'terpenes' && (
          <TerpeneModulator
            terpenes={terpenes}
            onChangeTerpenes={setTerpenes}
            onAddLog={addLog}
            harmonicHz={d9Clock.harmonicHz}
          />
        )}
      </main>

      {/* Deep Inspector Modal */}
      <AgentInspectorModal
        agent={inspectorModalAgent}
        onClose={() => setInspectorModalAgent(null)}
        onExecuteCommand={(cmd) => {
          setActiveTab('terminal');
          executeOrchestration(cmd);
        }}
        terpenes={terpenes}
        harmonicHz={d9Clock.harmonicHz}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 px-6 py-3 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 z-10 font-mono">
        <div>Sovereign Mesh Node  antiX Linux & Termux Sandbox Standards</div>
        <div className="flex items-center gap-4">
          <span>Dragon 9 Clock: 54m Hour Sync</span>
          <span className="text-emerald-400">FluidmotionTV Playout Active</span>
        </div>
      </footer>
    </div>
  );
}
