import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Radio,
  Zap,
  Activity,
  Layers,
  Shield,
  Terminal,
  CheckCircle2,
  RefreshCw,
  Play,
  Pause,
  Server,
  Network,
  Globe
} from 'lucide-react';
import { DragonTheme, AudioReactiveState } from '../types';

export interface AgentNode {
  id: string;
  name: string;
  core: 'D9_CORE_9' | 'OMEGA_CORE_27';
  status: 'ACTIVE' | 'SYNCHRONIZING' | 'STANDBY' | 'OPTIMIZING';
  load: number; // percentage 10 - 95
  latencyMs: number;
  fps: number;
  description: string;
}

const INITIAL_AGENTS: AgentNode[] = [
  // D9 9-Agent Core
  { id: 'd9-1', name: '432Hz Audio Synthesizer', core: 'D9_CORE_9', status: 'ACTIVE', load: 38, latencyMs: 2.1, fps: 60, description: 'Generative harmonic drone and mic frequency reactivity.' },
  { id: 'd9-2', name: 'Mandible Jaw Mechanics', core: 'D9_CORE_9', status: 'ACTIVE', load: 45, latencyMs: 1.8, fps: 60, description: 'RMS formants and asymmetric spring interpolation.' },
  { id: 'd9-3', name: 'Companion Telemetry Node', core: 'D9_CORE_9', status: 'ACTIVE', load: 22, latencyMs: 3.4, fps: 60, description: 'Asset timestamp tracking and companion JSON sync.' },
  { id: 'd9-4', name: 'Blender 3D Rig Exporter', core: 'D9_CORE_9', status: 'ACTIVE', load: 15, latencyMs: 4.1, fps: 60, description: 'Keyframe baking and armature hierarchy mapping.' },
  { id: 'd9-5', name: 'Sacred Geometry Skin Mapper', core: 'D9_CORE_9', status: 'ACTIVE', load: 52, latencyMs: 2.5, fps: 60, description: 'Modular skin layers and 11/222 sigil lattice projection.' },
  { id: 'd9-6', name: 'Infinity Flow Particle Engine', core: 'D9_CORE_9', status: 'ACTIVE', load: 68, latencyMs: 1.9, fps: 60, description: 'GPU dust simulation and vortex vector noise.' },
  { id: 'd9-7', name: 'Stream HUD & Chroma Compositor', core: 'D9_CORE_9', status: 'ACTIVE', load: 31, latencyMs: 2.2, fps: 60, description: 'OBS overlay, chat simulation, and chroma keying.' },
  { id: 'd9-8', name: 'Automated Pipeline Orchestrator', core: 'D9_CORE_9', status: 'ACTIVE', load: 41, latencyMs: 3.0, fps: 60, description: 'Manifest parsing and task scheduling.' },
  { id: 'd9-9', name: 'Quantum Sync Master Clock', core: 'D9_CORE_9', status: 'ACTIVE', load: 18, latencyMs: 0.8, fps: 60, description: '60fps render loop and cross-agent heartbeat.' },

  // Omega 27-Agent Expanded Swarm
  { id: 'om-1', name: 'Voice Auto-Ducking Subroutine', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 25, latencyMs: 1.5, fps: 60, description: 'Dynamic soundscape compression during active speech.' },
  { id: 'om-2', name: 'Volumetric Lighting Evaluator', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 60, latencyMs: 4.2, fps: 60, description: 'Studio preset environment and soft shadow casting.' },
  { id: 'om-3', name: 'Facial Morph Expression Mesh', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 33, latencyMs: 2.0, fps: 60, description: 'Idle, talk, roar, shield, and alert stance interpolator.' },
  { id: 'om-4', name: 'PWA Offline Cache Guardian', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 12, latencyMs: 5.0, fps: 60, description: 'Service worker asset caching and local persistence.' },
  { id: 'om-5', name: 'Firestore Realtime Sync', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 28, latencyMs: 12.4, fps: 60, description: 'Cross-device state replication and rules validation.' },
  { id: 'om-6', name: 'Multi-Camera Viewport Router', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 44, latencyMs: 2.1, fps: 60, description: 'Storefront vs. Fern Gallery camera transitions.' },
  { id: 'om-7', name: 'Shader Uniform Optimizer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 35, latencyMs: 1.1, fps: 60, description: 'WebGL memory management and draw call batching.' },
  { id: 'om-8', name: 'Dragon Breath Particle Emitter', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 55, latencyMs: 2.8, fps: 60, description: 'Roar threshold trigger and energy burst overlay.' },
  { id: 'om-9', name: 'Holographic Pedestal Renderer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 40, latencyMs: 2.4, fps: 60, description: 'Cylindrical base grid and floating ring projection.' },
  { id: 'om-10', name: 'Matrix Code Rain Streamer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 30, latencyMs: 1.7, fps: 60, description: 'Cybernetic background glyph waterfall.' },
  { id: 'om-11', name: 'Audio Spectrum FFT Analyzer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 48, latencyMs: 1.4, fps: 60, description: '32-band frequency bin extraction.' },
  { id: 'om-12', name: 'Noise Gate Gatekeeper', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 15, latencyMs: 0.9, fps: 60, description: 'Audio threshold filter and sibilance suppression.' },
  { id: 'om-13', name: 'Flight Physics Inertia Engine', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 42, latencyMs: 2.2, fps: 60, description: 'Velocity, acceleration, and aerodynamic drag math.' },
  { id: 'om-14', name: 'Infinity Path Calculator', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 26, latencyMs: 1.6, fps: 60, description: 'Lissajous curve and lemniscate trajectory generator.' },
  { id: 'om-15', name: 'Asset Version Vault Registrar', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 19, latencyMs: 3.2, fps: 60, description: 'PNG model version indexing and manifest sync.' },
  { id: 'om-16', name: 'Modular Skin Layer Blending', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 50, latencyMs: 2.7, fps: 60, description: 'Screen, overlay, and color-dodge composite pipeline.' },
  { id: 'om-17', name: 'ElevenLabs Speech Pipeline', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 22, latencyMs: 18.5, fps: 60, description: 'Neural voice synthesis integration bridge.' },
  { id: 'om-18', name: 'Smart Object Web Component Bridge', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 20, latencyMs: 3.1, fps: 60, description: 'Custom element encapsulation and Shadow DOM support.' },
  { id: 'om-19', name: 'OBS Setup Guide Supervisor', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 10, latencyMs: 1.0, fps: 60, description: 'Window capture instructions and telemetry tips.' },
  { id: 'om-20', name: 'Theme & Chroma Customizer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 14, latencyMs: 1.2, fps: 60, description: 'Dynamic CSS variable injection for color palettes.' },
  { id: 'om-21', name: 'Recording & Export Controller', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 38, latencyMs: 4.5, fps: 60, description: 'WebM video stream recording and buffer management.' },
  { id: 'om-22', name: 'Expression Stance Orchestrator', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 25, latencyMs: 1.8, fps: 60, description: 'Manual stance selector and audio reactivity override.' },
  { id: 'om-23', name: 'Telemetry Log Serializer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 16, latencyMs: 2.4, fps: 60, description: 'JSON serialization for companion suite telemetry.' },
  { id: 'om-24', name: 'Memory Garbage Collector', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 11, latencyMs: 6.0, fps: 60, description: 'Texture and audio buffer disposal.' },
  { id: 'om-25', name: 'Sub-Bass Resonance Harmonizer', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 29, latencyMs: 1.3, fps: 60, description: '108Hz sub-bass and 432Hz master tuning verification.' },
  { id: 'om-26', name: 'Network Latency Monitor', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 12, latencyMs: 1.1, fps: 60, description: 'Ping and round-trip telemetry verification.' },
  { id: 'om-27', name: 'Master Swarm Sentinel', core: 'OMEGA_CORE_27', status: 'ACTIVE', load: 45, latencyMs: 0.5, fps: 60, description: 'Failover watchdog and autonomous recovery loop.' }
];

interface MultiAgentCoreHubProps {
  theme: DragonTheme;
  audioState: AudioReactiveState;
}

export const MultiAgentCoreHub: React.FC<MultiAgentCoreHubProps> = ({ theme, audioState }) => {
  const [agents, setAgents] = useState<AgentNode[]>(INITIAL_AGENTS);
  const [selectedCore, setSelectedCore] = useState<'ALL' | 'D9_CORE_9' | 'OMEGA_CORE_27'>('ALL');
  const [isSwarmActive, setIsSwarmActive] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Simulate dynamic load fluctuations
  useEffect(() => {
    if (!isSwarmActive) return;
    const interval = setInterval(() => {
      setAgents(prev =>
        prev.map(agent => ({
          ...agent,
          load: Math.min(95, Math.max(10, agent.load + Math.floor(Math.random() * 9) - 4)),
          latencyMs: parseFloat(Math.max(0.5, agent.latencyMs + (Math.random() * 0.4 - 0.2)).toFixed(1))
        }))
      );
    }, 1500);
    return () => clearInterval(interval);
  }, [isSwarmActive]);

  const filteredAgents = agents.filter(agent => {
    const matchesCore = selectedCore === 'ALL' || agent.core === selectedCore;
    const matchesSearch = agent.name.toLowerCase().includes(searchTerm.toLowerCase()) || agent.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCore && matchesSearch;
  });

  const d9Count = agents.filter(a => a.core === 'D9_CORE_9').length;
  const omegaCount = agents.filter(a => a.core === 'OMEGA_CORE_27').length;
  const avgLoad = Math.round(agents.reduce((acc, curr) => acc + curr.load, 0) / agents.length);
  const avgLatency = (agents.reduce((acc, curr) => acc + curr.latencyMs, 0) / agents.length).toFixed(1);

  return (
    <div className="w-full bg-slate-950/95 rounded-2xl border border-slate-800 p-6 backdrop-blur-xl shadow-2xl text-slate-100 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border border-cyan-500/40 text-cyan-400">
            <Network className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent flex items-center gap-2">
              Dragon 9 (9-Agent) + Omega (27-Agent) Neural Swarm
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                36 Agents Synchronized
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Integrated multi-agent execution pipeline combining D9 Core orchestrator and Omega-27 expanded neural swarm.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSwarmActive(!isSwarmActive)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono border flex items-center gap-1.5 transition-colors cursor-pointer ${
              isSwarmActive
                ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                : 'bg-amber-950/60 border-amber-500/50 text-amber-300'
            }`}
          >
            {isSwarmActive ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            {isSwarmActive ? 'Swarm Active (36/36)' : 'Swarm Paused'}
          </button>
        </div>
      </div>

      {/* Telemetry Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-slate-500 text-[10px] block">TOTAL AGENTS</span>
          <span className="text-2xl font-bold text-cyan-300 mt-1 block">36</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">9 D9 Core + 27 Omega</span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-slate-500 text-[10px] block">AVERAGE CPU LOAD</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{avgLoad}%</span>
          <span className="text-[10px] text-emerald-500 mt-0.5 block">● Optimized 60 FPS</span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-slate-500 text-[10px] block">AVERAGE LATENCY</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">{avgLatency} ms</span>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Real-time WebSocket</span>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-slate-500 text-[10px] block">AUDIO SYNC HZ</span>
          <span className="text-2xl font-bold text-purple-300 mt-1 block">432 Hz</span>
          <span className="text-[10px] text-purple-400 mt-0.5 block">Harmonic Locked</span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          <button
            onClick={() => setSelectedCore('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
              selectedCore === 'ALL'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/60'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            All Agents (36)
          </button>
          <button
            onClick={() => setSelectedCore('D9_CORE_9')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
              selectedCore === 'D9_CORE_9'
                ? 'bg-amber-950 text-amber-300 border border-amber-500/60'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            D9 Core (9)
          </button>
          <button
            onClick={() => setSelectedCore('OMEGA_CORE_27')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
              selectedCore === 'OMEGA_CORE_27'
                ? 'bg-purple-950 text-purple-300 border border-purple-500/60'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            Omega Core (27)
          </button>
        </div>

        <div className="w-full sm:w-64">
          <input
            type="text"
            placeholder="Search agent subroutines..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
          />
        </div>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[500px] overflow-y-auto pr-1">
        {filteredAgents.map((agent) => {
          const isD9 = agent.core === 'D9_CORE_9';
          return (
            <div
              key={agent.id}
              className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between gap-3 group"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase border ${
                      isD9
                        ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                        : 'bg-purple-500/10 text-purple-300 border-purple-500/30'
                    }`}>
                      {isD9 ? 'D9 Core' : 'Omega-27'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{agent.id}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-200 mt-1 group-hover:text-cyan-300 transition-colors">
                    {agent.name}
                  </h4>
                </div>
                <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" />
                  {agent.status}
                </span>
              </div>

              <p className="text-xs text-slate-400 line-clamp-2">
                {agent.description}
              </p>

              {/* Load & Latency stats */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800/80 font-mono text-xs">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">CPU Load</span>
                  <span className={agent.load > 70 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {agent.load}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      agent.load > 70 ? 'bg-amber-500' : 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                    }`}
                    style={{ width: `${agent.load}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>Latency: {agent.latencyMs}ms</span>
                  <span>Frame Rate: {agent.fps} FPS</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MultiAgentCoreHub;
