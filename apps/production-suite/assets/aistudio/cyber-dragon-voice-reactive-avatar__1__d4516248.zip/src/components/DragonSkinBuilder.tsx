import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Layers,
  Wand2,
  Sliders,
  Maximize2,
  RotateCcw,
  Check,
  ChevronRight,
  ChevronLeft,
  Eye,
  Download,
  Share2,
  Shield,
  Zap,
  Activity,
  Cpu,
  Palette,
  Box
} from 'lucide-react';
import { DragonTheme } from '../types';

export interface SkinLayer {
  id: string;
  name: string;
  category: 'chassis' | 'scales' | 'sigil' | 'aura';
  imagePath: string;
  opacity: number; // 0 to 1
  blendMode: 'normal' | 'screen' | 'overlay' | 'color-dodge';
  pulseSpeed: number; // 0 (static) to 2 (fast)
  scale: number; // 1 to 2x close up zoom
  enabled: boolean;
  color: string;
  description: string;
}

const DEFAULT_SKIN_LAYERS: SkinLayer[] = [
  {
    id: 'base-obsidian',
    name: 'Obsidian Metallic Plating',
    category: 'chassis',
    imagePath: '/src/assets/images/super_puff_v2_1790288586379.jpg',
    opacity: 1.0,
    blendMode: 'normal',
    pulseSpeed: 0,
    scale: 1.0,
    enabled: true,
    color: '#0f172a',
    description: 'High-density cybernetic titanium alloy base frame.'
  },
  {
    id: 'close-scales',
    name: 'Cyber Scale Close-Up',
    category: 'scales',
    imagePath: '/src/assets/images/cyber_dragon_closeup_skin_1790289159031.jpg',
    opacity: 0.85,
    blendMode: 'overlay',
    pulseSpeed: 0.5,
    scale: 1.25,
    enabled: true,
    color: '#06b6d4',
    description: 'Macro scale texture with 432Hz conductive micro-channels.'
  },
  {
    id: 'sacred-lattice-222',
    name: 'Sacred Geometry Diamond Lattice (222)',
    category: 'sigil',
    imagePath: '/src/assets/images/cyber_dragon_sacred_lattice_1790289176610.jpg',
    opacity: 0.9,
    blendMode: 'screen',
    pulseSpeed: 1.0,
    scale: 1.4,
    enabled: true,
    color: '#10b981',
    description: 'Harmonic 222 diamond crystal matrix mapped onto skin layers.'
  },
  {
    id: 'head-emblem-11',
    name: 'Cyber Sigil Forehead Emblem (11)',
    category: 'sigil',
    imagePath: '/src/assets/images/cyber_dragon_head_closeup_1790289191758.jpg',
    opacity: 0.95,
    blendMode: 'screen',
    pulseSpeed: 1.2,
    scale: 1.1,
    enabled: true,
    color: '#f59e0b',
    description: 'Close-up head armor with 11 intersecting sacred geometry cross sigil.'
  }
];

interface DragonSkinBuilderProps {
  theme: DragonTheme;
  onApplySkinManifest?: (manifest: any) => void;
}

export const DragonSkinBuilder: React.FC<DragonSkinBuilderProps> = ({
  theme,
  onApplySkinManifest
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [layers, setLayers] = useState<SkinLayer[]>(DEFAULT_SKIN_LAYERS);
  const [selectedLayerId, setSelectedLayerId] = useState<string>('close-scales');
  const [zoomLevel, setZoomLevel] = useState<number>(1.2); // Close up zoom slider
  const [showSigilOverlay, setShowSigilOverlay] = useState<boolean>(true);
  const [isAnimating, setIsAnimating] = useState<boolean>(true);
  const [copiedManifest, setCopiedManifest] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'macro' | 'full' | 'split'>('split');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Update selected layer property
  const updateLayerProp = <K extends keyof SkinLayer>(id: string, key: K, val: SkinLayer[K]) => {
    setLayers(prev => prev.map(l => l.id === id ? { ...l, [key]: val } : l));
  };

  const selectedLayer = layers.find(l => l.id === selectedLayerId) || layers[0];

  // Animate custom canvas with moving layered skins & sacred geometry lines
  useEffect(() => {
    let animId: number;
    let startTime = performance.now();

    const render = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      const ctx = canvasRef.current?.getContext('2d');
      if (ctx && canvasRef.current) {
        const width = canvasRef.current.width;
        const height = canvasRef.current.height;

        // Clear dark background
        ctx.fillStyle = '#030712';
        ctx.fillRect(0, 0, width, height);

        // Draw animated background grid lines
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.6)';
        ctx.lineWidth = 1;
        const gridSize = 30;
        for (let x = 0; x < width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, height);
          ctx.stroke();
        }
        for (let y = 0; y < height; y += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }

        // Render Sacred Geometry Live Overlay lines (Sigils from 11.png and 222.png)
        if (showSigilOverlay) {
          const centerX = width / 2;
          const centerY = height / 2;
          const pulse = isAnimating ? Math.sin(elapsed * 2) * 0.15 + 0.85 : 1;

          ctx.save();
          ctx.translate(centerX, centerY);
          ctx.scale(pulse * zoomLevel, pulse * zoomLevel);

          // Render 222 Diamond Lattice
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.7)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(0, -90);
          ctx.lineTo(90, 0);
          ctx.lineTo(0, 90);
          ctx.lineTo(-90, 0);
          ctx.closePath();
          ctx.stroke();

          // Inverted Diamond
          ctx.strokeStyle = 'rgba(245, 158, 11, 0.8)';
          ctx.beginPath();
          ctx.moveTo(0, 90);
          ctx.lineTo(60, -40);
          ctx.lineTo(-60, -40);
          ctx.closePath();
          ctx.stroke();

          // Intersecting 11 Cross lines
          ctx.strokeStyle = 'rgba(16, 185, 129, 0.8)';
          ctx.beginPath();
          ctx.moveTo(-110, -110);
          ctx.lineTo(110, 110);
          ctx.moveTo(110, -110);
          ctx.lineTo(-110, 110);
          ctx.stroke();

          ctx.restore();
        }
      }

      if (isAnimating) {
        animId = requestAnimationFrame(render);
      }
    };

    render(performance.now());
    return () => cancelAnimationFrame(animId);
  }, [showSigilOverlay, isAnimating, zoomLevel, layers]);

  const handleCopyManifest = () => {
    const customSkinManifest = {
      builder: 'Build-Your-Dragon Step-by-Step Engine',
      timestamp: new Date().toISOString(),
      tuningHz: 432,
      zoomLevel,
      activeLayers: layers.filter(l => l.enabled).map(l => ({
        id: l.id,
        name: l.name,
        opacity: l.opacity,
        blendMode: l.blendMode,
        pulseSpeed: l.pulseSpeed,
        scale: l.scale,
        color: l.color
      })),
      sacredGeometrySigils: {
        sigil_11_cross: 'ENABLED',
        sigil_222_diamond_lattice: 'ENABLED',
        closeUpSkinDisplacement: 'ENABLED'
      }
    };

    navigator.clipboard.writeText(JSON.stringify(customSkinManifest, null, 2));
    setCopiedManifest(true);
    setTimeout(() => setCopiedManifest(false), 2000);

    if (onApplySkinManifest) {
      onApplySkinManifest(customSkinManifest);
    }
  };

  return (
    <div className="w-full bg-slate-950/90 rounded-2xl border border-slate-800 p-6 backdrop-blur-xl shadow-2xl text-slate-100 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/20 to-cyan-500/20 border border-amber-500/40 text-amber-400">
            <Wand2 className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-amber-400 via-cyan-300 to-emerald-400 bg-clip-text text-transparent flex items-center gap-2">
              Build Your Dragon: Step-by-Step Modular Skin Studio
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                Close-Up Sacred Geometry Mapping
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Combine close-up macro scale textures with sacred geometry sigils (11 & 222 diamond lattice) across separate moving skin layers.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAnimating(!isAnimating)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono border flex items-center gap-1.5 transition-colors ${
              isAnimating
                ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            {isAnimating ? 'Skin Movement ON' : 'Skin Movement Paused'}
          </button>

          <button
            onClick={handleCopyManifest}
            className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-cyan-600 hover:from-amber-400 hover:to-cyan-500 text-xs font-bold text-slate-950 flex items-center gap-1.5 shadow-lg shadow-amber-950/50 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            {copiedManifest ? 'Manifest Applied!' : 'Export Dragon Skin'}
          </button>
        </div>
      </div>

      {/* Step Wizard Progress Bar */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { step: 1, title: '1. Chassis Base', icon: Shield },
          { step: 2, title: '2. Macro Scale Skin', icon: Layers },
          { step: 3, title: '3. Sacred Sigil 11/222', icon: Sparkles },
          { step: 4, title: '4. Final Assembly', icon: Box }
        ].map((s) => {
          const Icon = s.icon;
          const isActive = activeStep === s.step;
          const isPassed = activeStep > s.step;
          return (
            <button
              key={s.step}
              onClick={() => setActiveStep(s.step)}
              className={`p-3 rounded-xl border text-left transition-all flex items-center gap-2 cursor-pointer ${
                isActive
                  ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-950'
                  : isPassed
                  ? 'bg-slate-900/80 border-emerald-500/40 text-emerald-400'
                  : 'bg-slate-900/40 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              <div className={`p-1.5 rounded-lg ${isActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'}`}>
                <Icon className="w-4 h-4" />
              </div>
              <span className="text-xs font-semibold truncate">{s.title}</span>
            </button>
          );
        })}
      </div>

      {/* Main Studio Area: Left Visual Canvas / Right Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Canvas & Close-Up Skin Viewport */}
        <div className="lg:col-span-7 bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-200">Interactive Skin Layer Viewport</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {zoomLevel.toFixed(1)}x Macro Zoom
              </span>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs font-mono text-slate-400 flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showSigilOverlay}
                  onChange={(e) => setShowSigilOverlay(e.target.checked)}
                  className="rounded bg-slate-800 border-slate-700 text-cyan-500 focus:ring-0"
                />
                Sacred Lines (11 / 222)
              </label>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-[10px] font-mono">
                {(['macro', 'full', 'split'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`px-2 py-0.5 rounded uppercase ${
                      viewMode === mode ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Canvas Composite Stack */}
          <div className="relative rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 aspect-video group">
            {/* Base Image Layer */}
            {layers.map((layer) => {
              if (!layer.enabled) return null;
              return (
                <img
                  key={layer.id}
                  src={layer.imagePath}
                  alt={layer.name}
                  referrerPolicy="no-referrer"
                  style={{
                    opacity: layer.opacity,
                    mixBlendMode: layer.blendMode,
                    transform: `scale(${layer.scale * (zoomLevel / 1.2)})`,
                    filter: `drop-shadow(0 0 12px ${layer.color}40)`
                  }}
                  className="absolute inset-0 w-full h-full object-cover transition-all duration-300"
                />
              );
            })}

            {/* Sacred Geometry Canvas Overlay */}
            <canvas
              ref={canvasRef}
              width={640}
              height={360}
              className="absolute inset-0 w-full h-full pointer-events-none mix-blend-screen opacity-80"
            />

            {/* Viewport Floating Info */}
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/70 border border-slate-800 backdrop-blur-md text-[10px] font-mono text-cyan-300 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>ACTIVE SKIN DISPLACEMENT: MULTI-LAYER 432Hz</span>
            </div>

            {/* Close-Up Zoom Slider Tool */}
            <div className="absolute bottom-3 left-3 right-3 p-2 rounded-xl bg-black/80 border border-slate-800 backdrop-blur-md flex items-center gap-3">
              <span className="text-[10px] font-mono text-slate-400 shrink-0">MACRO ZOOM:</span>
              <input
                type="range"
                min="1.0"
                max="2.5"
                step="0.1"
                value={zoomLevel}
                onChange={(e) => setZoomLevel(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-xs font-mono text-cyan-400 w-10 text-right">{zoomLevel.toFixed(1)}x</span>
            </div>
          </div>

          {/* Skin Layers Stack Status List */}
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Modular Moving Skin Layers</span>
              <span className="text-[10px] text-emerald-400 font-mono">{layers.filter(l => l.enabled).length} Active</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {layers.map((layer) => (
                <div
                  key={layer.id}
                  onClick={() => setSelectedLayerId(layer.id)}
                  className={`p-2 rounded-lg border text-xs font-mono transition-all cursor-pointer flex flex-col justify-between ${
                    selectedLayerId === layer.id
                      ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold truncate">{layer.name}</span>
                    <input
                      type="checkbox"
                      checked={layer.enabled}
                      onChange={(e) => updateLayerProp(layer.id, 'enabled', e.target.checked)}
                      onClick={(e) => e.stopPropagation()}
                      className="rounded bg-slate-800 border-slate-700 text-cyan-500"
                    />
                  </div>
                  <div className="flex items-center justify-between text-[9px] text-slate-500 mt-2">
                    <span>Opacity: {Math.round(layer.opacity * 100)}%</span>
                    <span style={{ color: layer.color }}>● {layer.blendMode}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Step Configurator Controls */}
        <div className="lg:col-span-5 bg-slate-900/80 rounded-xl border border-slate-800 p-5 space-y-5">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-amber-400 uppercase">STEP {activeStep} OF 4</span>
              <h3 className="text-base font-bold text-slate-100">
                {activeStep === 1 && 'Select Chassis & Base Scale Armor'}
                {activeStep === 2 && 'Adjust Macro Close-Up Scale Details'}
                {activeStep === 3 && 'Map Sacred Geometry Sigils (11 / 222)'}
                {activeStep === 4 && 'Finalize Dragon Assembly & Export'}
              </h3>
            </div>
          </div>

          {/* Layer Customization Panel */}
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-cyan-300 flex items-center justify-between">
                <span>Selected Skin Layer: {selectedLayer.name}</span>
                <span className="text-[10px] font-mono text-slate-500">{selectedLayer.category}</span>
              </span>
              <p className="text-xs text-slate-400">{selectedLayer.description}</p>
            </div>

            {/* Opacity Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Layer Opacity</span>
                <span className="text-cyan-400">{Math.round(selectedLayer.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={selectedLayer.opacity}
                onChange={(e) => updateLayerProp(selectedLayer.id, 'opacity', parseFloat(e.target.value))}
                className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Blend Mode */}
            <div className="space-y-1">
              <span className="text-xs font-mono text-slate-400 block">Blend Mode</span>
              <div className="grid grid-cols-2 gap-2">
                {(['normal', 'screen', 'overlay', 'color-dodge'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => updateLayerProp(selectedLayer.id, 'blendMode', mode)}
                    className={`py-1.5 px-2 rounded text-xs font-mono border uppercase transition-colors ${
                      selectedLayer.blendMode === mode
                        ? 'bg-cyan-950 border-cyan-500 text-cyan-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Pulse Speed */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">Skin Movement / Pulse Speed</span>
                <span className="text-amber-400">{selectedLayer.pulseSpeed.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0"
                max="2.0"
                step="0.1"
                value={selectedLayer.pulseSpeed}
                onChange={(e) => updateLayerProp(selectedLayer.id, 'pulseSpeed', parseFloat(e.target.value))}
                className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Energy Color Picker */}
            <div className="space-y-1">
              <span className="text-xs font-mono text-slate-400 block">Layer Energy Color</span>
              <div className="flex items-center gap-2">
                {['#06b6d4', '#10b981', '#f59e0b', '#a855f7', '#ef4444', '#3b82f6'].map((hex) => (
                  <button
                    key={hex}
                    onClick={() => updateLayerProp(selectedLayer.id, 'color', hex)}
                    style={{ backgroundColor: hex }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform ${
                      selectedLayer.color === hex ? 'scale-110 border-white shadow-lg' : 'border-transparent opacity-80 hover:opacity-100'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800">
            <button
              disabled={activeStep === 1}
              onClick={() => setActiveStep(prev => Math.max(1, prev - 1))}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-300 disabled:opacity-40 flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" /> Previous
            </button>

            <button
              disabled={activeStep === 4}
              onClick={() => setActiveStep(prev => Math.min(4, prev + 1))}
              className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-mono font-bold text-white flex items-center gap-1 shadow-md shadow-cyan-950"
            >
              Next Step <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DragonSkinBuilder;
