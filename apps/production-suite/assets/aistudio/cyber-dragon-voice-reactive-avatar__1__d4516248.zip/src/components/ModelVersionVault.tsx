import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  CheckCircle2,
  Download,
  Eye,
  FileCode,
  Shield,
  Activity,
  Cpu,
  Clock,
  Radio,
  Share2,
  Box,
  Image as ImageIcon
} from 'lucide-react';
import { DragonTheme } from '../types';

export interface ModelVersion {
  id: string;
  version: string;
  name: string;
  codename: string;
  imagePath: string;
  aspectRatio: string;
  renderEngine: string;
  tuningHz: number;
  polygonCount: string;
  createdTimestamp: string;
  description: string;
  status: 'STABLE_RELEASE' | 'PROTOTYPE' | 'EXPERIMENTAL' | 'DEPRECATED';
  tags: string[];
  specs: {
    resolution: string;
    jawRigType: string;
    particleSystem: string;
    audioReactivity: string;
  };
}

export const INITIAL_MODEL_VERSIONS: ModelVersion[] = [
  {
    id: 'puff-v1',
    version: 'v1.0.4',
    name: 'Super Puff - Classic Cyber Edition',
    codename: 'ORIGIN_PUFF',
    imagePath: '/src/assets/images/super_puff_v1_1790288568508.jpg',
    aspectRatio: '1:1 PNG Render',
    renderEngine: 'Blender EEVEE Next / WebGL2',
    tuningHz: 432,
    polygonCount: '48.5K tris',
    createdTimestamp: '2026-09-24 14:15:00 UTC',
    description: 'The original 3-minute pilot model with vibrant neon cyber scales, responsive jaw mechanic, and 432Hz harmonic soundwave aura.',
    status: 'STABLE_RELEASE',
    tags: ['432Hz', 'Cyber', 'Pilot Model', 'Jaw-Rigged'],
    specs: {
      resolution: '2048 x 2048 PNG',
      jawRigType: 'Parametric Audio-Bones',
      particleSystem: 'EnergyDust GPU Sprites',
      audioReactivity: 'Sub-Bass & Peak Gating'
    }
  },
  {
    id: 'puff-v2',
    version: 'v2.1.0',
    name: 'Super Puff - Mech Holographic Apex',
    codename: 'MECH_HERO',
    imagePath: '/src/assets/images/super_puff_v2_1790288586379.jpg',
    aspectRatio: '1:1 PNG Render',
    renderEngine: 'Cycles X / Hardware Raytracing',
    tuningHz: 432,
    polygonCount: '124.8K tris',
    createdTimestamp: '2026-09-24 15:23:00 UTC',
    description: 'Sleek holographic armor plating with high-mobility cybernetic wings and real-time audio-driven particle thrusters.',
    status: 'STABLE_RELEASE',
    tags: ['432Hz', 'Holo-Armor', 'High-Poly', 'Obsidian Mech'],
    specs: {
      resolution: '2048 x 2048 PNG',
      jawRigType: 'Dual-Axis Hydrolink Rig',
      particleSystem: 'InfinityFlow Vector Noise',
      audioReactivity: 'Full-Spectrum FFT (32-Bands)'
    }
  },
  {
    id: 'puff-v3',
    version: 'v3.0.0-alpha',
    name: 'Super Puff - Elemental Resonance',
    codename: 'HARMONIC_GOD',
    imagePath: '/src/assets/images/super_puff_v3_1790288602970.jpg',
    aspectRatio: '1:1 PNG Render',
    renderEngine: 'Unreal Engine 5.4 / Procedural Shaders',
    tuningHz: 432,
    polygonCount: '210.0K tris',
    createdTimestamp: '2026-09-24 15:23:25 UTC',
    description: 'Obsidian organic skin infused with gold 432Hz harmonic frequency veins and glowing sonic pulse halo.',
    status: 'EXPERIMENTAL',
    tags: ['432Hz', 'Elemental', 'Sonic Halo', 'Sub-Bass Veins'],
    specs: {
      resolution: '4096 x 4096 PNG',
      jawRigType: 'Volumetric Muscle Morph',
      particleSystem: 'DragonBreath Flame GPU Mesh',
      audioReactivity: 'Resonant Formant Tracking'
    }
  },
  {
    id: 'dragon9-node',
    version: 'v9.4.2',
    name: 'Dragon 9 - Pipeline Orchestrator Core',
    codename: 'MASTER_ENGINE',
    imagePath: '/src/assets/images/dragon9_pipeline_asset_1790288616356.jpg',
    aspectRatio: '16:9 Banner Asset',
    renderEngine: 'Isometric Render Engine',
    tuningHz: 432,
    polygonCount: '86.2K tris',
    createdTimestamp: '2026-09-24 15:23:40 UTC',
    description: 'The master telemetry orchestrator node managing audio-visual sync, asset rendering, and Companion logger nodes.',
    status: 'STABLE_RELEASE',
    tags: ['Orchestrator', 'Telemetry', 'ES Module', '432Hz Verified'],
    specs: {
      resolution: '3840 x 2160 PNG',
      jawRigType: 'N/A (Pipeline Core)',
      particleSystem: 'Node Network Telemetry Rays',
      audioReactivity: 'Master Clock Sync'
    }
  }
];

interface ModelVersionVaultProps {
  theme: DragonTheme;
  activeModelId?: string;
  onSelectModel?: (model: ModelVersion) => void;
}

export const ModelVersionVault: React.FC<ModelVersionVaultProps> = ({
  theme,
  activeModelId = 'puff-v1',
  onSelectModel
}) => {
  const [selectedModel, setSelectedModel] = useState<ModelVersion>(
    INITIAL_MODEL_VERSIONS.find(m => m.id === activeModelId) || INITIAL_MODEL_VERSIONS[0]
  );
  const [copiedManifest, setCopiedManifest] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);

  const handleSelect = (model: ModelVersion) => {
    setSelectedModel(model);
    onSelectModel?.(model);
  };

  const copyManifestJson = () => {
    const manifestSnippet = JSON.stringify({
      version: selectedModel.version,
      name: selectedModel.name,
      codename: selectedModel.codename,
      imageAsset: selectedModel.imagePath,
      audioTuningHz: selectedModel.tuningHz,
      specs: selectedModel.specs,
      pipelineConfig: {
        orchestratorNode: 'Dragon9-Master',
        companionTelemetry: true,
        renderEngine: selectedModel.renderEngine
      }
    }, null, 2);

    navigator.clipboard.writeText(manifestSnippet);
    setCopiedManifest(true);
    setTimeout(() => setCopiedManifest(false), 2000);
  };

  return (
    <div className="w-full bg-slate-950/90 rounded-2xl border border-slate-800 p-6 backdrop-blur-xl shadow-2xl text-slate-100 space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-cyan-500/20 to-indigo-500/20 border border-cyan-500/30 text-cyan-400">
            <Layers className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent flex items-center gap-2">
              Model Version Vault & Asset Registry
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                432Hz Synchronized
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Version control, telemetry inspection, and high-res model PNG preview assets for Dragon 9 & Super Puff.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Companion Logger Active
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
            4 Models Versioned
          </span>
        </div>
      </div>

      {/* Main Grid: Left List / Right Active Inspection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Model Selector List */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Generated Model Versions</span>
            <span className="text-[10px] text-cyan-400 font-mono">PNG / Manifest</span>
          </h3>

          <div className="space-y-3">
            {INITIAL_MODEL_VERSIONS.map((model) => {
              const isSelected = selectedModel.id === model.id;
              return (
                <div
                  key={model.id}
                  onClick={() => handleSelect(model)}
                  className={`group relative p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-4 ${
                    isSelected
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-lg shadow-cyan-950/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  {/* Thumbnail */}
                  <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-700/80 bg-slate-950 shrink-0">
                    <img
                      src={model.imagePath}
                      alt={model.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    <span className="absolute bottom-0.5 right-1 text-[9px] font-mono px-1 rounded bg-black/80 text-cyan-300 border border-cyan-500/30">
                      {model.version}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className={`text-sm font-semibold truncate ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                        {model.name}
                      </h4>
                      {isSelected && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shrink-0">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">{model.codename} • {model.polygonCount}</p>
                    <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                        {model.tuningHz}Hz
                      </span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                        {model.status}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Model Detail & Full Inspection */}
        <div className="lg:col-span-7 bg-slate-900/80 rounded-xl border border-slate-800 p-5 space-y-5">
          <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {selectedModel.version}
                </span>
                <span className="text-xs font-mono text-slate-400">{selectedModel.codename}</span>
              </div>
              <h3 className="text-lg font-bold text-slate-100 mt-1">{selectedModel.name}</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setPreviewModalOpen(true)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                Inspect PNG
              </button>
              <button
                onClick={copyManifestJson}
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-xs font-medium text-white flex items-center gap-1.5 shadow-lg shadow-cyan-950 transition-all"
              >
                <FileCode className="w-3.5 h-3.5" />
                {copiedManifest ? 'Copied Manifest!' : 'Copy Manifest JSON'}
              </button>
            </div>
          </div>

          {/* Large Model Visual Banner */}
          <div className="relative rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 aspect-video group">
            <img
              src={selectedModel.imagePath}
              alt={selectedModel.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80" />
            
            <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/80 text-emerald-400 border border-emerald-500/30 backdrop-blur-md">
                  432Hz Harmonic Render Verified
                </span>
                <p className="text-xs text-slate-300 mt-1 max-w-md line-clamp-2 drop-shadow">
                  {selectedModel.description}
                </p>
              </div>

              <a
                href={selectedModel.imagePath}
                download={`${selectedModel.id}_render.jpg`}
                className="p-2 rounded-lg bg-black/60 hover:bg-black/80 border border-slate-700 text-slate-200 backdrop-blur-md transition-colors"
                title="Download Model Image Asset"
              >
                <Download className="w-4 h-4 text-cyan-400" />
              </a>
            </div>
          </div>

          {/* Model Tech Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 text-[10px] block">RENDER ENGINE</span>
              <span className="text-slate-200 font-semibold truncate block mt-0.5">{selectedModel.renderEngine}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 text-[10px] block">POLYGON BUDGET</span>
              <span className="text-cyan-400 font-semibold truncate block mt-0.5">{selectedModel.polygonCount}</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 text-[10px] block">TUNING FREQUENCY</span>
              <span className="text-emerald-400 font-semibold truncate block mt-0.5">{selectedModel.tuningHz} Hz</span>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-slate-500 text-[10px] block">RIG TYPE</span>
              <span className="text-purple-400 font-semibold truncate block mt-0.5">{selectedModel.specs.jawRigType}</span>
            </div>
          </div>

          {/* Tags */}
          <div className="flex items-center gap-2 flex-wrap pt-1">
            <span className="text-[10px] text-slate-400 font-mono">VERSION TAGS:</span>
            {selectedModel.tags.map((tag, idx) => (
              <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                #{tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Fullscreen Image Preview Modal */}
      {previewModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-100">{selectedModel.name} ({selectedModel.version})</h3>
                <p className="text-xs text-slate-400 font-mono">{selectedModel.specs.resolution} • {selectedModel.renderEngine}</p>
              </div>
              <button
                onClick={() => setPreviewModalOpen(false)}
                className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-mono"
              >
                Close ESC
              </button>
            </div>

            <div className="relative rounded-xl overflow-hidden border border-slate-800 max-h-[70vh] flex items-center justify-center bg-black">
              <img
                src={selectedModel.imagePath}
                alt={selectedModel.name}
                referrerPolicy="no-referrer"
                className="max-h-[70vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelVersionVault;
