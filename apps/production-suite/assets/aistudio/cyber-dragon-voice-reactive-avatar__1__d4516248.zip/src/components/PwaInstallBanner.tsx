import React, { useState, useEffect } from 'react';
import { Smartphone, Download, X, Check } from 'lucide-react';
import { DragonTheme } from '../types';

interface PwaInstallBannerProps {
  theme: DragonTheme;
}

export function PwaInstallBanner({ theme }: PwaInstallBannerProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Register Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.log('SW registration failed: ', err);
      });
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      // Fallback instruction for manual installation on iOS / Android
      alert('To install on your phone:\n- iOS Safari: Tap Share -> "Add to Home Screen"\n- Android Chrome: Tap Menu -> "Install App" or "Add to Home Screen"');
      return;
    }

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setShowBanner(false);
    }
    setDeferredPrompt(null);
  };

  if (isInstalled) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm bg-zinc-900/95 backdrop-blur-xl border border-zinc-700/80 rounded-2xl shadow-2xl p-4 flex items-center gap-3 animate-slideUp">
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border"
        style={{
          background: `linear-gradient(135deg, ${theme.primary}22, ${theme.energy}33)`,
          borderColor: theme.energy,
        }}
      >
        <Smartphone className="w-6 h-6" style={{ color: theme.energy }} />
      </div>

      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-bold text-zinc-100 truncate">Install Cyber Dragon PWA</h4>
        <p className="text-xs text-zinc-400">Add to your phone for standalone immersive mode & offline jaw physics.</p>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={handleInstallClick}
          className="px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 shadow-lg transition-all hover:scale-105 active:scale-95"
          style={{
            background: `linear-gradient(135deg, ${theme.primary}, ${theme.energy})`,
            color: '#000',
          }}
        >
          <Download className="w-3.5 h-3.5" />
          Install
        </button>
        <button
          onClick={() => setShowBanner(false)}
          className="p-1.5 text-zinc-400 hover:text-zinc-200 rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
