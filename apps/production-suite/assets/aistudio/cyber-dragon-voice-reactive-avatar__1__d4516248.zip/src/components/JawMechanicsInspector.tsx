import React, { useState, useEffect } from 'react';
import {
  Code,
  Copy,
  Check,
  Zap,
  Sliders,
  Play,
  RotateCcw,
  Sparkles,
  Info,
  Download,
  Terminal,
  Activity,
  Volume2,
  Wand2,
} from 'lucide-react';
import { JAW_MECHANICS_STANDALONE_SNIPPET } from '../utils/jawAudioEngineSnippet';
import { AudioReactiveState, DragonTheme, AudioConfig } from '../types';

interface JawMechanicsInspectorProps {
  audioState: AudioReactiveState;
  theme: DragonTheme;
  audioConfig?: AudioConfig;
  onUpdateAudioConfig?: (updates: Partial<AudioConfig>) => void;
  onUpdateJawMultiplier?: (val: number) => void;
}

export const JawMechanicsInspector: React.FC<JawMechanicsInspectorProps> = ({
  audioState,
  theme,
  audioConfig,
  onUpdateAudioConfig,
  onUpdateJawMultiplier,
}) => {
  const [copied, setCopied] = useState(false);
  const [maxJawDrop, setMaxJawDrop] = useState(42);
  const [maxJawAngle, setMaxJawAngle] = useState(18);
  const [formantWeight, setFormantWeight] = useState(65);
  const [springAttack, setSpringAttack] = useState(0.45);
  const [springDecay, setSpringDecay] = useState(0.22);
  const [activeTab, setActiveTab] = useState<'visualizer' | 'calibration' | 'snippet' | 'formula'>('calibration');

  // Auto-Calibration states
  const [isCalibratingNoise, setIsCalibratingNoise] = useState(false);
  const [isCalibratingMultiplier, setIsCalibratingMultiplier] = useState(false);
  const [calibrationProgress, setCalibrationProgress] = useState(0);
  const [calibrationCountdown, setCalibrationCountdown] = useState(0);
  const [calibrationStatus, setCalibrationStatus] = useState('');

  // History buffer for scrolling waveform
  const [history, setHistory] = useState<number[]>(new Array(150).fill(0));

  // Capture volume history
  useEffect(() => {
    setHistory(prev => {
      const next = [...prev.slice(1), audioState.rawVolume || audioState.volume];
      return next;
    });
  }, [audioState.volume, audioState.rawVolume]);

  const runNoiseCalibration = () => {
    setIsCalibratingNoise(true);
    setCalibrationProgress(0);
    setCalibrationCountdown(3);
    setCalibrationStatus('Evaluating ambient room noise...');
    
    const peaks: number[] = [];
    let sec = 3;
    
    const timer = setInterval(() => {
      sec -= 1;
      setCalibrationCountdown(sec);
      setCalibrationProgress(p => p + 33.3);
      
      // Capture current volume
      peaks.push(audioState.rawVolume || audioState.volume || 0.02);
      
      if (sec <= 0) {
        clearInterval(timer);
        setIsCalibratingNoise(false);
        setCalibrationProgress(100);
        
        // Find maximum peak and add 0.02 margin
        const maxPeak = Math.max(...peaks, 0.02);
        const calibratedGate = Math.min(0.4, Math.max(0.01, maxPeak + 0.025));
        
        if (onUpdateAudioConfig) {
          onUpdateAudioConfig({ noiseGate: parseFloat(calibratedGate.toFixed(3)) });
        }
        setCalibrationStatus(`Completed! Calibrated Noise Gate: ${calibratedGate.toFixed(3)}`);
      }
    }, 1000);
  };

  const runMultiplierCalibration = () => {
    setIsCalibratingMultiplier(true);
    setCalibrationProgress(0);
    setCalibrationCountdown(3);
    setCalibrationStatus('Speak normally into your microphone...');
    
    const peaks: number[] = [];
    let sec = 3;
    
    const timer = setInterval(() => {
      sec -= 1;
      setCalibrationCountdown(sec);
      setCalibrationProgress(p => p + 33.3);
      
      peaks.push(audioState.rawVolume || audioState.volume || 0.05);
      
      if (sec <= 0) {
        clearInterval(timer);
        setIsCalibratingMultiplier(false);
        setCalibrationProgress(100);
        
        // Compute optimal multiplier to map peak volume to wide jaw (around 1.0)
        const maxPeak = Math.max(...peaks, 0.05);
        const calibratedMultiplier = Math.min(2.5, Math.max(0.5, 0.85 / maxPeak));
        
        if (onUpdateAudioConfig) {
          onUpdateAudioConfig({ jawMultiplier: parseFloat(calibratedMultiplier.toFixed(2)) });
        }
        setCalibrationStatus(`Completed! Calibrated Multiplier: ${calibratedMultiplier.toFixed(2)}x`);
      }
    }, 1000);
  };

  // Simulated animated jaw preview
  const simulatedDropPx = (audioState.jawOpen * maxJawDrop).toFixed(1);
  const simulatedAngleDeg = (audioState.jawOpen * maxJawAngle).toFixed(1);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(JAW_MECHANICS_STANDALONE_SNIPPET);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSnippet = () => {
    const blob = new Blob([JAW_MECHANICS_STANDALONE_SNIPPET], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dragon9-audio-reactive-jaw.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Header Badge */}
      <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/90 border border-zinc-800">
        <div className="flex items-center gap-2">
          <div
            className="p-1.5 rounded-lg border text-xs"
            style={{
              backgroundColor: `${theme.primary}20`,
              borderColor: theme.primary,
              color: theme.energy,
            }}
          >
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <div className="font-orbitron font-bold text-xs text-zinc-100 flex items-center gap-1.5">
              <span>CYBERNETICS // JAW MECHANICS</span>
              <span className="text-[10px] px-1.5 py-0.2 bg-cyan-950 text-cyan-400 border border-cyan-800/60 rounded">
                60 FPS
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 font-mono">
              Web Audio API frequency analysis → Jaw animation mapping
            </p>
          </div>
        </div>

        <button
          onClick={handleDownloadSnippet}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-750 text-zinc-200 text-xs font-mono transition-all cursor-pointer border border-zinc-700"
          title="Download JavaScript File"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">.JS Snippet</span>
        </button>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1 bg-zinc-900/80 p-1 rounded-lg border border-zinc-800 text-xs font-rajdhani font-bold">
        <button
          onClick={() => setActiveTab('calibration')}
          className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer uppercase flex items-center justify-center gap-1.5 ${
            activeTab === 'calibration'
              ? 'bg-zinc-800 text-cyan-300 border border-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5 text-amber-400" />
          <span>Interactive Calibration</span>
        </button>
        <button
          onClick={() => setActiveTab('visualizer')}
          className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer uppercase ${
            activeTab === 'visualizer'
              ? 'bg-zinc-800 text-cyan-300 border border-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Telemetry & Physics
        </button>
        <button
          onClick={() => setActiveTab('snippet')}
          className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer uppercase flex items-center justify-center gap-1.5 ${
            activeTab === 'snippet'
              ? 'bg-zinc-800 text-cyan-300 border border-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Code className="w-3.5 h-3.5" />
          <span>JS Snippet</span>
        </button>
        <button
          onClick={() => setActiveTab('formula')}
          className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer uppercase ${
            activeTab === 'formula'
              ? 'bg-zinc-800 text-cyan-300 border border-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Mapping Math
        </button>
      </div>

      {/* INTERACTIVE CALIBRATION TAB */}
      {activeTab === 'calibration' && (
        <div className="flex flex-col gap-4">
          {/* Waveform Visualization Canvas */}
          <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-zinc-400 border-b border-zinc-900 pb-2">
              <span className="flex items-center gap-1.5 text-zinc-200 font-bold">
                <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                ENVIRONMENTAL NOISE VS. JAW THRESHOLD WAVEFORM
              </span>
              <span className="text-[10px] text-zinc-500">150 Samples Running Buffer</span>
            </div>

            {/* Custom Interactive Waveform Graph using SVG */}
            <div className="relative h-36 w-full bg-zinc-950 rounded-lg border border-zinc-900/80 overflow-hidden flex flex-col justify-end">
              {/* Grid Lines */}
              <div className="absolute inset-0 grid grid-rows-4 grid-cols-6 pointer-events-none opacity-10">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="border-b border-zinc-100 w-full" />
                ))}
              </div>

              {/* Threshold Lines */}
              {/* 1. Noise Gate Line */}
              <div
                className="absolute left-0 right-0 border-t-2 border-dashed border-cyan-500/80 pointer-events-none transition-all duration-150"
                style={{
                  bottom: `${(audioConfig?.noiseGate || 0.08) * 100}%`,
                }}
              >
                <span className="absolute left-2 -top-4 text-[9px] bg-cyan-950/85 text-cyan-400 px-1.5 py-0.2 rounded border border-cyan-500/30">
                  Gate: {(audioConfig?.noiseGate || 0.08).toFixed(3)}
                </span>
              </div>

              {/* 2. Optimal Peak Multiplier Line */}
              <div
                className="absolute left-0 right-0 border-t-2 border-dotted border-emerald-500/80 pointer-events-none transition-all duration-150"
                style={{
                  bottom: `${Math.min(100, (1.0 / (audioConfig?.jawMultiplier || 1.4)) * 100)}%`,
                }}
              >
                <span className="absolute right-2 -top-4 text-[9px] bg-emerald-950/85 text-emerald-400 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  Peak Target: {(1.0 / (audioConfig?.jawMultiplier || 1.4)).toFixed(2)} Volume
                </span>
              </div>

              {/* SVG Line Chart for Volume History */}
              <svg className="w-full h-full absolute inset-0 pointer-events-none">
                <defs>
                  <linearGradient id="waveGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={theme.energy} stopOpacity="0.45" />
                    <stop offset="100%" stopColor={theme.energy} stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                
                {/* Area under wave */}
                <path
                  d={`M 0 144 ${history.map((val, i) => `L ${(i / (history.length - 1)) * 320} ${144 - Math.min(130, val * 130)}`).join(' ')} L 320 144 Z`}
                  fill="url(#waveGrad)"
                  className="w-full h-full"
                />

                {/* Wave Line */}
                <path
                  d={history.map((val, i) => `${i === 0 ? 'M' : 'L'} ${(i / (history.length - 1)) * 320} ${144 - Math.min(130, val * 130)}`).join(' ')}
                  fill="none"
                  stroke={theme.energy}
                  strokeWidth="2"
                  className="w-full h-full opacity-90"
                />
              </svg>

              {/* Speech triggers indicator */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5 pointer-events-none">
                <span className={`w-2.5 h-2.5 rounded-full ${audioState.isSpeaking ? 'bg-emerald-400 animate-ping' : 'bg-zinc-700'}`} />
                <span className="text-[9px] text-zinc-400">{audioState.isSpeaking ? 'SPEECH DETECTED (ABOVE GATE)' : 'SILENT / BELOW GATE'}</span>
              </div>
            </div>

            <p className="text-[10px] text-zinc-500 leading-relaxed text-center">
              The <strong className="text-cyan-400">Cyan Gate Line</strong> defines when the mouth begins to open. The <strong className="text-emerald-400">Emerald Target Line</strong> shows where speech triggers 100% jaw aperture.
            </p>
          </div>

          {/* Automated Calibration Wizards */}
          <div className="p-4 bg-zinc-900/70 rounded-xl border border-zinc-800 flex flex-col gap-3 font-mono text-xs">
            <div className="font-bold text-zinc-200 flex items-center justify-between border-b border-zinc-800/80 pb-2">
              <span className="flex items-center gap-1.5 text-zinc-100">
                <Wand2 className="w-4 h-4 text-amber-400" />
                INTELLIGENT AUTO-CALIBRATION WIZARDS
              </span>
            </div>

            {/* If calibration is running, show countdown progress */}
            {(isCalibratingNoise || isCalibratingMultiplier) ? (
              <div className="p-4 bg-zinc-950 rounded-lg border border-amber-500/30 flex flex-col items-center justify-center text-center gap-2.5">
                <div className="text-sm font-bold text-amber-400 animate-pulse uppercase flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
                  {isCalibratingNoise ? 'CALIBRATING NOISE GATE' : 'CALIBRATING AMPLITUDE MULTIPLIER'}
                </div>
                
                <div className="text-3xl font-orbitron font-extrabold text-white">
                  {calibrationCountdown}s Remaining
                </div>

                <div className="text-xs text-zinc-400 italic">
                  {calibrationStatus}
                </div>

                {/* Progress Bar */}
                <div className="w-full h-2 bg-zinc-900 rounded-full overflow-hidden p-0.5 border border-zinc-850 mt-1">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-cyan-500 rounded-full transition-all duration-300"
                    style={{ width: `${calibrationProgress}%` }}
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* 1. Ambient Noise Calibration */}
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 flex flex-col justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-cyan-300 flex items-center gap-1.5">
                      <Volume2 className="w-3.5 h-3.5" />
                      Ambient Noise Floor
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-1.5 leading-relaxed">
                      Measures your room's baseline quiet level for 3s to set the ideal noise gate so fans/AC don't trigger the mouth.
                    </p>
                  </div>
                  <button
                    onClick={runNoiseCalibration}
                    className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded transition-colors text-center text-xs cursor-pointer"
                  >
                    Measure Noise Floor
                  </button>
                </div>

                {/* 2. Voice/Multiplier Calibration */}
                <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-850 flex flex-col justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-emerald-300 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5" />
                      Normal Vocal Multiplier
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-1.5 leading-relaxed">
                      Speak normally into your mic for 3s to calibrate the mouth stretch so speech maps cleanly to 100% wide.
                    </p>
                  </div>
                  <button
                    onClick={runMultiplierCalibration}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded transition-colors text-center text-xs cursor-pointer"
                  >
                    Calibrate Multiplier
                  </button>
                </div>
              </div>
            )}

            {/* Calibration Status Text */}
            {calibrationStatus && !isCalibratingNoise && !isCalibratingMultiplier && (
              <div className="px-3 py-2 rounded bg-cyan-950/20 border border-cyan-800/40 text-[11px] text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>{calibrationStatus}</span>
              </div>
            )}
          </div>

          {/* Manual Settings Fine-Tuning */}
          <div className="p-4 bg-zinc-900/70 rounded-xl border border-zinc-800 flex flex-col gap-3 font-mono text-xs">
            <div className="font-bold text-zinc-200">MANUAL FINE-TUNING</div>

            {/* 1. Noise Gate */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Noise Gate Threshold (0.01 - 0.40):</span>
                <span className="text-cyan-400 font-bold">{(audioConfig?.noiseGate || 0.08).toFixed(3)}</span>
              </div>
              <input
                type="range"
                min="0.01"
                max="0.40"
                step="0.005"
                value={audioConfig?.noiseGate || 0.08}
                onChange={(e) => onUpdateAudioConfig?.({ noiseGate: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* 2. Jaw Multiplier */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Jaw Multiplier / Vocal Amplitude (0.50 - 2.50):</span>
                <span className="text-emerald-400 font-bold">{(audioConfig?.jawMultiplier || 1.4).toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.50"
                max="2.50"
                step="0.05"
                value={audioConfig?.jawMultiplier || 1.4}
                onChange={(e) => onUpdateAudioConfig?.({ jawMultiplier: parseFloat(e.target.value) })}
                className="w-full accent-emerald-400 cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* VIEW 1: TELEMETRY & PHYSICS TESTER */}
      {activeTab === 'visualizer' && (
        <div className="flex flex-col gap-3">
          {/* Live Telemetry Radar */}
          <div className="p-3.5 bg-zinc-950 rounded-xl border border-zinc-800 font-mono text-xs flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-zinc-400 border-b border-zinc-850 pb-2">
              <span className="flex items-center gap-1.5 text-zinc-200 font-bold">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                LIVE HINGE TELEMETRY
              </span>
              <span className="text-[10px] text-cyan-400">
                {audioState.isSpeaking ? '● SPEECH ACTIVE' : '○ IDLE HINGE'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2 rounded bg-zinc-900/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">JAW OPEN</div>
                <div className="text-sm font-bold text-cyan-300">
                  {(audioState.jawOpen * 100).toFixed(0)}%
                </div>
              </div>

              <div className="p-2 rounded bg-zinc-900/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">TRANSLATE Y</div>
                <div className="text-sm font-bold text-amber-300">
                  +{simulatedDropPx}px
                </div>
              </div>

              <div className="p-2 rounded bg-zinc-900/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">ROTATION</div>
                <div className="text-sm font-bold text-pink-300">
                  {simulatedAngleDeg}°
                </div>
              </div>

              <div className="p-2 rounded bg-zinc-900/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">SPEECH FORMANT</div>
                <div className="text-sm font-bold text-emerald-300">
                  {(audioState.mid * 100).toFixed(0)}%
                </div>
              </div>
            </div>

            {/* Visual Hinge Gauge */}
            <div className="flex flex-col gap-1 pt-1">
              <div className="flex justify-between text-[10px] text-zinc-400">
                <span>Jaw Mandible Aperture (A0 → A_max)</span>
                <span>{simulatedDropPx}px / {maxJawDrop}px</span>
              </div>
              <div className="h-3 w-full bg-zinc-900 rounded-full overflow-hidden p-0.5 border border-zinc-800">
                <div
                  className="h-full rounded-full transition-all duration-75"
                  style={{
                    width: `${Math.min(100, audioState.jawOpen * 100)}%`,
                    backgroundColor: audioState.isRoaring
                      ? '#f43f5e'
                      : audioState.isSpeaking
                      ? theme.energy
                      : '#3f3f46',
                    boxShadow: `0 0 10px ${theme.energy}`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* Physics Tuners */}
          <div className="p-3 bg-zinc-900/70 rounded-xl border border-zinc-800 flex flex-col gap-3 font-mono text-xs">
            <div className="font-bold text-zinc-200 flex items-center justify-between">
              <span>MANDIBLE SPRING & DAMPING TUNING</span>
              <button
                onClick={() => {
                  setMaxJawDrop(42);
                  setMaxJawAngle(18);
                  setFormantWeight(65);
                  setSpringAttack(0.45);
                  setSpringDecay(0.22);
                }}
                className="text-[10px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                Reset Defaults
              </button>
            </div>

            {/* Max Jaw Drop */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Max Vertical Drop Distance:</span>
                <span className="text-cyan-300 font-bold">{maxJawDrop}px</span>
              </div>
              <input
                type="range"
                min="20"
                max="80"
                value={maxJawDrop}
                onChange={(e) => setMaxJawDrop(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Max Jaw Angle */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Max Angular Rotation:</span>
                <span className="text-cyan-300 font-bold">{maxJawAngle}°</span>
              </div>
              <input
                type="range"
                min="5"
                max="35"
                value={maxJawAngle}
                onChange={(e) => setMaxJawAngle(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Speech Formant Ratio */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-zinc-400 text-[11px]">
                <span>Voice Formant Weight (300Hz-2800Hz):</span>
                <span className="text-cyan-300 font-bold">{formantWeight}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="90"
                value={formantWeight}
                onChange={(e) => setFormantWeight(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Attack & Decay Springs */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-zinc-400 text-[10px]">
                  <span>Attack Alpha:</span>
                  <span className="text-emerald-400 font-bold">{springAttack}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="0.9"
                  step="0.05"
                  value={springAttack}
                  onChange={(e) => setSpringAttack(Number(e.target.value))}
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-zinc-400 text-[10px]">
                  <span>Decay Alpha:</span>
                  <span className="text-amber-400 font-bold">{springDecay}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.6"
                  step="0.05"
                  value={springDecay}
                  onChange={(e) => setSpringDecay(Number(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: STANDALONE JS SNIPPET */}
      {activeTab === 'snippet' && (
        <div className="flex flex-col gap-2 font-mono text-xs">
          <div className="flex items-center justify-between bg-zinc-900 px-3 py-2 rounded-t-xl border border-zinc-800">
            <div className="flex items-center gap-2 text-zinc-300">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>dragon9-audio-reactive-jaw.js</span>
            </div>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-zinc-950 rounded font-bold transition-all cursor-pointer text-[11px]"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED!' : 'COPY CODE'}</span>
            </button>
          </div>

          <pre className="p-3 bg-zinc-950 text-zinc-300 rounded-b-xl border-x border-b border-zinc-800 text-[11px] leading-relaxed max-h-[340px] overflow-y-auto overflow-x-auto whitespace-pre font-mono">
            {JAW_MECHANICS_STANDALONE_SNIPPET}
          </pre>
        </div>
      )}

      {/* VIEW 3: MATHEMATICAL FORMULA */}
      {activeTab === 'formula' && (
        <div className="p-3.5 bg-zinc-900/80 rounded-xl border border-zinc-800 font-mono text-xs flex flex-col gap-3 text-zinc-300">
          <div className="font-bold text-cyan-300 flex items-center gap-1.5">
            <Info className="w-4 h-4" />
            <span>DIRECT AMPLITUDE & FORMANT MAPPING EQUATIONS</span>
          </div>

          <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800 space-y-2 text-[11px]">
            <p className="text-zinc-400">
              <strong className="text-zinc-200">1. RMS Volume Calculation:</strong>
              <br />
              <code className="text-cyan-400">RMS = sqrt( (1 / N) * sum((timeData[i] - 128) / 128)^2 )</code>
            </p>

            <p className="text-zinc-400">
              <strong className="text-zinc-200">2. Speech Formant Band Energy (300Hz - 2800Hz):</strong>
              <br />
              <code className="text-emerald-400">E_vocal = (1 / K) * sum(freqData[k] / 255) for bin(k) in [300, 2800]Hz</code>
            </p>

            <p className="text-zinc-400">
              <strong className="text-zinc-200">3. Target Mandible Aperture ($T_j$):</strong>
              <br />
              <code className="text-amber-400">T_j = min(1.0, ( (1 - w_vocal) * RMS + w_vocal * E_vocal ) * M_jaw)</code>
            </p>

            <p className="text-zinc-400">
              <strong className="text-zinc-200">4. Asymmetric Spring Interpolation:</strong>
              <br />
              <code className="text-pink-400">J_t = J_{`{t-1}`} + (T_j - J_{`{t-1}`}) * (T_j &gt; J_{`{t-1}`} ? α_attack : α_decay)</code>
            </p>
          </div>

          <p className="text-[11px] text-zinc-400 leading-relaxed">
            This prevents flickering micro-jitters during sibilants (such as 's' and 'f') while opening rapidly on plosives and vowels ('a', 'o', 'u').
          </p>
        </div>
      )}
    </div>
  );
};
