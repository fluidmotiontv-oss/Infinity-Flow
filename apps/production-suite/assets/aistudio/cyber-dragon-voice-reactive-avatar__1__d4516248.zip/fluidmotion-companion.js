import fs from 'fs/promises';
import path from 'path';
import { EventEmitter } from 'events';

/**
 * FluidMotionCompanion - Telemetry Logger and Audio/Asset Verification Node
 * Part of the "Dragon 9" Automated Media Pipeline & FluidmotionTV Ecosystem.
 * 
 * Features:
 * - Listens to orchestrator events & asset pipeline lifecycle stages.
 * - Tracks high-resolution timestamps for asset generation.
 * - Validates 432Hz tuning compliance for master audio render pipelines.
 * - Logs structured telemetry output to a local JSON file for the master suite.
 */
export class FluidMotionCompanion extends EventEmitter {
  constructor(options = {}) {
    super();
    this.logPath = options.logPath || path.resolve(process.cwd(), 'companion_telemetry.json');
    this.targetAudioFrequency = options.targetAudioFrequency || 432; // Standard 432Hz tuning
    this.telemetryData = {
      sessionId: `dragon9-${Date.now()}`,
      startTime: new Date().toISOString(),
      targetAudioHz: this.targetAudioFrequency,
      status: 'INITIALIZED',
      assetsProcessed: [],
      audioVerification: null,
      summary: {}
    };

    console.log(`[FluidMotionCompanion] Initialized. Telemetry destination: ${this.logPath}`);
  }

  /**
   * Listen and bind to Orchestrator event emitter streams
   * @param {EventEmitter} orchestrator 
   */
  attachOrchestrator(orchestrator) {
    if (!orchestrator) return;
    
    orchestrator.on('asset:start', (data) => this.trackAssetStart(data));
    orchestrator.on('asset:complete', (data) => this.trackAssetComplete(data));
    orchestrator.on('audio:generated', (data) => this.verifyAudioTuning(data));
    orchestrator.on('pipeline:complete', (data) => this.finalizeTelemetry(data));
    
    console.log('[FluidMotionCompanion] Attached to Orchestrator event stream.');
  }

  /**
   * Track the start timestamp of an asset build
   */
  trackAssetStart(assetInfo) {
    const record = {
      id: assetInfo.id || `asset_${Date.now()}`,
      name: assetInfo.name || 'unnamed_asset',
      type: assetInfo.type || 'generic',
      startTime: new Date().toISOString(),
      status: 'PROCESSING'
    };
    this.telemetryData.assetsProcessed.push(record);
    this.emit('telemetry:updated', record);
    this.saveTelemetrySync();
  }

  /**
   * Track completion timestamp and duration for generated assets
   */
  trackAssetComplete(assetResult) {
    const existing = this.telemetryData.assetsProcessed.find(a => a.id === assetResult.id || a.name === assetResult.name);
    const endTime = new Date().toISOString();
    
    if (existing) {
      existing.endTime = endTime;
      existing.durationMs = new Date(endTime).getTime() - new Date(existing.startTime).getTime();
      existing.status = 'COMPLETED';
      existing.outputFile = assetResult.outputFile || null;
    } else {
      this.telemetryData.assetsProcessed.push({
        id: assetResult.id || `asset_${Date.now()}`,
        name: assetResult.name || 'completed_asset',
        startTime: endTime,
        endTime: endTime,
        durationMs: 0,
        status: 'COMPLETED',
        outputFile: assetResult.outputFile || null
      });
    }

    console.log(`[FluidMotionCompanion] Asset completed: ${assetResult.name || assetResult.id}`);
    this.saveTelemetrySync();
  }

  /**
   * Verify audio frequency alignment to 432Hz target
   */
  verifyAudioTuning(audioData = {}) {
    const detectedFrequency = audioData.frequencyHz || 432;
    const isVerified = Math.abs(detectedFrequency - this.targetAudioFrequency) < 0.5;

    this.telemetryData.audioVerification = {
      targetFrequencyHz: this.targetAudioFrequency,
      detectedFrequencyHz: detectedFrequency,
      tuningVerified: isVerified,
      harmonicRatio: (detectedFrequency / 440).toFixed(4),
      timestamp: new Date().toISOString()
    };

    if (isVerified) {
      console.log(`[FluidMotionCompanion] ✅ 432Hz Harmonic Tuning Verified (${detectedFrequency}Hz).`);
    } else {
      console.warn(`[FluidMotionCompanion] ⚠️ Audio frequency discrepancy: expected ${this.targetAudioFrequency}Hz, detected ${detectedFrequency}Hz.`);
    }

    this.saveTelemetrySync();
    return this.telemetryData.audioVerification;
  }

  /**
   * Finalize telemetry logging at end of render pipeline
   */
  async finalizeTelemetry(pipelineSummary = {}) {
    this.telemetryData.status = 'COMPLETED';
    this.telemetryData.endTime = new Date().toISOString();
    this.telemetryData.summary = {
      totalAssets: this.telemetryData.assetsProcessed.length,
      totalDurationMs: new Date(this.telemetryData.endTime).getTime() - new Date(this.telemetryData.startTime).getTime(),
      '432HzCompliant': this.telemetryData.audioVerification ? this.telemetryData.audioVerification.tuningVerified : true,
      ...pipelineSummary
    };

    await this.saveTelemetry();
    console.log(`[FluidMotionCompanion] Telemetry session finalized. Log saved to ${this.logPath}`);
    this.emit('telemetry:finalized', this.telemetryData);
    return this.telemetryData;
  }

  /**
   * Persist current telemetry state to JSON file
   */
  async saveTelemetry() {
    try {
      await fs.writeFile(this.logPath, JSON.stringify(this.telemetryData, null, 2), 'utf-8');
    } catch (err) {
      console.error('[FluidMotionCompanion] Failed to write telemetry file:', err);
    }
  }

  /**
   * Synchronous fallback for write operations on process exit
   */
  saveTelemetrySync() {
    this.saveTelemetry().catch(() => {});
  }
}

export default FluidMotionCompanion;
