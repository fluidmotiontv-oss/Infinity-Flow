import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface WebGLMatrixProps {
  somaticData: {
    velocity: number;
    audioIntensity: number;
    frequency: number;
    resonance432Hz: number;
    cognitiveLoad: number;
    heartRate: number;
    adrenalineState: boolean;
    polarityState: string;
  };
  viewStyle: 'lotus' | 'infinity' | 'spine';
}

export function WebGLMatrix({ somaticData, viewStyle }: WebGLMatrixProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const meshRef = useRef<THREE.Mesh | null>(null);
  const pointsRef = useRef<THREE.Points | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // References to keep data accessible to the render loop without triggering full reinstantiations
  const somaticDataRef = useRef(somaticData);
  useEffect(() => {
    somaticDataRef.current = somaticData;
  }, [somaticData]);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 500;
    const height = containerRef.current.clientHeight || 450;

    // 1. Create Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x030712, 0.08);

    // 2. Create Camera
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    camera.position.z = 6;
    cameraRef.current = camera;

    // 3. Create WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    
    // Clear the container first
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.15);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 0.95);
    keyLight.position.set(5, 5, 5);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x06B6D4, 0.7);
    fillLight.position.set(-5, -2, -5);
    scene.add(fillLight);

    // 5. Construct Geometry based on selection
    let geometry: THREE.BufferGeometry;
    if (viewStyle === 'lotus') {
      // Octagonal Torus Knot / Lotus representation
      geometry = new THREE.TorusKnotGeometry(1.6, 0.5, 120, 12, 3, 4);
    } else if (viewStyle === 'infinity') {
      // Infinity Ring Loop representation
      geometry = new THREE.TorusGeometry(1.8, 0.35, 12, 100);
    } else {
      // Spine Helix Cylindrical Coil structure
      geometry = new THREE.CylinderGeometry(0.8, 0.8, 4.2, 24, 32, true);
    }

    const material = new THREE.MeshBasicMaterial({
      color: 0x06B6D4,
      wireframe: true,
      transparent: true,
      opacity: 0.8,
    });

    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);
    meshRef.current = mesh;

    // 6. Cyber Particle Cloud
    const particleCount = 250;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 10;
      positions[i + 1] = (Math.random() - 0.5) * 10;
      positions[i + 2] = (Math.random() - 0.5) * 10;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x06B6D4,
      size: 0.05,
      transparent: true,
      opacity: 0.6,
    });
    const points = new THREE.Points(particleGeo, particleMat);
    scene.add(points);
    pointsRef.current = points;

    // 7. Mouse orbital drag
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !mesh) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      mesh.rotation.y += deltaX * 0.007;
      mesh.rotation.x += deltaY * 0.007;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    // 8. Render Heartbeat loop
    let lastTime = 0;
    const render = (time: number) => {
      const delta = (time - lastTime) * 0.001;
      lastTime = time;

      const currentSomatic = somaticDataRef.current;

      if (mesh) {
        // Rotate speed scales up with somatic gesture velocity
        const rotSpeed = 0.05 + currentSomatic.velocity * 1.1;
        mesh.rotation.y += delta * rotSpeed;
        mesh.rotation.x += delta * (rotSpeed * 0.4);

        // Organnic breathing pulse scaling bound to sound intensity/resonance
        const pulse = 1.0 + (currentSomatic.audioIntensity * 0.35) + Math.sin(time * 0.003) * 0.04;
        mesh.scale.set(pulse, pulse, pulse);

        // Custom sinusoidal warping
        if (viewStyle === 'infinity') {
          const pos = geometry.attributes.position;
          for (let i = 0; i < pos.count; i++) {
            const x = pos.getX(i);
            const y = pos.getY(i);
            const z = pos.getZ(i);
            const angle = Math.atan2(y, x);
            const warp = Math.sin(angle * 4 + time * 0.004) * 0.12 * currentSomatic.velocity;
            pos.setZ(i, z + warp);
          }
          geometry.attributes.position.needsUpdate = true;
        } else if (viewStyle === 'spine') {
          const pos = geometry.attributes.position;
          for (let i = 0; i < pos.count; i++) {
            const y = pos.getY(i);
            const x = pos.getX(i);
            const z = pos.getZ(i);
            // Spinal nerve ripple waves
            const warp = Math.sin(y * 2 + time * 0.005) * 0.1 * currentSomatic.velocity;
            pos.setX(i, x + warp * Math.cos(y));
            pos.setZ(i, z + warp * Math.sin(y));
          }
          geometry.attributes.position.needsUpdate = true;
        }

        // Color transition logic (Yin = Cyan, Yang = Amber, Adrenaline = Fire Red)
        let targetColor = new THREE.Color(0x06B6D4); // standard electric cyan
        if (currentSomatic.adrenalineState) {
          targetColor = new THREE.Color(0xEF4444); // Neon Fire Red
        } else if (currentSomatic.polarityState === 'yang') {
          targetColor = new THREE.Color(0xF59E0B); // Cyber Amber Orange
        } else {
          // calm Yin morphing blue/cyan
          const pulseColor = 0.5 + Math.sin(time * 0.001) * 0.5;
          targetColor.lerp(new THREE.Color(0x2563EB), pulseColor);
        }

        material.color.copy(targetColor);
        particleMat.color.copy(targetColor);
      }

      if (points) {
        points.rotation.y -= delta * 0.025;
      }

      renderer.render(scene, camera);
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    // Window Resize logic
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // 9. Cleanup allocations
    return () => {
      window.removeEventListener('resize', handleResize);
      domElement.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      renderer.dispose();
      geometry.dispose();
      material.dispose();
      particleGeo.dispose();
      particleMat.dispose();
    };
  }, [viewStyle]);

  return (
    <div className="relative w-full h-full min-h-[400px]">
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      
      {/* Mini tech panel overlay */}
      <div className="absolute top-4 left-4 flex flex-col gap-1 pointer-events-none bg-black/50 backdrop-blur-md px-3 py-2 border border-white/5 rounded text-[10px] font-mono text-cyan-400">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          WEBGL_RENDERER ACTIVE
        </span>
        <span>GEOMETRY: {viewStyle.toUpperCase()}</span>
        <span>FPS_TARGET: 60Hz</span>
      </div>
    </div>
  );
}
