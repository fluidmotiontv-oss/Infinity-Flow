import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Video, Mic, Volume2, Compass, Cpu, Zap, 
  Sparkles, Terminal, Heart, Share2, RefreshCw, Play, 
  Square, Settings, Code2, AlertTriangle, Layers, ChevronRight
} from 'lucide-react';
import * as THREE from 'three';
import { WebGLMatrix } from './AppWebGL';

// Interfaces for our Somatic States
interface SomaticState {
  velocity: number;
  audioIntensity: number;
  frequency: number;
  resonance432Hz: number;
  cognitiveLoad: number;
  heartRate: number;
  adrenalineState: boolean;
  polarityState: string;
}

interface OracleResult {
  statusUpdate: string;
  polarityAdvice: string;
  systemDirectives: string[];
  adrenalineAnalysis: string;
  somaticAura: string;
}

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<'visualizer' | 'inputs' | 'engine' | 'oracle'>('visualizer');

  // WebSocket / Connection status
  const [wsConnected, setWsConnected] = useState(false);
  const [tickerInterval, setTickerInterval] = useState(150);
  const [messagesReceivedCount, setMessagesReceivedCount] = useState(0);

  // Somatic Data State (Master tracking)
  const [somaticData, setSomaticData] = useState<SomaticState>({
    velocity: 0.15,
    audioIntensity: 0.08,
    frequency: 432.0,
    resonance432Hz: 0.85,
    cognitiveLoad: 45.0,
    heartRate: 72,
    adrenalineState: false,
    polarityState: 'yin'
  });

  // Controls & Toggles
  const [viewStyle, setViewStyle] = useState<'lotus' | 'infinity' | 'spine'>('lotus');
  const [autoBalancePolarity, setAutoBalancePolarity] = useState(true);

  // Sensory Capture State
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  const [camFPS, setCamFPS] = useState(0);
  const [rawMotionIndex, setRawMotionIndex] = useState(0);

  // Web Audio Contexts
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioAnalyserRef = useRef<AnalyserNode | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioAnimationRef = useRef<number | null>(null);
  const [audioSpectrum, setAudioSpectrum] = useState<number[]>(new Array(32).fill(0));

  // Webcam References
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastFrameDataRef = useRef<Uint8ClampedArray | null>(null);
  const camAnimationRef = useRef<number | null>(null);

  // Oracle AI Interaction State
  const [oracleInput, setOracleInput] = useState('');
  const [oracleResponse, setOracleResponse] = useState<OracleResult | null>({
    statusUpdate: "Somatic feedback loops initialized. Waiting for environmental waves or custom query.",
    polarityAdvice: "The two-pin polarity resides in neutral Yin. Harmonization threshold is operational.",
    systemDirectives: [
      "sys_alloc --cpu-governor performance",
      "somatic_matrix_core --bind-ports 8080 --tune-resonance 432Hz",
      "watch -n 1 'antix_mem_status | grep -E \"allocated_ram|cognitive_threads\"'"
    ],
    adrenalineAnalysis: "Compute scaling is running at safe nominal levels. 4GB memory segment mapped.",
    somaticAura: "The 3D WebGL Lotus skin is pulsing a calm cyan, indicating meditative homeostasis."
  });
  const [oracleLoading, setOracleLoading] = useState(false);
  const [oracleError, setOracleError] = useState<string | null>(null);

  // WebSocket reference
  const wsRef = useRef<WebSocket | null>(null);

  // Connect to Proprioceptive WebSocket Bus
  useEffect(() => {
    // Establish dynamic connection URL based on current host
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/somatic-bus`;

    const connectWS = () => {
      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          setWsConnected(true);
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            setMessagesReceivedCount(prev => prev + 1);

            if (data.type === 'somatic-state' || data.type === 'somatic-heartbeat' || data.type === 'somatic-welcome') {
              setSomaticData(data.state);
              if (data.interval) {
                setTickerInterval(data.interval);
              }
            }
          } catch (e) {
            console.error('Error parsing somatic broadcast:', e);
          }
        };

        ws.onclose = () => {
          setWsConnected(false);
          // Auto reconnect after 3s
          setTimeout(connectWS, 3000);
        };

        ws.onerror = () => {
          setWsConnected(false);
        };
      } catch (err) {
        console.error('WebSocket connection failed:', err);
      }
    };

    connectWS();

    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  // Update telemetry helper over WS or REST fallback
  const sendTelemetryUpdate = async (updates: Partial<SomaticState>) => {
    // Update local immediately for immediate render loop response
    setSomaticData(prev => ({ ...prev, ...updates }));

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'sensor-telemetry',
        ...updates
      }));
    } else {
      // Fallback post
      try {
        await fetch('/api/somatic/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
      } catch (err) {
        // quiet fallback
      }
    }
  };

  // Trigger high-intensity somatic impulse
  const handleImpulseTrigger = async () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'trigger-pulse' }));
    } else {
      try {
        await fetch('/api/somatic/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            velocity: 1.8,
            audioIntensity: 0.95,
            resonance432Hz: 0.98,
            cognitiveLoad: 85.0,
            adrenalineState: true
          })
        });
      } catch (err) {}
    }
  };

  // Manual Adjuster Helpers
  const handleSliderChange = (key: keyof SomaticState, value: number | boolean) => {
    sendTelemetryUpdate({ [key]: value });
  };

  // --- Computer Vision Optic Nerve Real Hand-Tracking Engine ---
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240, facingMode: 'user' }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setIsCameraActive(true);
        // Start processing frames
        startCameraProcessing();
      }
    } catch (err) {
      alert("Camera permissions blocked. Activating simulated video tracking pattern instead.");
      setIsCameraActive(true);
      startCameraProcessing(true); // simulated
    }
  };

  const stopCamera = () => {
    setIsCameraActive(false);
    if (camAnimationRef.current) {
      cancelAnimationFrame(camAnimationRef.current);
      camAnimationRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    lastFrameDataRef.current = null;
  };

  const startCameraProcessing = (isSimulated = false) => {
    let lastTime = performance.now();
    let frameCount = 0;

    const processFrame = () => {
      if (!isCameraActive && !isSimulated) return;

      const now = performance.now();
      frameCount++;
      if (now - lastTime >= 1000) {
        setCamFPS(frameCount);
        frameCount = 0;
        lastTime = now;
      }

      const canvas = canvasRef.current;
      const video = videoRef.current;

      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;

          if (isSimulated) {
            // Draw a spinning tech grid for simulated testing
            ctx.fillStyle = '#030712';
            ctx.fillRect(0, 0, w, h);
            ctx.strokeStyle = '#06B6D433';
            ctx.lineWidth = 1;
            
            // Grid lines
            for (let i = 0; i < w; i += 20) {
              ctx.beginPath();
              ctx.moveTo(i, 0);
              ctx.lineTo(i, h);
              ctx.stroke();
            }
            for (let i = 0; i < h; i += 20) {
              ctx.beginPath();
              ctx.moveTo(0, i);
              ctx.lineTo(w, i);
              ctx.stroke();
            }

            // Rotating scanner circle
            const cx = w / 2;
            const cy = h / 2;
            const radius = 60 + Math.sin(now * 0.003) * 20;
            ctx.strokeStyle = '#06B6D4';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.stroke();

            // Scrolling crosshairs
            ctx.strokeStyle = '#EF444488';
            ctx.beginPath();
            ctx.moveTo(cx - 80, cy);
            ctx.lineTo(cx + 80, cy);
            ctx.moveTo(cx, cy - 80);
            ctx.lineTo(cx, cy + 80);
            ctx.stroke();

            // Calculate simulated motion index
            const simMotion = 0.1 + Math.abs(Math.sin(now * 0.001) * 0.5) + (Math.random() * 0.05);
            setRawMotionIndex(Math.floor(simMotion * 100));
            sendTelemetryUpdate({
              velocity: Number((simMotion * 1.5).toFixed(3))
            });

          } else if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
            // Real webcam analysis
            ctx.drawImage(video, 0, 0, w, h);
            const frame = ctx.getImageData(0, 0, w, h);
            const data = frame.data;

            if (lastFrameDataRef.current) {
              let diffSum = 0;
              const step = 4; // Sample every 4th pixel for high performance speed
              for (let i = 0; i < data.length; i += step * 4) {
                const rDiff = Math.abs(data[i] - lastFrameDataRef.current[i]);
                const gDiff = Math.abs(data[i + 1] - lastFrameDataRef.current[i + 1]);
                const bDiff = Math.abs(data[i + 2] - lastFrameDataRef.current[i + 2]);
                diffSum += (rDiff + gDiff + bDiff);
              }

              // Normalize motion intensity to scale
              const normalizedDiff = diffSum / (w * h * 3 / step);
              // Scale range: 0 to 100 representing percentage of pixels modified
              const motionPct = Math.min(100, normalizedDiff * 8); 
              setRawMotionIndex(Math.floor(motionPct));

              // Map to somatic velocity (0.05 to 2.0)
              const computedVelocity = Math.max(0.05, Math.min(2.0, (motionPct / 40)));
              
              // Only update if there is a distinct change to reduce excessive server spam
              if (Math.abs(somaticData.velocity - computedVelocity) > 0.02) {
                sendTelemetryUpdate({
                  velocity: Number(computedVelocity.toFixed(3))
                });
              }
            }

            // Store current frame as previous for next iteration
            lastFrameDataRef.current = new Uint8ClampedArray(data);

            // Draw a tech-scanner HUD over the camera feed
            ctx.strokeStyle = somaticData.velocity > 1.0 ? '#EF4444' : '#06B6D4';
            ctx.lineWidth = 1;
            ctx.strokeRect(10, 10, w - 20, h - 20);

            // Horizontal scanline
            const scanY = (now * 0.15) % (h - 20) + 10;
            ctx.strokeStyle = somaticData.velocity > 1.0 ? '#EF444455' : '#06B6D455';
            ctx.beginPath();
            ctx.moveTo(10, scanY);
            ctx.lineTo(w - 10, scanY);
            ctx.stroke();

            // Caliper text on frame
            ctx.fillStyle = '#22D3EE';
            ctx.font = '8px monospace';
            ctx.fillText(`MOTION_V: ${somaticData.velocity.toFixed(3)}`, 15, 25);
            ctx.fillText(`OPTIC_FLOW: ${Math.floor(rawMotionIndex)}%`, 15, 35);
          }
        }
      }

      camAnimationRef.current = requestAnimationFrame(processFrame);
    };

    camAnimationRef.current = requestAnimationFrame(processFrame);
  };


  // --- Auditory Nerve Real Microphone FFT Analysis ---
  const startMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      audioCtxRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256; // 128 frequency bands
      source.connect(analyser);
      audioAnalyserRef.current = analyser;

      setIsMicActive(true);
      startMicProcessing();
    } catch (err) {
      alert("Microphone permission was denied. Loading simulated ambient wave telemetry instead.");
      setIsMicActive(true);
      startMicProcessing(true); // simulated
    }
  };

  const stopMic = () => {
    setIsMicActive(false);
    if (audioAnimationRef.current) {
      cancelAnimationFrame(audioAnimationRef.current);
      audioAnimationRef.current = null;
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach(track => track.stop());
      audioStreamRef.current = null;
    }
    if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
      audioCtxRef.current.close();
    }
  };

  const startMicProcessing = (isSimulated = false) => {
    const bufferLength = audioAnalyserRef.current ? audioAnalyserRef.current.frequencyBinCount : 128;
    const dataArray = new Uint8Array(bufferLength);

    const updateAudio = () => {
      if (!isMicActive && !isSimulated) return;

      if (isSimulated) {
        // Generate simulated spectrum wave
        const now = Date.now();
        const mockSpectrum = Array.from({ length: 32 }, (_, i) => {
          const base = Math.sin(now * 0.0015 + i * 0.2) * 30 + 40;
          // Peak near 432Hz (around index 9)
          const is432HzZone = i === 9 || i === 10 || i === 8;
          const peak = is432HzZone ? (Math.sin(now * 0.005) * 40 + 70) : 0;
          return Math.max(5, Math.floor(base + peak + Math.random() * 10));
        });

        setAudioSpectrum(mockSpectrum);

        // Convert index 9 (432Hz area) energy into resonance
        const intensity = mockSpectrum.reduce((acc, v) => acc + v, 0) / (32 * 150);
        const peakEnergy = mockSpectrum[9] / 150;

        sendTelemetryUpdate({
          audioIntensity: Number(Math.max(0.02, Math.min(1.0, intensity)).toFixed(3)),
          frequency: Number((425.0 + Math.sin(now * 0.002) * 15).toFixed(1)),
          resonance432Hz: Number(Math.max(0.1, Math.min(1.0, peakEnergy)).toFixed(3))
        });

      } else if (audioAnalyserRef.current) {
        audioAnalyserRef.current.getByteFrequencyData(dataArray);

        // Map buffer frequencies to a readable spectrum of 32 points
        const step = Math.floor(bufferLength / 32);
        const mappedSpectrum = Array.from({ length: 32 }, (_, i) => {
          let sum = 0;
          for (let j = 0; j < step; j++) {
            sum += dataArray[i * step + j] || 0;
          }
          return Math.floor(sum / step);
        });
        setAudioSpectrum(mappedSpectrum);

        // Analyze specific 432Hz bands
        // Sample rate is typically 48000Hz.
        // bin size = sampleRate / fftSize = 48000 / 256 = 187.5Hz
        // Index 2 is ~375Hz, Index 3 is ~562Hz.
        // We calculate exact energy centered between bin 2 and 3.
        const energyAtLow = dataArray[1] || 0;
        const energyAtMid = dataArray[2] || 0;  // roughly near 375-562Hz
        const energyAtHigh = dataArray[3] || 0;

        const maxEnergy = Math.max(...Array.from(dataArray));
        const overallLoudness = (mappedSpectrum.reduce((a, b) => a + b, 0) / (32 * 255));

        // Quantify resonance centered specifically near 432Hz
        const targetResonance = Math.max(0.0, Math.min(1.0, (energyAtMid * 1.5) / 255));
        
        // Calculate dynamic dominant frequency representation (weighted average center)
        let weightSum = 0;
        let valueSum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          weightSum += dataArray[i];
          valueSum += dataArray[i] * i * (48000 / 256);
        }
        const dominantFreq = weightSum > 100 ? (valueSum / weightSum) : 432.0;

        sendTelemetryUpdate({
          audioIntensity: Number(Math.max(0.01, Math.min(1.0, overallLoudness)).toFixed(3)),
          frequency: Number(Math.max(100, Math.min(2000, dominantFreq)).toFixed(1)),
          resonance432Hz: Number(targetResonance.toFixed(3))
        });
      }

      audioAnimationRef.current = requestAnimationFrame(updateAudio);
    };

    audioAnimationRef.current = requestAnimationFrame(updateAudio);
  };

  // Run somatic balance computations
  useEffect(() => {
    if (!autoBalancePolarity) return;

    // Adjust Yin/Yang Polarity dynamically based on current cognitive load and adrenaline
    let nextPolarity = 'yin';
    if (somaticData.cognitiveLoad > 75 || somaticData.adrenalineState) {
      nextPolarity = 'yang';
    } else {
      nextPolarity = 'yin';
    }

    if (somaticData.polarityState !== nextPolarity) {
      sendTelemetryUpdate({ polarityState: nextPolarity });
    }
  }, [somaticData.cognitiveLoad, somaticData.adrenalineState, autoBalancePolarity]);


  // --- Gemini Oracle Cognitive Query ---
  const handleOracleQuery = async (presetPrompt?: string) => {
    setOracleLoading(true);
    setOracleError(null);
    const query = presetPrompt || oracleInput || "Analyze current somatic sensory matrix and generate system directives.";

    try {
      const response = await fetch('/api/somatic/oracle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customPrompt: query
        })
      });

      const data = await response.json();
      if (data.success && data.analysis) {
        setOracleResponse(data.analysis as OracleResult);
        setOracleInput('');
      } else {
        setOracleError(data.error || 'Failed to analyze somatic inputs.');
      }
    } catch (err) {
      setOracleError('Internal server communication failure. Verify Node broker status.');
    } finally {
      setOracleLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-950 font-sans antialiased text-gray-100">
      
      {/* 2. Top Bar Contract - STRICT 3-ZONE CONFIG */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-gray-900 bg-gray-950/80 backdrop-blur-md z-50">
        {/* Zone 1: Brand title (One line wordmark) */}
        <div className="flex items-center gap-3">
          <span className="text-lg font-black tracking-widest text-cyan-400 font-display uppercase">
            Cyber Dragon Matrix
          </span>
        </div>

        {/* Zone 2: Nav Links (4-6 links, single-line, 1-2 words) */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold tracking-wider font-display text-gray-400 uppercase">
          <button 
            onClick={() => setActiveTab('visualizer')} 
            className={`transition-colors whitespace-nowrap hover:text-cyan-400 ${activeTab === 'visualizer' ? 'text-cyan-400 underline underline-offset-4 decoration-2' : ''}`}
          >
            Somatic Skin
          </button>
          <button 
            onClick={() => setActiveTab('inputs')} 
            className={`transition-colors whitespace-nowrap hover:text-cyan-400 ${activeTab === 'inputs' ? 'text-cyan-400 underline underline-offset-4 decoration-2' : ''}`}
          >
            Sensory Receptors
          </button>
          <button 
            onClick={() => setActiveTab('engine')} 
            className={`transition-colors whitespace-nowrap hover:text-cyan-400 ${activeTab === 'engine' ? 'text-cyan-400 underline underline-offset-4 decoration-2' : ''}`}
          >
            Engine Translation
          </button>
          <button 
            onClick={() => setActiveTab('oracle')} 
            className={`transition-colors whitespace-nowrap hover:text-cyan-400 ${activeTab === 'oracle' ? 'text-cyan-400 underline underline-offset-4 decoration-2' : ''}`}
          >
            Cognitive Core
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3">
          <button 
            onClick={handleImpulseTrigger}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold font-display uppercase tracking-wider text-black bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 rounded hover:from-red-600 hover:to-yellow-600 transition-all duration-300 transform active:scale-95"
          >
            <Zap size={11} className="animate-bounce" />
            Trigger Impulse
          </button>
          <div className="flex items-center gap-1 bg-black/40 px-2 py-1 border border-white/5 rounded text-[9px] font-mono whitespace-nowrap">
            <span className={`w-1.5 h-1.5 rounded-full ${wsConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
            <span className="text-gray-400 uppercase">{wsConnected ? 'Bus Linked' : 'Offline'}</span>
          </div>
        </div>
      </header>

      {/* Main Grid Workspace */}
      <main className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-5 p-5 max-w-[1700px] w-full mx-auto">
        
        {/* Left Control and Sensory Area: 3cols (Hidden on Visualizer full mode to maximize viewport space) */}
        <section className={`xl:col-span-3 flex flex-col gap-5 ${activeTab !== 'inputs' && activeTab !== 'visualizer' ? 'hidden xl:flex' : ''}`}>
          
          {/* Computer Vision - Optic Nerve */}
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Video size={14} className="text-cyan-400" />
                Optic Nerve (Vision)
              </h3>
              <button
                onClick={isCameraActive ? stopCamera : startCamera}
                className={`px-2 py-1 text-[9px] font-bold tracking-wider uppercase rounded transition-all ${isCameraActive ? 'bg-red-950/50 border border-red-500/30 text-red-400' : 'bg-cyan-950/50 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-900/50'}`}
              >
                {isCameraActive ? 'Terminate' : 'Initialize'}
              </button>
            </div>

            <div className="relative w-full aspect-video bg-black/60 rounded overflow-hidden border border-gray-800 flex flex-col items-center justify-center">
              {/* Invisible hidden video */}
              <video ref={videoRef} className="hidden" />
              
              {/* Visual render canvas */}
              <canvas ref={canvasRef} width="320" height="240" className={`w-full h-full object-cover ${isCameraActive ? 'block' : 'hidden'}`} />

              {!isCameraActive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center text-gray-500 font-mono text-[10px]">
                  <Activity size={24} className="text-gray-700 mb-2 animate-pulse" />
                  <span>OPTIC SENSORS OFFLINE</span>
                  <span className="text-[8px] text-gray-600 mt-1">Activate camera to track physical gestures & velocity.</span>
                </div>
              )}
            </div>

            {/* Ingestion Readout */}
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-gray-400 bg-black/20 p-2 rounded border border-white/5">
              <div className="flex flex-col">
                <span className="text-gray-600 text-[8px] uppercase">Telemetry Index</span>
                <span className="font-semibold text-cyan-400">VELOCITY_V: {somaticData.velocity.toFixed(3)}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-600 text-[8px] uppercase">Optic Flow Rate</span>
                <span className="font-semibold text-cyan-400">{rawMotionIndex}%</span>
              </div>
              <div className="flex flex-col col-span-2 pt-1 border-t border-white/5 flex-row justify-between flex">
                <span className="text-gray-600 text-[8px] uppercase">Feed Status</span>
                <span className="text-emerald-400">{isCameraActive ? `STREAMING @ ${camFPS}FPS` : 'INACTIVE'}</span>
              </div>
            </div>
          </div>

          {/* Audio Harmonics - Auditory Nerve */}
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Mic size={14} className="text-cyan-400" />
                Auditory Nerve (Sound)
              </h3>
              <button
                onClick={isMicActive ? stopMic : startMic}
                className={`px-2 py-1 text-[9px] font-bold tracking-wider uppercase rounded transition-all ${isMicActive ? 'bg-red-950/50 border border-red-500/30 text-red-400' : 'bg-cyan-950/50 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-900/50'}`}
              >
                {isMicActive ? 'Terminate' : 'Initialize'}
              </button>
            </div>

            {/* Spectrum Graphic */}
            <div className="h-20 w-full bg-black/60 rounded border border-gray-800 p-2 flex items-end gap-[2px]">
              {audioSpectrum.map((value, idx) => {
                // Focus marker at index 9/10 (roughly 432Hz)
                const is432Zone = idx === 9 || idx === 10;
                return (
                  <div
                    key={idx}
                    style={{ height: `${Math.max(5, (value / 255) * 100)}%` }}
                    className={`flex-1 rounded-t transition-all duration-75 ${is432Zone ? 'bg-gradient-to-t from-cyan-500 to-amber-400 shadow-[0_0_8px_rgba(34,211,238,0.5)]' : 'bg-cyan-950'}`}
                  />
                );
              })}
            </div>

            {/* Calipers */}
            <div className="flex justify-between items-center text-[8px] font-mono text-gray-500 px-1 -mt-1 uppercase">
              <span>20Hz</span>
              <span className="text-amber-400 font-bold border border-amber-400/20 px-1 bg-amber-950/20">Target: 432Hz</span>
              <span>20kHz</span>
            </div>

            {/* Audio Ingestion metrics */}
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-gray-400 bg-black/20 p-2 rounded border border-white/5">
              <div className="flex flex-col">
                <span className="text-gray-600 text-[8px] uppercase">Loudness Intensity</span>
                <span className="font-semibold text-cyan-400">AMPLITUDE_I: {somaticData.audioIntensity.toFixed(3)}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-gray-600 text-[8px] uppercase">432Hz Resonance</span>
                <span className={`font-semibold ${somaticData.resonance432Hz > 0.8 ? 'text-amber-400' : 'text-cyan-400'}`}>
                  ALIGNMENT: {(somaticData.resonance432Hz * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex flex-col col-span-2 pt-1 border-t border-white/5">
                <span className="text-gray-600 text-[8px] uppercase">Center Frequency</span>
                <span className="font-semibold text-cyan-400">{somaticData.frequency.toFixed(1)} Hz</span>
              </div>
            </div>
          </div>

          {/* Wave Simulator panel (If user does not use raw microphone or camera) */}
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-3">
            <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
              <Compass size={14} className="text-cyan-400" />
              Somatic Control Deck
            </h3>

            {/* Sliders */}
            <div className="flex flex-col gap-2 font-mono text-[10px] text-gray-400">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between">
                  <span>Gesture Velocity</span>
                  <span className="text-cyan-400">{somaticData.velocity.toFixed(2)}v</span>
                </div>
                <input 
                  type="range" min="0.05" max="2" step="0.05"
                  value={somaticData.velocity}
                  onChange={(e) => handleSliderChange('velocity', parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between">
                  <span>Environmental Sound</span>
                  <span className="text-cyan-400">{somaticData.audioIntensity.toFixed(2)}i</span>
                </div>
                <input 
                  type="range" min="0" max="1" step="0.02"
                  value={somaticData.audioIntensity}
                  onChange={(e) => handleSliderChange('audioIntensity', parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between">
                  <span>Cognitive Core Load</span>
                  <span className="text-cyan-400">{somaticData.cognitiveLoad.toFixed(0)}%</span>
                </div>
                <input 
                  type="range" min="5" max="100" step="1"
                  value={somaticData.cognitiveLoad}
                  onChange={(e) => handleSliderChange('cognitiveLoad', parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Center WebGL Canvas viewport: 6cols */}
        <section className={`xl:col-span-6 flex flex-col gap-5 ${activeTab !== 'visualizer' ? 'hidden xl:flex' : ''}`}>
          
          {/* Main 3D Matrix Screen */}
          <div className="relative flex-1 bg-black rounded-lg border border-gray-900 overflow-hidden flex flex-col min-h-[500px]">
            
            {/* Header overlay metadata */}
            <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
              {/* Geometry selector */}
              <div className="flex items-center gap-1 p-1 bg-black/60 backdrop-blur-md border border-white/5 rounded-lg">
                <button
                  onClick={() => setViewStyle('lotus')}
                  className={`px-2.5 py-1 text-[9px] font-bold font-display uppercase rounded transition-colors ${viewStyle === 'lotus' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
                >
                  Lotus Core
                </button>
                <button
                  onClick={() => setViewStyle('infinity')}
                  className={`px-2.5 py-1 text-[9px] font-bold font-display uppercase rounded transition-colors ${viewStyle === 'infinity' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
                >
                  Infinity
                </button>
                <button
                  onClick={() => setViewStyle('spine')}
                  className={`px-2.5 py-1 text-[9px] font-bold font-display uppercase rounded transition-colors ${viewStyle === 'spine' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
                >
                  Spine Helix
                </button>
              </div>
            </div>

            {/* WebGL viewport container */}
            <div className="flex-1 w-full h-full min-h-[420px]">
              <WebGLMatrix somaticData={somaticData} viewStyle={viewStyle} />
            </div>

            {/* Bottom metadata HUD bar over WebGL */}
            <div className="absolute bottom-4 left-4 right-4 z-10 pointer-events-none flex justify-between items-end">
              
              {/* Dynamic state dials */}
              <div className="flex flex-wrap gap-2 pointer-events-auto bg-black/60 backdrop-blur-md p-3 border border-white/5 rounded-md font-mono text-[10px]">
                <div className="flex flex-col pr-3 border-r border-white/5">
                  <span className="text-gray-600 text-[8px] uppercase">Polarity Index</span>
                  <span className={`font-bold ${somaticData.polarityState === 'yang' ? 'text-amber-400' : 'text-cyan-400 animate-pulse'}`}>
                    {somaticData.polarityState.toUpperCase()} POLAR
                  </span>
                </div>
                <div className="flex flex-col pr-3 border-r border-white/5">
                  <span className="text-gray-600 text-[8px] uppercase">Adrenaline</span>
                  <span className={`font-bold ${somaticData.adrenalineState ? 'text-red-500 animate-pulse' : 'text-gray-500'}`}>
                    {somaticData.adrenalineState ? 'MAX_SCALING' : 'NOMINAL'}
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-gray-600 text-[8px] uppercase">Active Pacemaker</span>
                  <span className="font-bold text-gray-300">
                    {somaticData.heartRate} BPM <span className="text-[8px] text-gray-600">({tickerInterval}ms)</span>
                  </span>
                </div>
              </div>

              {/* Interaction Callout */}
              <div className="hidden sm:block text-[8px] font-mono text-gray-600 bg-black/40 backdrop-blur-sm px-2 py-1 rounded">
                Click and drag WebGL to orient spinal structures
              </div>
            </div>
          </div>

          {/* Quick Stats overview cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3 bg-gray-900/20 rounded-lg border border-gray-900 font-mono text-[11px] flex flex-col gap-1">
              <span className="text-gray-600 text-[8px] uppercase">CV Optic Velocity</span>
              <span className="text-lg font-bold text-cyan-400">{somaticData.velocity.toFixed(3)} <span className="text-xs text-gray-500">v</span></span>
            </div>
            <div className="p-3 bg-gray-900/20 rounded-lg border border-gray-900 font-mono text-[11px] flex flex-col gap-1">
              <span className="text-gray-600 text-[8px] uppercase">Audio Resonance</span>
              <span className="text-lg font-bold text-cyan-400">{(somaticData.resonance432Hz * 100).toFixed(0)}% <span className="text-xs text-gray-500">at 432Hz</span></span>
            </div>
            <div className="p-3 bg-gray-900/20 rounded-lg border border-gray-900 font-mono text-[11px] flex flex-col gap-1">
              <span className="text-gray-600 text-[8px] uppercase">Cognitive Load</span>
              <span className="text-lg font-bold text-cyan-400">{somaticData.cognitiveLoad.toFixed(1)}%</span>
            </div>
            <div className="p-3 bg-gray-900/20 rounded-lg border border-gray-900 font-mono text-[11px] flex flex-col gap-1">
              <span className="text-gray-600 text-[8px] uppercase">Pulse Ticker</span>
              <span className="text-lg font-bold text-cyan-400 flex items-center gap-1">
                <Heart size={14} className="text-red-500 fill-red-500 animate-pulse" />
                {somaticData.heartRate} <span className="text-[10px] text-gray-500">bpm</span>
              </span>
            </div>
          </div>
        </section>

        {/* Right Engine Translation sidebar: 3cols */}
        <section className={`xl:col-span-3 flex flex-col gap-5 ${activeTab !== 'engine' ? 'hidden xl:flex' : ''}`}>
          
          {/* Somatic Translation - Engine Room */}
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-4">
            <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
              <Cpu size={14} className="text-cyan-400" />
              Somatic Translation Engine
            </h3>

            {/* Tick heart visualizer */}
            <div className="p-4 bg-black/60 rounded border border-gray-800 flex flex-col items-center justify-center gap-3">
              <div className="relative">
                <Heart 
                  size={52} 
                  style={{ animationDuration: `${60 / somaticData.heartRate}s` }}
                  className={`text-red-500 fill-red-500/20 transition-all ${somaticData.adrenalineState ? 'animate-ping opacity-25 absolute inset-0' : ''}`}
                />
                <Heart 
                  size={52} 
                  style={{ 
                    animationDuration: `${60 / somaticData.heartRate}s`,
                    transform: `scale(${1.0 + somaticData.audioIntensity * 0.3})`
                  }}
                  className="text-red-500 fill-red-500 animate-pulse relative"
                />
              </div>
              <div className="text-center font-mono text-[10px] text-gray-400">
                <span className="text-[8px] text-gray-600 uppercase block">Active Pacemaker Interval</span>
                <span className="text-xs font-bold text-cyan-400">{tickerInterval}ms / Cycle</span>
                <span className="text-[8px] text-gray-500 block mt-0.5">WS packet broadcast rate scaling</span>
              </div>
            </div>

            {/* Endocrine System Adrenaline scaling */}
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-gray-400 uppercase">Endocrine Adrenaline</span>
                <button
                  onClick={() => handleSliderChange('adrenalineState', !somaticData.adrenalineState)}
                  className={`px-2.5 py-1 text-[9px] font-bold font-display uppercase tracking-wider rounded border ${somaticData.adrenalineState ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse' : 'bg-gray-950 border-gray-800 text-gray-400'}`}
                >
                  {somaticData.adrenalineState ? 'ACTIVE (Yang)' : 'IDLE (Yin)'}
                </button>
              </div>
              <p className="text-[9px] font-mono text-gray-500 leading-normal bg-black/20 p-2 rounded">
                High-energy inputs trigger Adrenaline. In a physical environment, this scales node threads and up-scales active cognitive compute capacity from 4GB to 16GB.
              </p>
            </div>

            {/* Polarity state balance config */}
            <div className="flex flex-col gap-2 pt-2 border-t border-gray-800">
              <div className="flex items-center justify-between font-mono text-[10px]">
                <span className="text-gray-400 uppercase">Polarity Balancer</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={autoBalancePolarity} 
                    onChange={(e) => setAutoBalancePolarity(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-7 h-4 bg-gray-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-gray-400 after:border-gray-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-cyan-500 peer-checked:after:bg-black" />
                  <span className="ml-1 text-[9px] uppercase font-bold text-gray-500">Auto</span>
                </label>
              </div>

              {!autoBalancePolarity && (
                <div className="grid grid-cols-2 gap-1 p-1 bg-black/40 rounded border border-white/5">
                  <button
                    onClick={() => handleSliderChange('polarityState', 'yin')}
                    className={`px-2 py-1 text-[8px] font-mono uppercase font-bold rounded ${somaticData.polarityState === 'yin' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500'}`}
                  >
                    Yin Calm
                  </button>
                  <button
                    onClick={() => handleSliderChange('polarityState', 'yang')}
                    className={`px-2 py-1 text-[8px] font-mono uppercase font-bold rounded ${somaticData.polarityState === 'yang' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'text-gray-500'}`}
                  >
                    Yang Processing
                  </button>
                </div>
              )}
            </div>

            {/* Live Spinal Cord Process Monitor */}
            <div className="flex flex-col gap-1.5 pt-3 border-t border-gray-800">
              <span className="text-[8px] font-mono font-bold text-gray-600 uppercase">antiX Core Thread Allocation</span>
              <div className="bg-black/80 font-mono text-[9px] text-gray-400 p-2.5 rounded border border-gray-800/80 h-32 overflow-y-auto flex flex-col gap-1">
                <div><span className="text-gray-600">[sys_init]</span> somatic memory pool mapped.</div>
                <div><span className="text-gray-600">[threads]</span> spinal broker loaded (PID 1290).</div>
                <div><span className="text-gray-600">[websocket]</span> socket channel active on port 3000.</div>
                <div className="text-emerald-500">
                  <span className="text-gray-600">[heart]</span> pulse core: {somaticData.heartRate} bpm.
                </div>
                {somaticData.adrenalineState && (
                  <>
                    <div className="text-red-400 animate-pulse"><span className="text-red-500 font-bold">!! [adrenaline]</span> heavy flow detected.</div>
                    <div className="text-red-400"><span className="text-gray-600">[scaling]</span> allocating upscaled memory segment (16GB RAM mode).</div>
                    <div className="text-red-400"><span className="text-gray-600">[scaling]</span> performance governor forced on all 8 cores.</div>
                  </>
                )}
                {!somaticData.adrenalineState && (
                  <div><span className="text-gray-600">[scaling]</span> safe baseline operation (4GB dynamic stack).</div>
                )}
                <div className="text-cyan-400"><span className="text-gray-600">[telemetry]</span> packet broadcast delay: {tickerInterval}ms.</div>
              </div>
            </div>
          </div>
        </section>

      </main>

      {/* 4. Bottom Grid - Gemini Oracle, Python Hardware Connector */}
      <footer className="grid grid-cols-1 xl:grid-cols-12 gap-5 p-5 max-w-[1700px] w-full mx-auto border-t border-gray-900 mt-auto">
        
        {/* Gemini AI Cognitive Core Somatic Oracle: 7cols */}
        <section className={`xl:col-span-7 flex flex-col gap-3 ${activeTab === 'oracle' ? 'col-span-12' : ''}`}>
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-3 h-full">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
                <Sparkles size={14} className="text-amber-400" />
                Gemini Cognitive Core: Somatic Oracle
              </h3>
              <span className="text-[9px] font-mono text-gray-600 uppercase">MODEL: gemini-3.8-flash</span>
            </div>

            <p className="text-[11px] text-gray-400 leading-relaxed font-sans -mt-1">
              Query the core AI to translate environmental telemetry and live body readings into directives, cybernetic status updates, and hardware balancing suggestions.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 flex-1">
              {/* Prompts controls */}
              <div className="md:col-span-4 flex flex-col gap-2">
                <span className="text-[9px] font-mono font-bold text-gray-600 uppercase">Presets Directives</span>
                <button
                  disabled={oracleLoading}
                  onClick={() => handleOracleQuery("Draft cyber-dragon action directive for active node systems.")}
                  className="px-2.5 py-1.5 text-left text-[9px] font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-500/20 rounded hover:bg-cyan-950/40 transition-colors flex items-center justify-between"
                >
                  <span>Draft Action Directive</span>
                  <ChevronRight size={10} />
                </button>
                <button
                  disabled={oracleLoading}
                  onClick={() => handleOracleQuery("Analyze the 432Hz harmonic wave tuning resonance of our studio environment.")}
                  className="px-2.5 py-1.5 text-left text-[9px] font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-500/20 rounded hover:bg-cyan-950/40 transition-colors flex items-center justify-between"
                >
                  <span>Analyze 432Hz Resonance</span>
                  <ChevronRight size={10} />
                </button>
                <button
                  disabled={oracleLoading}
                  onClick={() => handleOracleQuery("Execute a stress-test on current endocrine systems & calculate dilation values.")}
                  className="px-2.5 py-1.5 text-left text-[9px] font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-500/20 rounded hover:bg-cyan-950/40 transition-colors flex items-center justify-between"
                >
                  <span>Stress-Test Dilation</span>
                  <ChevronRight size={10} />
                </button>
              </div>

              {/* Terminal Display */}
              <div className="md:col-span-8 flex flex-col gap-2">
                <div className="bg-black/95 border border-gray-900 rounded p-3 font-mono text-[10px] flex-1 flex flex-col gap-2 max-h-[220px] overflow-y-auto">
                  {oracleLoading ? (
                    <div className="flex items-center gap-2 text-cyan-400 animate-pulse py-4">
                      <RefreshCw size={12} className="animate-spin" />
                      <span>COGNITIVE MODULE PROCESSING SENSORY STREAM...</span>
                    </div>
                  ) : oracleError ? (
                    <div className="flex items-center gap-2 text-red-400 py-4">
                      <AlertTriangle size={12} />
                      <span>CORE ERROR: {oracleError}</span>
                    </div>
                  ) : oracleResponse ? (
                    <div className="flex flex-col gap-2 leading-relaxed">
                      <div>
                        <span className="text-cyan-500 uppercase text-[8px] block font-bold">// POETIC STATUS</span>
                        <span className="text-gray-300">{oracleResponse.statusUpdate}</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1.5 border-t border-gray-900">
                        <div>
                          <span className="text-amber-400 uppercase text-[8px] block font-bold">// ADRENALINE ANALYSIS</span>
                          <span className="text-gray-400 text-[9px]">{oracleResponse.adrenalineAnalysis}</span>
                        </div>
                        <div>
                          <span className="text-cyan-400 uppercase text-[8px] block font-bold">// WEBGL SKIN AURA</span>
                          <span className="text-gray-400 text-[9px]">{oracleResponse.somaticAura}</span>
                        </div>
                      </div>
                      <div className="pt-1.5 border-t border-gray-900">
                        <span className="text-emerald-400 uppercase text-[8px] block font-bold">// CRITICAL TERMINAL DIRECTIVES</span>
                        <div className="flex flex-col gap-0.5 mt-1 text-[9px] text-emerald-500/90 font-mono bg-black p-1.5 border border-emerald-950/30 rounded">
                          {oracleResponse.systemDirectives.map((cmd, idx) => (
                            <div key={idx} className="flex items-center gap-1.5">
                              <span>&gt;_</span>
                              <span>{cmd}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-gray-600 text-center py-6">
                      Spinal cord terminal ready. Trigger manual or automatic sensory analysis above.
                    </div>
                  )}
                </div>

                {/* Input block */}
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleOracleQuery(); }}
                  className="flex gap-2"
                >
                  <input
                    type="text"
                    value={oracleInput}
                    onChange={(e) => setOracleInput(e.target.value)}
                    placeholder="Ask Gemini to translate current physical states to system directives..."
                    className="flex-1 px-3 py-1.5 text-xs font-mono bg-black border border-gray-900 rounded focus:outline-none focus:border-cyan-500 text-gray-200"
                  />
                  <button
                    type="submit"
                    disabled={oracleLoading || !oracleInput}
                    className="px-3 py-1.5 text-xs font-bold font-display uppercase bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/30 text-cyan-400 rounded transition-colors"
                  >
                    Transmit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Local Hardware Bus Connector (Python Script): 5cols */}
        <section className={`xl:col-span-5 flex flex-col gap-3 ${activeTab === 'inputs' ? 'col-span-12' : ''}`}>
          <div className="p-4 bg-gray-900/40 backdrop-blur-md rounded-lg border border-gray-900 flex flex-col gap-2 h-full">
            <h3 className="text-xs font-bold font-display tracking-wider text-gray-300 uppercase flex items-center gap-2">
              <Code2 size={14} className="text-cyan-400" />
              Physical Optic & Auditory Nerve Hardware Bridge
            </h3>
            
            <p className="text-[11px] text-gray-400 leading-normal">
              Bring Cyber Dragon out of the server rack! Copy this local Python script to stream high-fidelity hand gesture vision and pyAudio sound telemetry straight to the Express Somatic spinal cord on your antiX Linux rig.
            </p>

            {/* Code clipboard block */}
            <div className="relative flex-1 bg-black p-3 rounded border border-gray-900 overflow-hidden min-h-[140px] flex flex-col">
              <span className="text-[8px] font-mono text-cyan-500 block mb-1 font-bold">MOCK_GESTURE_CV_BRIDGE.PY</span>
              <pre className="text-[9px] font-mono text-gray-400 leading-relaxed overflow-y-auto max-h-[140px] flex-1">
{`# Cyber Dragon Somatic Matrix Bus Integration Script
import cv2
import websockets
import asyncio
import json
import numpy as np

async def main():
    uri = "ws://localhost:3000/somatic-bus"
    async with websockets.connect(uri) as websocket:
        print("[Optic Nerve] Spinal bus link established!")
        cap = cv2.VideoCapture(0)
        _, prev_frame = cap.read()
        prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break
            
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            diff = cv2.absdiff(gray, prev_gray)
            mean_diff = np.mean(diff) # Velocity/volume
            
            # Map optical differences to velocity
            velocity = float(np.clip(mean_diff / 5.0, 0.05, 2.0))
            
            # Broadcast raw telemetry to Express node
            payload = {
                "type": "sensor-telemetry",
                "velocity": velocity,
                "audioIntensity": 0.15,
                "frequency": 432.0,
                "resonance432Hz": 0.95
            }
            await websocket.send(json.dumps(payload))
            prev_gray = gray
            await asyncio.sleep(0.05) # 20 ticks/sec

asyncio.run(main())`}
              </pre>
              <div className="mt-2 flex justify-between items-center text-[8px] font-mono text-gray-500 pt-2 border-t border-gray-900">
                <span>Requires: opencv-python, websockets</span>
                <span className="text-cyan-400 font-bold bg-cyan-950/20 px-1 border border-cyan-500/10">WSS://HOST/SOMATIC-BUS</span>
              </div>
            </div>
          </div>
        </section>

      </footer>
    </div>
  );
}
