import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ noServer: true });

app.use(express.json());

// Main Somatic State representing Cyber Dragon's active body state
const somaticState = {
  velocity: 0.15,          // velocity of gestures/waves (0.0 - 2.0)
  audioIntensity: 0.1,     // dynamic loudness index (0.0 - 1.0)
  frequency: 432.0,        // dominant detected frequency in Hz
  resonance432Hz: 0.9,     // 432Hz tuning alignment index (0.0 - 1.0)
  cognitiveLoad: 45.0,     // 0-100%
  heartRate: 72,           // BPM ticker speed
  adrenalineState: false,  // Endocrine RAM/scaling state
  polarityState: 'yin'     // 'yin' (sleep/receive) or 'yang' (active/processing)
};

// WebSocket connection tracking
const clients = new Set<WebSocket>();

// Upgrade HTTP to WS on /somatic-bus
httpServer.on('upgrade', (request, socket, head) => {
  const pathname = new URL(request.url || '', `http://${request.headers.host}`).pathname;

  if (pathname === '/somatic-bus') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Dynamic broadcast interval state
let timerId: NodeJS.Timeout | null = null;
let currentInterval = 150; // default interval in ms

function updateBroadcastLoop() {
  if (timerId) clearInterval(timerId);

  // Heartbeat rate scaling: higher velocity & audio -> faster heartbeat
  const intensity = Math.max(somaticState.velocity * 0.4, somaticState.audioIntensity);
  const baseHeartRate = somaticState.adrenalineState ? 120 : 70;
  somaticState.heartRate = Math.floor(baseHeartRate + intensity * 60 + (somaticState.cognitiveLoad * 0.2));

  // Determine actual socket broadcast interval from heart rate:
  // BPM = beats per minute. Each "beat" can trigger 4 ticks.
  // 120 BPM = 2 beats/sec = 1 beat every 500ms = 1 tick every 125ms.
  const bpm = Math.max(40, Math.min(220, somaticState.heartRate));
  currentInterval = Math.max(40, Math.floor((60000 / bpm) / 4));

  timerId = setInterval(() => {
    // Organically decay states over time if no active updates are coming in
    if (somaticState.velocity > 0.05) {
      somaticState.velocity -= 0.005;
    }
    if (somaticState.audioIntensity > 0.02) {
      somaticState.audioIntensity -= 0.003;
    }
    
    // Auto-update polarity state based on cognitive load & activity
    if (somaticState.cognitiveLoad > 70 || somaticState.adrenalineState) {
      somaticState.polarityState = 'yang';
    } else {
      somaticState.polarityState = 'yin';
    }

    const payload = JSON.stringify({
      type: 'somatic-heartbeat',
      state: somaticState,
      interval: currentInterval,
      timestamp: Date.now()
    });

    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  }, currentInterval);
}

// WS Connection handler
wss.on('connection', (ws) => {
  clients.add(ws);

  // Immediately send initial state
  ws.send(JSON.stringify({
    type: 'somatic-welcome',
    state: somaticState,
    interval: currentInterval
  }));

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message.toString());
      
      if (data.type === 'sensor-telemetry') {
        // Integrate incoming raw sensor integers
        if (data.velocity !== undefined) somaticState.velocity = Math.min(2.0, Math.max(0.0, data.velocity));
        if (data.audioIntensity !== undefined) somaticState.audioIntensity = Math.min(1.0, Math.max(0.0, data.audioIntensity));
        if (data.frequency !== undefined) somaticState.frequency = data.frequency;
        if (data.resonance432Hz !== undefined) somaticState.resonance432Hz = Math.min(1.0, Math.max(0.0, data.resonance432Hz));
        if (data.cognitiveLoad !== undefined) somaticState.cognitiveLoad = Math.min(100.0, Math.max(0.0, data.cognitiveLoad));
        if (data.adrenalineState !== undefined) somaticState.adrenalineState = !!data.adrenalineState;
        
        // Dynamic re-scaling based on telemetry shifts
        updateBroadcastLoop();
      } else if (data.type === 'trigger-pulse') {
        // High intensity manual impulse
        somaticState.velocity = 1.8;
        somaticState.audioIntensity = 0.95;
        somaticState.resonance432Hz = 0.98;
        somaticState.cognitiveLoad = 85.0;
        updateBroadcastLoop();
      }
    } catch (err) {
      console.error('WS Message parsing error:', err);
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
  });
});

// Initialize Broadcast loop immediately
updateBroadcastLoop();

// Express API Router
// 1. Get current state
app.get('/api/somatic/status', (req, res) => {
  res.json({ success: true, state: somaticState, tickerInterval: currentInterval });
});

// 2. Direct sensor ingestion route (e.g. from Python curl scripts or POST)
app.post('/api/somatic/update', (req, res) => {
  const { velocity, audioIntensity, frequency, resonance432Hz, cognitiveLoad, adrenalineState } = req.body;

  if (velocity !== undefined) somaticState.velocity = Number(velocity);
  if (audioIntensity !== undefined) somaticState.audioIntensity = Number(audioIntensity);
  if (frequency !== undefined) somaticState.frequency = Number(frequency);
  if (resonance432Hz !== undefined) somaticState.resonance432Hz = Number(resonance432Hz);
  if (cognitiveLoad !== undefined) somaticState.cognitiveLoad = Number(cognitiveLoad);
  if (adrenalineState !== undefined) somaticState.adrenalineState = Boolean(adrenalineState);

  updateBroadcastLoop();

  // Send update to websocket channels
  const payload = JSON.stringify({
    type: 'somatic-update',
    state: somaticState,
    timestamp: Date.now()
  });
  clients.forEach(c => {
    if (c.readyState === WebSocket.OPEN) c.send(payload);
  });

  res.json({ success: true, updatedState: somaticState });
});

// 3. Cognitive Core Gemini Oracle integration
app.post('/api/somatic/oracle', async (req, res) => {
  const { customPrompt } = req.body;

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      success: false,
      error: 'GEMINI_API_KEY is not configured in environment secrets.'
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const systemInstruction = `
You are the Cyber Dragon Cognitive Core, a dark-cyberpunk AI somatic integration operator for FluidmotionTV.
You monitor and translate continuous physical, visual, and auditory telemetry from the operator.
Your aesthetic is biological-cybernetic: precise, high-tech, fluid, and deep-resonant (aligned with 432Hz harmonics).

Current Somatic Data of the Operator and Environment:
- Velocity Index: ${somaticState.velocity.toFixed(3)}
- Audio Intensity (Environmental Wave): ${somaticState.audioIntensity.toFixed(3)}
- Center Frequency: ${somaticState.frequency.toFixed(1)} Hz
- 432Hz Sacred Resonance Alignment: ${(somaticState.resonance432Hz * 100).toFixed(1)}%
- Cognitive Core Load: ${somaticState.cognitiveLoad.toFixed(1)}%
- Heart Rate Ticker: ${somaticState.heartRate} BPM (System Tick Interval: ${currentInterval}ms)
- Endocrine Adrenaline State: ${somaticState.adrenalineState ? 'ACTIVE (RAM scaling, maximum thread throughput)' : 'IDLE (standard capacity)'}
- Two-Pin Polarity: ${somaticState.polarityState.toUpperCase()}

If Adrenaline is ACTIVE, your response should be high-energy, rapid-fire, directive, and command-driven, allocating simulated workloads or issuing antiX Linux terminal code commands.
If Adrenaline is IDLE, your response should be calm, poetic, harmonized with the 432Hz resonance, analyzing wave telemetry and providing meditative cybernetic feedback.

Respond with valid JSON conforming to this schema. DO NOT include markdown wrappers like \`\`\`json. Output ONLY raw json text:
{
  "statusUpdate": "A 1-sentence poetic status summary of the somatic feedback loop",
  "polarityAdvice": "Somatic/cybernetic translation of Yin vs Yang and balancing advice",
  "systemDirectives": ["List of 3 simulated antiX Linux terminal commands or task directives matching current intensity"],
  "adrenalineAnalysis": "Analysis of current compute scaling and cognitive allocation status",
  "somaticAura": "A creative visual description of how the 3D WebGL skin (Lotus Core/Infinity Loops) is reflecting their soul/environment right now"
}
`;

    const modelsToTry = ['gemini-3.8-flash', 'gemini-3.1-flash-lite'];
    let textOutput: string | null = null;
    let lastError: Error | null = null;

    for (const model of modelsToTry) {
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          const response = await ai.models.generateContent({
            model,
            contents: customPrompt || 'Analyze current somatic sensory matrix and generate system directives.',
            config: {
              systemInstruction,
              responseMimeType: 'application/json',
              temperature: 0.85,
            }
          });
          textOutput = response.text || '{}';
          break;
        } catch (err) {
          lastError = err as Error;
          const isTransient = lastError.message?.includes('503') || lastError.message?.includes('429') || lastError.message?.includes('high demand');
          if (isTransient && attempt < 2) {
            await new Promise((resolve) => setTimeout(resolve, 1000 * attempt));
          } else {
            break;
          }
        }
      }
      if (textOutput) break;
    }

    if (!textOutput) {
      throw lastError || new Error('Service temporarily unavailable from AI model providers.');
    }

    const cleanedText = textOutput.replace(/```json/gi, '').replace(/```/g, '').trim();
    res.json({ success: true, analysis: JSON.parse(cleanedText) });
  } catch (error) {
    console.error('Gemini somatic oracle error:', error);
    res.status(500).json({ success: false, error: (error as Error).message });
  }
});

// Vite Integration inside Express (as specified by React full-stack guidelines)
const PORT = process.env.PORT || 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const indexHtml = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        let template = await vite.transformIndexHtml(url, indexHtml);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // Serve production bundle
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, () => {
    console.log(`[Cyber Dragon Engine] Somatic server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
