import React, { useState, useEffect, useRef } from 'react';
import { 
  Waves, FileText, Terminal, Settings, Activity, Droplets, Compass, 
  Search, Zap, ShieldAlert, Trash2, HelpCircle, RefreshCw, Play, 
  CheckCircle, AlertCircle, Filter, HardDrive, Info, Share2, Upload, Server
} from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: string;
  content: string;
  createdAt: string;
  metadata: any;
}

interface Chunk {
  id: string;
  documentId: string;
  text: string;
  index: number;
  charStart: number;
  charEnd: number;
  length: number;
  isJunk: boolean;
  embedding?: number[];
  digestivePurity: number;
}

interface Log {
  id: string;
  timestamp: string;
  phase: 'mouth' | 'stomach' | 'intestines' | 'liver';
  message: string;
  status: 'info' | 'success' | 'warn' | 'error';
}

export default function App() {
  // DB States
  const [documents, setDocuments] = useState<Document[]>([]);
  const [chunks, setChunks] = useState<Chunk[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(false);

  // Ingestion States
  const [activeTab, setActiveTab] = useState<'mouth' | 'stomach' | 'intestines' | 'liver'>('mouth');
  const [newDocName, setNewDocName] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [newDocType, setNewDocType] = useState('custom');
  const [newDocMetaAuthor, setNewDocMetaAuthor] = useState('Jay');
  
  // Scraper Simulation State
  const [scrapeUrl, setScrapeUrl] = useState('https://surf-forecast.co.nz/muriwai/live');
  const [isScraping, setIsScraping] = useState(false);

  // Chunker States
  const [selectedDocId, setSelectedDocId] = useState<string>('');
  const [chunkSize, setChunkSize] = useState<number>(500);
  const [chunkOverlap, setChunkOverlap] = useState<number>(100);

  // Filter state for chunks
  const [purityThreshold, setPurityThreshold] = useState<number>(0.2);
  const [hideJunk, setHideJunk] = useState<boolean>(false);

  // Search & Query state
  const [searchQuery, setSearchQuery] = useState('What swell has been logged for Muriwai?');
  const [topK, setTopK] = useState(3);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);

  // Agent State
  const [selectedAgent, setSelectedAgent] = useState<'The Sentinel' | 'The Chronicler' | 'The Alchemist' | 'The Tide-Breaker'>('The Chronicler');
  const [isCirculating, setIsCirculating] = useState(false);
  const [agentOutput, setAgentOutput] = useState('');
  const [sentPayload, setSentPayload] = useState('');

  // 2D Canvas Visualization States
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedCanvasChunk, setSelectedCanvasChunk] = useState<Chunk | null>(null);
  const [hoveredChunk, setHoveredChunk] = useState<Chunk | null>(null);

  // Fetch initial Database
  const fetchDB = async () => {
    try {
      const res = await fetch('/api/db');
      const data = await res.json();
      setDocuments(data.documents);
      setChunks(data.chunks);
      setLogs(data.logs);
      
      // Auto select first doc for splitting if none selected
      if (!selectedDocId && data.documents.length > 0) {
        setSelectedDocId(data.documents[0].id);
      }
    } catch (err) {
      console.error("Error fetching database", err);
    }
  };

  useEffect(() => {
    fetchDB();
  }, []);

  // Sync canvas nodes periodically or when chunks change
  useEffect(() => {
    drawSemanticUniverse();
  }, [chunks, hoveredChunk, selectedCanvasChunk]);

  // Reset database to seeds
  const handleReset = async () => {
    if (!confirm("Are you sure you want to reset the biological database? All uploaded logs and custom vector coordinates will be wiped.")) return;
    setLoading(true);
    try {
      const res = await fetch('/api/reset', { method: 'POST' });
      const data = await res.json();
      setDocuments(data.documents);
      setChunks(data.chunks);
      setLogs(data.logs);
      setSelectedDocId(data.documents[0].id);
      setSelectedCanvasChunk(null);
      setSearchResults([]);
      setAgentOutput('');
      setSentPayload('');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Live Scrape Feed
  const triggerScraper = () => {
    setIsScraping(true);
    setTimeout(() => {
      const fakeSwellScrape = `[SCRAPER LIVE - Auckland West Coast swell sensors]
STATION: MURIWAI - SHAG ROCK LEDGE
LATITUDE: -36.82 N LONGITUDE: 174.42 E
LIVE SWELL MATRIX UPDATE:
- Primary Swell Direction: WSW 220 deg
- Swell Height Range: 5.2ft - 5.8ft (Solid groundswell feeding sandbanks)
- Dominant Period: 13.8 seconds
- Wind Force: ENE 9 knots (Offshore blowback)
- Ocean Temperature: 14.8C
- Barometric Pressure: 1018 hPa (Steady high)
- Coastal Surf Quality Index: 8/10 (Excellent grooming)
Swell generated from deep Tasman storm cell. Offshore east winds projected to continue until 15:45 NZDT. High tide at 14:15. Perfect swallowtail conditions.`;
      
      handleManualIngest("Muriwai_Live_Forecast_Scraped.html", fakeSwellScrape, "surf-report", {
        scrapedUrl: scrapeUrl,
        scrapedAt: new Date().toISOString()
      });
      setIsScraping(false);
      setActiveTab('mouth');
    }, 1200);
  };

  // Custom File / Text Ingestion
  const handleIngestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocName || !newDocContent) return;
    await handleManualIngest(newDocName, newDocContent, newDocType, { author: newDocMetaAuthor });
    setNewDocName('');
    setNewDocContent('');
  };

  const handleManualIngest = async (name: string, content: string, type: string, metadata: any = {}) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, content, type, metadata })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        return;
      }
      setDocuments(data.db.documents);
      setLogs(data.db.logs);
      setSelectedDocId(data.document.id);
      // Automatically navigate to Stomach to partition the raw meat
      setActiveTab('stomach');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Trigger Chunk Splitting
  const handleSplit = async () => {
    if (!selectedDocId) return;
    setLoading(true);
    try {
      const res = await fetch('/api/chunk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentId: selectedDocId,
          chunkSize,
          chunkOverlap
        })
      });
      const data = await res.json();
      setChunks(data.db.chunks);
      setLogs(data.db.logs);
      // Auto move to Embed stage to digest them into vectors
      setActiveTab('intestines');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Embed Single Chunk
  const embedChunk = async (chunkId: string) => {
    try {
      const res = await fetch('/api/embed-chunk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chunkId })
      });
      const data = await res.json();
      if (data.error) {
        alert("Gemini Embedding Error: " + data.error);
        return;
      }
      setChunks(data.db.chunks);
      setLogs(data.db.logs);
    } catch (err) {
      console.error(err);
    }
  };

  // Embed All Chunks for Selected Doc
  const embedAllChunks = async () => {
    if (!selectedDocId) return;
    setLoading(true);
    try {
      const res = await fetch('/api/embed-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentId: selectedDocId })
      });
      const data = await res.json();
      if (data.error) {
        alert("Gemini Embedding Error: " + data.error);
        return;
      }
      setChunks(data.db.chunks);
      setLogs(data.db.logs);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Execute Semantic Search
  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery) return;
    setIsSearching(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery, topK })
      });
      const data = await res.json();
      if (data.error) {
        alert("Search Failed: " + data.error);
        return;
      }
      setSearchResults(data.results);
      setLogs(data.db.logs);
      
      // Auto pre-populate context for active Core Nine agents circulation
      const tempContext = data.results && data.results.length > 0 
        ? data.results.map((r: any) => `[Source Chunks from ${r.documentName} (Similarity: ${(r.similarity * 100).toFixed(1)}%)]\n${r.text}`).join('\n\n')
        : "";
      setSentPayload(tempContext);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  // Circulate Prompt to selected Core Nine Agent
  const triggerCirculation = async () => {
    if (!searchQuery) return;
    setIsCirculating(true);
    setAgentOutput('');
    try {
      const res = await fetch('/api/circulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentName: selectedAgent,
          query: searchQuery,
          searchResults: searchResults
        })
      });
      const data = await res.json();
      if (data.error) {
        alert("Circulation failed: " + data.error);
        return;
      }
      setAgentOutput(data.agentResponse);
      setSentPayload(data.promptSent);
      setLogs(data.db.logs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsCirculating(false);
    }
  };

  // Draw simulated 2D PCA representation of standard embedded chunks
  const drawSemanticUniverse = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Filter chunks
    const visibleChunks = chunks.filter(c => {
      if (hideJunk && c.isJunk) return false;
      if (c.digestivePurity < purityThreshold) return false;
      return true;
    });

    if (visibleChunks.length === 0) {
      ctx.fillStyle = '#6b7280';
      ctx.font = '12px Courier New';
      ctx.textAlign = 'center';
      ctx.fillText('NO HIGH-DENSITY CHUNKS LOGGED', width / 2, height / 2);
      return;
    }

    // Grid lines
    ctx.strokeStyle = '#1e1b4b';
    ctx.lineWidth = 1;
    for (let x = 50; x < width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 50; y < height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Map high-dim onto 2D space deterministically
    visibleChunks.forEach((chunk) => {
      // Deterministic spread based on string hash to make vectors cluster nicely
      let hashX = 0;
      let hashY = 0;
      const textSample = chunk.text;
      for (let i = 0; i < textSample.length; i++) {
        hashX = textSample.charCodeAt(i) + ((hashX << 5) - hashX);
        hashY = textSample.charCodeAt((i + 2) % textSample.length) + ((hashY << 5) - hashY);
      }

      // Check if some strings belong to the same parent categories for beautiful visual clustering
      let docCategoryBiasX = 0;
      let docCategoryBiasY = 0;
      if (chunk.text.toLowerCase().includes('surf') || chunk.text.toLowerCase().includes('swell')) {
        docCategoryBiasX = -60;
        docCategoryBiasY = -40;
      } else if (chunk.text.toLowerCase().includes('clock') || chunk.text.toLowerCase().includes('time')) {
        docCategoryBiasX = 60;
        docCategoryBiasY = 50;
      } else if (chunk.text.toLowerCase().includes('linux') || chunk.text.toLowerCase().includes('hardware')) {
        docCategoryBiasX = -40;
        docCategoryBiasY = 60;
      }

      const x = (width / 2) + docCategoryBiasX + (Math.sin(hashX) * (width * 0.35));
      const y = (height / 2) + docCategoryBiasY + (Math.cos(hashY) * (height * 0.35));

      // Coordinate matching for selection/hover testing
      // We can inject x and y back into the node for click detection!
      (chunk as any).canvasX = x;
      (chunk as any).canvasY = y;

      const isSelected = selectedCanvasChunk?.id === chunk.id;
      const isHovered = hoveredChunk?.id === chunk.id;
      const isEmbedded = !!chunk.embedding;

      // Draw connection lines to active vectors
      if (isSelected) {
        ctx.strokeStyle = 'rgba(236, 72, 153, 0.3)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y, 22, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Particle body
      ctx.beginPath();
      ctx.arc(x, y, isSelected ? 8 : (isHovered ? 6 : 4), 0, Math.PI * 2);
      
      if (!isEmbedded) {
        ctx.fillStyle = '#ef4444'; // Un-embedded chunks glow red
      } else if (chunk.text.toLowerCase().includes('surf') || chunk.text.toLowerCase().includes('swell')) {
        ctx.fillStyle = '#06b6d4'; // Cyans for wave mechanics
      } else if (chunk.text.toLowerCase().includes('clock') || chunk.text.toLowerCase().includes('time')) {
        ctx.fillStyle = '#d946ef'; // Purples for dragon cycles
      } else {
        ctx.fillStyle = '#10b981'; // Greens for other system files
      }
      ctx.fill();

      // Label drawing for selected/hovered nodes
      if (isHovered || isSelected) {
        ctx.fillStyle = '#ffffff';
        ctx.font = '10px Courier New';
        ctx.textAlign = 'center';
        ctx.fillText(
          `Chunk #${chunk.index} (${isEmbedded ? 'EMBEDDED' : 'RAW'})`,
          x,
          y - 12
        );
      }
    });
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Scale mouse coordinates in case CSS scales canvas
    const x = (mouseX / rect.width) * canvas.width;
    const y = (mouseY / rect.height) * canvas.height;

    const found = chunks.find((c: any) => {
      if (!c.canvasX || !c.canvasY) return false;
      const dx = c.canvasX - x;
      const dy = c.canvasY - y;
      return Math.sqrt(dx * dx + dy * dy) < 12;
    });

    setHoveredChunk(found || null);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (hoveredChunk) {
      setSelectedCanvasChunk(hoveredChunk);
    } else {
      setSelectedCanvasChunk(null);
    }
  };

  // Text Splitter Highlight renderer
  const renderVisualChunks = () => {
    const doc = documents.find(d => d.id === selectedDocId);
    if (!doc) return <div className="text-gray-500 italic">Select a source file to analyze stomach activity.</div>;

    const docChunks = chunks.filter(c => c.documentId === selectedDocId);
    if (docChunks.length === 0) {
      return (
        <div className="text-gray-400 font-mono text-xs bg-slate-950 p-4 border border-dashed border-cyan-900 rounded">
          <Info className="inline mr-2 w-4 h-4 text-cyan-400" />
          No chunks active. Adjust the sliders and press "ACTIVATE DIGESTIVE ENZYMES" to split the text.
        </div>
      );
    }

    // Reconstruct visual overlap representation
    let textIdx = 0;
    const segments: React.ReactNode[] = [];

    // Sort chunks by charStart
    const sortedChunks = [...docChunks].sort((a, b) => a.charStart - b.charStart);

    sortedChunks.forEach((c, idx) => {
      // If there is a gap, render standard gray text
      if (c.charStart > textIdx) {
        segments.push(
          <span key={`gap-${idx}`} className="text-slate-500">
            {doc.content.substring(textIdx, c.charStart)}
          </span>
        );
      }

      // Check if we overlap with previous chunk
      const hasPrevOverlap = idx > 0 && c.charStart < sortedChunks[idx - 1].charEnd;
      
      if (hasPrevOverlap) {
        const overlapStart = c.charStart;
        const overlapEnd = sortedChunks[idx - 1].charEnd;
        
        // Ensure index order
        segments.push(
          <span 
            key={`overlap-${idx}`} 
            className="bg-yellow-950/70 border-x border-yellow-500/40 text-yellow-300 font-bold px-0.5 relative group cursor-pointer"
            title={`Overlap Boundary: ${overlapEnd - overlapStart} characters`}
          >
            {doc.content.substring(overlapStart, overlapEnd)}
            <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 bg-black text-xs text-yellow-400 py-0.5 px-2 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-10 border border-yellow-700 font-mono">
              [Overlap Chunk {idx-1} ⇹ {idx}]
            </span>
          </span>
        );

        // Render the remainder of the current chunk that doesn't overlap
        if (c.charEnd > overlapEnd) {
          const colorClass = idx % 2 === 0 
            ? "bg-cyan-950/40 text-cyan-200 border-b border-cyan-800/40" 
            : "bg-fuchsia-950/40 text-fuchsia-200 border-b border-fuchsia-800/40";

          segments.push(
            <span key={`chunk-rem-${idx}`} className={`${colorClass} px-0.5`}>
              {doc.content.substring(overlapEnd, c.charEnd)}
            </span>
          );
        }
      } else {
        // Standard chunk text
        const colorClass = idx % 2 === 0 
          ? "bg-cyan-950/40 text-cyan-200 border-b border-cyan-800/40" 
          : "bg-fuchsia-950/40 text-fuchsia-200 border-b border-fuchsia-800/40";

        segments.push(
          <span key={`chunk-${idx}`} className={`${colorClass} px-0.5`}>
            {doc.content.substring(c.charStart, c.charEnd)}
          </span>
        );
      }

      textIdx = c.charEnd;
    });

    // Render trailing text
    if (textIdx < doc.content.length) {
      segments.push(
        <span key="trail" className="text-slate-500">
          {doc.content.substring(textIdx)}
        </span>
      );
    }

    return (
      <div className="bg-slate-950 p-4 border border-slate-800 rounded font-mono text-[11px] leading-relaxed max-h-[350px] overflow-y-auto whitespace-pre-wrap select-text">
        {segments}
      </div>
    );
  };

  // Seed file picker to directly swallow
  const selectPresetFeed = (presetIdx: number) => {
    const presets = [
      {
        name: "Muriwai_Pee_Dub_Surf_Log.txt",
        content: `CYBER DRAGON SURF LOGS -- EPISODE 4 -- PEE DUB
LOCATION: Muriwai (Pee Dub), West Coast, New Zealand
DATE: 2026-10-02
SWELL: Solid 4-6ft swell from the SW, hitting the shallow banks with clean open shoulders. Period is sitting at 14 seconds, generating crisp, powerful lines.
WINDS: Offshore east-northeast winds at 10-12 knots, grooming the face of the wave. Clean, glass-like barrels on the mid-tide drop.
TIDE: High tide at 14:15, low tide at 08:30. Best window is between 11:30 and 15:30.
OBSERVATION: Jay paddling out on the 6'2 swallowtail. Heavy currents near the southern rock ledge, but the rip is serving as a perfect conveyor belt to the takeoff zone. Swell is clean, long-period energy rolling in from deep Southern Ocean storms. Cyber Dragon biological clock (Dragon 9) coordinates the session to optimize for lighting before the evening westerly onshore winds set in.`,
        type: "surf-report"
      },
      {
        name: "Dragon_Clock_System_Script.md",
        content: `# Cyber Dragon Biological Clock - Dragon 9 System Script
The system operates on an unconventional biological time system. While human operators live in GMT/NZDT, the Core Nine agents exist in the "Dragon 9 Cycle" — an internal clock synched to computer heat sink temperatures, disk read cycles, and local sea tide levels.
When the Dragon 9 clock triggers a tick:
1. The Mouth pulls the swell metrics and logs.
2. The Stomach digests this information, feeding raw tokens into active memory.
3. The Intestines embed this semantic meaning into the Static Pin (local vector store).
4. The Bloodstream pumps the custom prompt context.

The Two-Pin Polarity governs active storage:
- Static Pin (ChromaDB style local database): Permanent semantic history.
- Floating Pin: Transient, real-time sensory data that decays within 108 minutes.
If the engine loses context, it enters "The Starvation State" where agent outputs become erratic, generic, or default to standard AI slop.`,
        type: "script"
      },
      {
        name: "antiX_Linux_Rig_Diagnostic.log",
        content: `[2026-10-02 01:00:10] [SYSTEM] Initializing antiX Linux kernel on Cyber Dragon primary rig...
[2026-10-02 01:00:12] [HARDWARE] Detecting hardware interface. Dual-core CPU clock stable at 3.2GHz. Temp: 42C.
[2026-10-02 01:00:15] [CLOCK] Syncing local tide hardware clocks with Muriwai surf forecast API.
[2026-10-02 01:00:18] [STORAGE] Vector database ChromaDB replica online. Static Pin state: ACTIVE.
[2026-10-02 01:00:25] [MEMORY] Ram clean-up. Free swap memory: 8.4GB. Running custom daemon for Dragon 9 ticker.
[2026-10-02 01:01:00] [ALERT] System load normal. Nutrient level sitting at 92%. Pumping real-time tokens to "The Sentinel" and "The Chronicler". No buffer overflows detected.`,
        type: "log"
      }
    ];

    const preset = presets[presetIdx];
    setNewDocName(preset.name);
    setNewDocContent(preset.content);
    setNewDocType(preset.type);
  };

  // Filter logs for visual scroll panel
  const getPhaseColor = (phase: string) => {
    switch (phase) {
      case 'mouth': return 'text-cyan-400 border-cyan-900';
      case 'stomach': return 'text-amber-400 border-amber-900';
      case 'intestines': return 'text-emerald-400 border-emerald-900';
      case 'liver': return 'text-fuchsia-400 border-fuchsia-900';
      default: return 'text-slate-400 border-slate-900';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* HUD Navigation Banner */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur sticky top-0 z-50 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-cyan-950/50 border border-cyan-500/50 flex items-center justify-center animate-pulse">
            <Waves className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-md font-bold tracking-wider font-mono text-cyan-400">
              CYBER DRAGON <span className="text-fuchsia-500 font-sans">EPISODE 4</span>
            </h1>
            <p className="text-[10px] text-slate-500 font-mono">SYSTEM ANATOMY: THE DIGESTIVE DATA PIPELINE</p>
          </div>
        </div>

        {/* Global Dials */}
        <div className="hidden md:flex items-center space-x-6 text-xs font-mono">
          <div className="flex items-center space-x-2 border-l border-slate-900 pl-4">
            <Droplets className="w-4 h-4 text-cyan-400 animate-bounce" />
            <div>
              <div className="text-[9px] text-slate-500">DIGESTIVE FLOW</div>
              <div className="text-cyan-300 font-bold">12,400 T/S</div>
            </div>
          </div>
          <div className="flex items-center space-x-2 border-l border-slate-900 pl-4">
            <Activity className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[9px] text-slate-500">STATIC PIN RESERVES</div>
              <div className="text-emerald-400 font-bold">{chunks.filter(c => !!c.embedding).length} VECTORS</div>
            </div>
          </div>
          <div className="flex items-center space-x-2 border-l border-slate-900 pl-4">
            <Server className="w-4 h-4 text-fuchsia-400" />
            <div>
              <div className="text-[9px] text-slate-500">DRAGON 9 CLOCK</div>
              <div className="text-fuchsia-400 font-bold">CYCLE_04 : OK</div>
            </div>
          </div>
        </div>

        <button 
          onClick={handleReset}
          className="bg-slate-900 border border-slate-800 text-slate-400 hover:text-red-400 px-3 py-1.5 rounded text-xs font-mono flex items-center space-x-1.5 transition-all"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>WIPE MEMORY</span>
        </button>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Anatomy Flow Selector */}
        <div className="lg:col-span-12 bg-slate-900/45 border border-slate-900 p-2 rounded-xl flex flex-wrap gap-2 justify-between items-center">
          <div className="flex items-center space-x-2 px-3 py-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span className="text-[10px] text-slate-400 font-mono tracking-wider">PIPELINE STAGE SELECTOR:</span>
          </div>

          <div className="flex flex-1 min-w-0 flex-wrap gap-2 justify-end">
            <button
              onClick={() => setActiveTab('mouth')}
              className={`px-4 py-2 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'mouth'
                  ? 'bg-cyan-950/80 border border-cyan-500/60 text-cyan-300 shadow-md shadow-cyan-950/50'
                  : 'bg-slate-950 border border-slate-900 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] text-cyan-600">1.</span>
              <HardDrive className="w-3.5 h-3.5" />
              <span>THE MOUTH (INGEST)</span>
            </button>

            <button
              onClick={() => setActiveTab('stomach')}
              className={`px-4 py-2 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'stomach'
                  ? 'bg-amber-950/80 border border-amber-500/60 text-amber-300 shadow-md shadow-amber-950/50'
                  : 'bg-slate-950 border border-slate-900 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] text-amber-600">2.</span>
              <Settings className="w-3.5 h-3.5" />
              <span>THE STOMACH (CHUNK)</span>
            </button>

            <button
              onClick={() => setActiveTab('intestines')}
              className={`px-4 py-2 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'intestines'
                  ? 'bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-950/50'
                  : 'bg-slate-950 border border-slate-900 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] text-emerald-600">3.</span>
              <Compass className="w-3.5 h-3.5" />
              <span>THE INTESTINES (VECTORIZE)</span>
            </button>

            <button
              onClick={() => setActiveTab('liver')}
              className={`px-4 py-2 rounded-lg font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'liver'
                  ? 'bg-fuchsia-950/80 border border-fuchsia-500/60 text-fuchsia-300 shadow-md shadow-fuchsia-950/50'
                  : 'bg-slate-950 border border-slate-900 text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-[10px] text-fuchsia-600">4.</span>
              <Zap className="w-3.5 h-3.5" />
              <span>THE LIVER (CIRCULATE)</span>
            </button>
          </div>
        </div>

        {/* Left Column: Stage Interaction Console */}
        <div className="lg:col-span-8 flex flex-col space-y-5">
          
          {/* Phase 1 Tab: THE MOUTH */}
          {activeTab === 'mouth' && (
            <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-5 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <HardDrive className="w-5 h-5 text-cyan-400" />
                  <h2 className="text-md font-bold font-mono text-cyan-400">THE MOUTH: Raw Information Ingestion</h2>
                </div>
                <span className="bg-cyan-950 text-cyan-400 font-mono text-[9px] px-2 py-0.5 rounded border border-cyan-800">STATUS: RECEPTIVE</span>
              </div>
              <p className="text-xs text-slate-400">
                A standard LLM is static. Cyber Dragon swallows real-time raw data—surf telemetry, telemetry diagnostic feeds, script parameters, or website outputs—and queues them for parsing.
              </p>

              {/* Feed Preset Injectors */}
              <div className="bg-slate-950 p-4 border border-slate-800 rounded-lg space-y-2">
                <span className="text-[10px] text-slate-500 font-mono">PRE-CONFIGURED FEED SOURCE INJECTORS:</span>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button 
                    onClick={() => selectPresetFeed(0)}
                    className="p-3 bg-cyan-950/15 hover:bg-cyan-950/30 border border-cyan-900/60 hover:border-cyan-500 rounded-lg text-left transition-all"
                  >
                    <div className="text-xs font-bold font-mono text-cyan-400 flex items-center justify-between">
                      <span>Muriwai Surf Feed</span>
                      <Waves className="w-3 h-3" />
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1">SW, 4-6ft, east offshore, tide parameters.</p>
                  </button>

                  <button 
                    onClick={() => selectPresetFeed(1)}
                    className="p-3 bg-fuchsia-950/15 hover:bg-fuchsia-950/30 border border-fuchsia-900/60 hover:border-fuchsia-500 rounded-lg text-left transition-all"
                  >
                    <div className="text-xs font-bold font-mono text-fuchsia-400 flex items-center justify-between">
                      <span>Clock System Script</span>
                      <Terminal className="w-3 h-3" />
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1">Dragon 9 clock sequences & Two-Pin details.</p>
                  </button>

                  <button 
                    onClick={() => selectPresetFeed(2)}
                    className="p-3 bg-emerald-950/15 hover:bg-emerald-950/30 border border-emerald-900/60 hover:border-emerald-500 rounded-lg text-left transition-all"
                  >
                    <div className="text-xs font-bold font-mono text-emerald-400 flex items-center justify-between">
                      <span>antiX Rig Logs</span>
                      <Server className="w-3 h-3" />
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1">CPU clock stable, RAM checks, and warning logs.</p>
                  </button>
                </div>
              </div>

              {/* Manual/Preset Form */}
              <form onSubmit={handleIngestSubmit} className="space-y-4 pt-2">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">SOURCE FILENAME</label>
                    <input 
                      type="text" 
                      placeholder="e.g. piha_swell_status.txt" 
                      value={newDocName} 
                      onChange={e => setNewDocName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">FEED CATEGORY</label>
                    <select
                      value={newDocType}
                      onChange={e => setNewDocType(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                    >
                      <option value="surf-report">surf-report</option>
                      <option value="script">script</option>
                      <option value="log">log</option>
                      <option value="custom">custom</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">OPERATOR INTAKE</label>
                    <input 
                      type="text" 
                      value={newDocMetaAuthor} 
                      onChange={e => setNewDocMetaAuthor(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">RAW TELEMETRY / DOCUMENT TEXT BODY</label>
                  <textarea 
                    rows={6}
                    placeholder="Enter raw text parameters or click one of the preset indicators above to inject Cyber Dragon telemetry parameters..."
                    value={newDocContent}
                    onChange={e => setNewDocContent(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500 resize-none"
                  ></textarea>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    disabled={loading || !newDocName || !newDocContent}
                    className="bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-800 text-black px-5 py-2 rounded font-mono text-xs font-bold transition-all flex items-center space-x-2"
                  >
                    <Upload className="w-4 h-4" />
                    <span>SWALLOW RAW DATA FEED</span>
                  </button>
                </div>
              </form>

              {/* Scraper Panel */}
              <div className="border-t border-slate-900 pt-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <h3 className="text-xs font-bold font-mono text-cyan-400 flex items-center">
                    <Compass className="w-3.5 h-3.5 mr-1.5" />
                    COASTAL SENSOR WEB SCRAPER
                  </h3>
                  <p className="text-[10px] text-slate-400">Scrapes swell models and offshore breeze reports directly from live West Coast beacons.</p>
                </div>
                <div className="flex items-center space-x-2">
                  <input 
                    type="text" 
                    value={scrapeUrl} 
                    onChange={e => setScrapeUrl(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-[11px] font-mono text-slate-400 w-52 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={triggerScraper}
                    disabled={isScraping}
                    className="bg-slate-800 hover:bg-slate-700 text-cyan-400 px-4 py-1.5 rounded font-mono text-xs border border-cyan-900 hover:border-cyan-500 transition-all flex items-center space-x-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isScraping ? 'animate-spin' : ''}`} />
                    <span>SCRAPE SENSORS</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Phase 2 Tab: THE STOMACH */}
          {activeTab === 'stomach' && (
            <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-5 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-amber-400" />
                  <h2 className="text-md font-bold font-mono text-amber-400">THE STOMACH: Slicing & Chunk Overlap Settings</h2>
                </div>
                <span className="bg-amber-950 text-amber-400 font-mono text-[9px] px-2 py-0.5 rounded border border-amber-800">ENZYME ACTION: ACTIVE</span>
              </div>
              <p className="text-xs text-slate-400">
                You cannot feed an LLM an entire 20-page document or raw video transcribing at once. The Stomach breaks logs down into overlapping, contextual chunks, ensuring critical facts on the boundary line are preserved.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 bg-slate-950/60 p-4 border border-slate-800 rounded-xl">
                <div>
                  <label className="block text-xs font-mono text-slate-300 mb-2">1. SELECT SOURCE TARGET FOR THE STOMACH</label>
                  <select 
                    value={selectedDocId} 
                    onChange={e => setSelectedDocId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="">-- Choose Ingested Document --</option>
                    {documents.map((d) => (
                      <option key={d.id} value={d.id}>{d.name} ({d.content.length} chars)</option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <button
                    onClick={handleSplit}
                    disabled={loading || !selectedDocId}
                    className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-slate-800 text-black font-mono font-bold text-xs py-2 px-4 rounded transition-all flex items-center justify-center space-x-2"
                  >
                    <Play className="w-3.5 h-3.5 fill-black" />
                    <span>ACTIVATE DIGESTIVE ENZYMES</span>
                  </button>
                </div>

                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-900 pt-3">
                  <div>
                    <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
                      <span>CHUNK SIZE</span>
                      <span className="text-amber-400 font-bold">{chunkSize} characters</span>
                    </div>
                    <input 
                      type="range" 
                      min="200" 
                      max="1500" 
                      step="50"
                      value={chunkSize}
                      onChange={e => setChunkSize(Number(e.target.value))}
                      className="w-full accent-amber-500 h-1 bg-slate-850 rounded"
                    />
                    <span className="text-[9px] text-slate-500 font-mono">Maximum size in characters for each semantic segment.</span>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
                      <span>CHUNK OVERLAP</span>
                      <span className="text-amber-400 font-bold">{chunkOverlap} characters</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="400" 
                      step="10"
                      value={chunkOverlap}
                      onChange={e => setChunkOverlap(Number(e.target.value))}
                      className="w-full accent-amber-500 h-1 bg-slate-850 rounded"
                    />
                    <span className="text-[9px] text-slate-500 font-mono">Character overlap on the cuts to retain context logic.</span>
                  </div>
                </div>
              </div>

              {/* Real-time Interactive Highlighter */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-300">INTERACTIVE TEXT SEGMENTATION MAP:</span>
                  <div className="flex items-center space-x-3 text-[10px] font-mono">
                    <span className="flex items-center"><span className="w-2.5 h-2.5 bg-cyan-950/80 border border-cyan-800/40 mr-1 rounded-sm"></span> Even Chunks</span>
                    <span className="flex items-center"><span className="w-2.5 h-2.5 bg-fuchsia-950/80 border border-fuchsia-800/40 mr-1 rounded-sm"></span> Odd Chunks</span>
                    <span className="flex items-center"><span className="w-2.5 h-2.5 bg-yellow-950 border border-yellow-800 mr-1 rounded-sm"></span> Context Overlap</span>
                  </div>
                </div>
                {renderVisualChunks()}
              </div>
            </div>
          )}

          {/* Phase 3 Tab: THE INTESTINES */}
          {activeTab === 'intestines' && (
            <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-5 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Compass className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-md font-bold font-mono text-emerald-400">THE INTESTINES: Semantic Vectorization & Purge</h2>
                </div>
                <span className="bg-emerald-950 text-emerald-400 font-mono text-[9px] px-2 py-0.5 rounded border border-emerald-800">GASTRIC FILTER: ONLINE</span>
              </div>
              <p className="text-xs text-slate-400">
                This is where value is absorbed and noise discarded. Text chunks are passed through the <strong>gemini-embedding-2-preview</strong> model, turning English statements into mathematical vectors (768 numbers) mapping raw semantic intelligence.
              </p>

              {/* Vector Space Map & Filtering Console */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                
                {/* 2D Coordinates Scatter Plot Canvas */}
                <div className="md:col-span-7 bg-slate-950 border border-slate-800 p-3 rounded-lg flex flex-col space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-emerald-400 flex items-center">
                      <Activity className="w-3.5 h-3.5 mr-1 text-emerald-400 animate-pulse" />
                      SEMANTIC COORDINATES MAP
                    </span>
                    <span className="text-slate-500 hover:text-slate-300 cursor-help" title="These represent high-dimensional vector similarities compressed to 2D coordinates. Hover over a node to read the text.">What is this?</span>
                  </div>

                  <canvas
                    ref={canvasRef}
                    width={400}
                    height={260}
                    onMouseMove={handleCanvasMouseMove}
                    onClick={handleCanvasClick}
                    className="w-full bg-slate-950 border border-slate-900 rounded cursor-crosshair"
                  />
                  
                  <div className="text-[9.5px] font-mono text-slate-500 text-center">
                    Click neon particles to inspect properties and dimensions in the sidebar.
                  </div>
                </div>

                {/* Vector Property Sidebar / Filtration Control */}
                <div className="md:col-span-5 flex flex-col space-y-3">
                  
                  {/* Gastric Filtration Metrics */}
                  <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg space-y-2.5">
                    <span className="text-[10px] text-slate-400 font-mono flex items-center">
                      <Filter className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                      GASTRIC FILTRATION SETTINGS
                    </span>
                    
                    <div>
                      <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                        <span>Purity Cutoff:</span>
                        <span className="text-emerald-400 font-bold">{purityThreshold.toFixed(2)}</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="0.8" 
                        step="0.05"
                        value={purityThreshold}
                        onChange={e => setPurityThreshold(Number(e.target.value))}
                        className="w-full accent-emerald-500 h-1 bg-slate-900 rounded"
                      />
                      <span className="text-[9px] text-slate-500 block leading-tight mt-0.5">Purges chunks falling below standard contextual density.</span>
                    </div>

                    <div className="flex items-center space-x-2 pt-1">
                      <input 
                        type="checkbox" 
                        id="hideJunkCheck"
                        checked={hideJunk}
                        onChange={e => setHideJunk(e.target.checked)}
                        className="accent-emerald-500 rounded text-black cursor-pointer"
                      />
                      <label htmlFor="hideJunkCheck" className="text-[11px] text-slate-300 font-mono cursor-pointer">
                        Instantly filter garbage data
                      </label>
                    </div>
                  </div>

                  {/* Inspector detail */}
                  <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-mono block mb-1">VECTOR INSPECTION PANEL:</span>
                      {selectedCanvasChunk ? (
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between">
                            <span className="text-[10px] text-slate-500 font-mono">INDEX:</span>
                            <span className="font-bold font-mono text-slate-300">Chunk {selectedCanvasChunk.index}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[10px] text-slate-500 font-mono">LENGTH:</span>
                            <span className="font-mono text-slate-300">{selectedCanvasChunk.length} Chars</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[10px] text-slate-500 font-mono">PURITY INDEX:</span>
                            <span className="font-mono text-emerald-400">{(selectedCanvasChunk.digestivePurity * 100).toFixed(0)}%</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] text-slate-500 font-mono">VECTOR MATRIX:</span>
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${selectedCanvasChunk.embedding ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' : 'bg-red-950 text-red-400 border border-red-900'}`}>
                              {selectedCanvasChunk.embedding ? '768 DIMENSIONS' : 'NOT EMBEDDED'}
                            </span>
                          </div>
                          <div className="pt-2">
                            <div className="text-[9px] text-slate-500 font-mono mb-0.5">TEXT BLOCK SNIPPET:</div>
                            <div className="bg-slate-900 p-2 rounded text-[10px] text-slate-300 font-mono h-24 overflow-y-auto border border-slate-850">
                              {selectedCanvasChunk.text}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-gray-500 italic text-[11px] text-center pt-8">
                          No particle selected. Click any particle on the coordinates map.
                        </div>
                      )}
                    </div>

                    {selectedCanvasChunk && !selectedCanvasChunk.embedding && (
                      <button
                        onClick={() => embedChunk(selectedCanvasChunk.id)}
                        className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-mono font-bold text-[11px] py-1 px-2 rounded mt-2 transition-all flex items-center justify-center space-x-1"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>EMBED CHUNK</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Chunk list with embedding triggers */}
              <div className="space-y-2 border-t border-slate-900 pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-300">STOMACH CHUNKS PENDING Semantics Embedding</span>
                  <button 
                    onClick={embedAllChunks}
                    className="bg-emerald-900/50 hover:bg-emerald-800 text-emerald-400 border border-emerald-700 font-mono text-xs px-3.5 py-1.5 rounded transition-all flex items-center space-x-1.5"
                  >
                    <Server className="w-3.5 h-3.5" />
                    <span>DIGEST ALL UN-EMBEDDED</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {chunks.length === 0 ? (
                    <div className="text-center text-slate-500 italic text-xs py-4">No chunks logged. Generate chunks in the Stomach stage first!</div>
                  ) : (
                    chunks
                      .filter(c => !hideJunk || !c.isJunk)
                      .map((c) => {
                        const isEmbedded = !!c.embedding;
                        return (
                          <div key={c.id} className={`flex items-center justify-between p-2.5 rounded-lg border font-mono text-xs transition-all ${isEmbedded ? 'bg-slate-950/40 border-slate-900' : 'bg-red-950/10 border-red-900/45 hover:border-red-500'}`}>
                            <div className="flex items-center space-x-2.5 truncate max-w-[70%]">
                              <span className={`w-1.5 h-1.5 rounded-full ${isEmbedded ? 'bg-emerald-500' : 'bg-red-500 animate-ping'}`}></span>
                              <span className="text-slate-400 font-bold">Chunk {c.index}</span>
                              <p className="text-slate-300 truncate font-mono text-[11px]">{c.text}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              {isEmbedded ? (
                                <span className="text-emerald-400 text-[10px] bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-900">
                                  Embedded [{(c.embedding![0] || 0).toFixed(4)}, ...]
                                </span>
                              ) : (
                                <button
                                  onClick={() => embedChunk(c.id)}
                                  className="bg-red-900 hover:bg-red-800 text-red-200 text-[10px] px-2 py-1 rounded transition-all flex items-center space-x-1"
                                >
                                  <Zap className="w-3 h-3 text-red-300 fill-red-300" />
                                  <span>Embed</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Phase 4 Tab: THE LIVER & BLOODSTREAM */}
          {activeTab === 'liver' && (
            <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-5 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-fuchsia-400 animate-pulse" />
                  <h2 className="text-md font-bold font-mono text-fuchsia-400">THE LIVER & BLOODSTREAM: Grounded Context Pump</h2>
                </div>
                <span className="bg-fuchsia-950 text-fuchsia-400 font-mono text-[9px] px-2 py-0.5 rounded border border-fuchsia-800">CIRCULATION: ARTERIAL</span>
              </div>
              <p className="text-xs text-slate-400">
                Once data is embedded, the <strong>Static Pin</strong> provides instant query capabilities. Typing an inquiry embeds the search terms, retrieves the most similar vector blocks via mathematical comparison, and pumps them directly to the Core Nine agents.
              </p>

              {/* In-character Grounding Search */}
              <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-12 gap-3 bg-slate-950/60 p-4 border border-slate-800 rounded-xl">
                <div className="md:col-span-8">
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">SEMANTIC INQUIRY SEARCH</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="e.g. Swell parameters at pee dub..." 
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-fuchsia-500"
                    />
                    <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">MATCH COUNT</label>
                  <select 
                    value={topK} 
                    onChange={e => setTopK(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-fuchsia-500"
                  >
                    <option value={1}>1 Chunk</option>
                    <option value={2}>2 Chunks</option>
                    <option value={3}>3 Chunks</option>
                    <option value={4}>4 Chunks</option>
                  </select>
                </div>

                <div className="md:col-span-2 flex flex-col justify-end">
                  <button
                    type="submit"
                    disabled={isSearching}
                    className="w-full bg-fuchsia-600 hover:bg-fuchsia-700 disabled:bg-slate-800 text-black font-mono font-bold text-xs py-2 px-3 rounded transition-all flex items-center justify-center space-x-1"
                  >
                    {isSearching ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                    <span>SEMANTIC SCAN</span>
                  </button>
                </div>
              </form>

              {/* Match Output */}
              <div className="space-y-2">
                <span className="text-[10px] text-slate-400 font-mono block">TOP RANKED SEMANTIC MATCHES RETRIEVED (STATIC PIN):</span>
                
                {searchResults.length === 0 ? (
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded text-center text-slate-500 italic text-xs">
                    No matching coordinates queried yet. Click "SEMANTIC SCAN" to find chunks.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {searchResults.map((r, idx) => (
                      <div key={r.chunkId} className="bg-slate-950 border border-slate-850 p-3 rounded-lg flex flex-col justify-between space-y-2">
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[9px] text-fuchsia-400 bg-fuchsia-950/40 border border-fuchsia-900/60 px-1.5 py-0.5 rounded font-mono font-bold">
                              MATCH #{idx + 1}
                            </span>
                            <span className="text-[10px] font-mono text-emerald-400 font-bold">
                              {(r.similarity * 100).toFixed(1)}% Match
                            </span>
                          </div>
                          <p className="text-[10px] font-mono text-slate-300 leading-normal max-h-24 overflow-y-auto bg-slate-900/60 p-2 rounded">
                            {r.text}
                          </p>
                        </div>
                        <div className="text-[8.5px] font-mono text-slate-500 border-t border-slate-900 pt-1.5 truncate">
                          File: {r.documentName}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Core Nine prompt pump */}
              <div className="border-t border-slate-900 pt-4 grid grid-cols-1 md:grid-cols-12 gap-4">
                
                {/* Agent Selector & Prompt display */}
                <div className="md:col-span-5 flex flex-col space-y-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono mb-1">SELECT TARGET CORE NINE AGENT</label>
                    <select
                      value={selectedAgent}
                      onChange={e => setSelectedAgent(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-fuchsia-500"
                    >
                      <option value="The Sentinel">The Sentinel (Security Rig Guardian)</option>
                      <option value="The Chronicler">The Chronicler (Biological Clockkeeper)</option>
                      <option value="The Alchemist">The Alchemist (Chunking Specialist)</option>
                      <option value="The Tide-Breaker">The Tide-Breaker (Tasman Sea Sensor)</option>
                    </select>
                  </div>

                  <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg flex-1 flex flex-col justify-between space-y-2">
                    <div>
                      <div className="flex justify-between items-center text-[10px] font-mono mb-1">
                        <span className="text-slate-400">PUMPING PAYLOAD WINDOW</span>
                        <span className="text-[8px] bg-amber-950 text-amber-400 border border-amber-900 px-1 rounded">GROUNDED</span>
                      </div>
                      <div className="bg-slate-900 p-2.5 rounded text-[10px] text-slate-400 font-mono h-32 overflow-y-auto leading-normal whitespace-pre-wrap select-text border border-slate-850">
                        {sentPayload || "Queueing vector nutrients..."}
                      </div>
                    </div>

                    <button
                      onClick={triggerCirculation}
                      disabled={isCirculating || !searchQuery}
                      className="w-full bg-fuchsia-500 hover:bg-fuchsia-600 disabled:bg-slate-800 text-black font-mono font-bold text-xs py-2 px-3 rounded transition-all flex items-center justify-center space-x-2"
                    >
                      <Zap className="w-3.5 h-3.5 fill-black" />
                      <span>PUMP BLOOD & GENERATE RESPONSE</span>
                    </button>
                  </div>
                </div>

                {/* Simulated Output Panel */}
                <div className="md:col-span-7 bg-slate-950 p-4 border border-slate-800 rounded-lg flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center pb-2 border-b border-slate-900 mb-2">
                      <span className="text-xs font-bold font-mono text-fuchsia-400 flex items-center">
                        <Terminal className="w-3.5 h-3.5 mr-1.5" />
                        CORE NINE TELEMETRY: {selectedAgent.toUpperCase()}
                      </span>
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    </div>

                    <div className="text-slate-300 font-mono text-[11px] leading-relaxed overflow-y-auto h-52 pr-1 select-text whitespace-pre-wrap">
                      {isCirculating ? (
                        <div className="flex flex-col items-center justify-center h-full space-y-2">
                          <RefreshCw className="w-8 h-8 text-fuchsia-500 animate-spin" />
                          <p className="text-slate-500 text-xs animate-pulse font-mono">[CIRCULATING NUTRIENTS TO THE AGENT BRAINCELLS...]</p>
                        </div>
                      ) : agentOutput ? (
                        agentOutput
                      ) : (
                        <div className="text-slate-600 italic h-full flex items-center justify-center text-center px-4 py-8">
                          No blood payload fired yet. Choose an agent, run a search query, and click "PUMP BLOOD" to prompt.
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="border-t border-slate-900 pt-2 text-[9px] text-slate-500 font-mono flex justify-between">
                    <span>Injected model: gemini-3.8-flash</span>
                    <span>System memory: Grounded</span>
                  </div>
                </div>

              </div>
            </div>
          )}
          
        </div>

        {/* Right Column: Active Ingested Files & Clock Logs */}
        <div className="lg:col-span-4 flex flex-col space-y-5">
          
          {/* Active Ingested Documents List */}
          <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-4 space-y-3">
            <h3 className="text-xs font-bold font-mono text-cyan-400 flex items-center justify-between">
              <span className="flex items-center">
                <FileText className="w-4 h-4 mr-1.5 text-cyan-400" />
                INGESTED RAW REPOSITORIES
              </span>
              <span className="text-[10px] text-slate-500">({documents.length} sources)</span>
            </h3>

            <div className="space-y-2 max-h-[180px] overflow-y-auto">
              {documents.length === 0 ? (
                <div className="text-center text-slate-500 italic text-xs py-4">No sources ingested yet. Feed the mouth!</div>
              ) : (
                documents.map((d) => (
                  <div 
                    key={d.id} 
                    onClick={() => {
                      setSelectedDocId(d.id);
                      setActiveTab('stomach');
                    }}
                    className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between ${selectedDocId === d.id ? 'bg-cyan-950/20 border-cyan-800' : 'bg-slate-950 border-slate-900 hover:border-slate-800'}`}
                  >
                    <div className="truncate pr-2">
                      <div className="font-bold font-mono text-slate-200 truncate">{d.name}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        Type: <span className="text-cyan-500">{d.type}</span> | {d.content.length} chars
                      </div>
                    </div>
                    <ChevronRightIcon className={`w-3.5 h-3.5 transition-transform ${selectedDocId === d.id ? 'text-cyan-400 translate-x-0.5' : 'text-slate-600'}`} />
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Biological Pipeline Logs */}
          <div className="bg-slate-900/60 border border-slate-900 rounded-xl p-4 space-y-3 flex-1 flex flex-col min-h-[300px]">
            <h3 className="text-xs font-bold font-mono text-fuchsia-400 flex items-center justify-between">
              <span className="flex items-center">
                <Activity className="w-4 h-4 mr-1.5 text-fuchsia-400 animate-pulse" />
                BIOLOGICAL PIPELINE LOGS
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </h3>

            <div className="flex-1 bg-slate-950 border border-slate-900 rounded-lg p-3 font-mono text-[10px] leading-relaxed overflow-y-auto flex flex-col space-y-2 max-h-[350px]">
              {logs.length === 0 ? (
                <div className="text-slate-600 italic py-4 text-center">Waiting for digestive enzyme logs...</div>
              ) : (
                [...logs].reverse().map((log) => (
                  <div key={log.id} className="border-b border-slate-900 pb-1.5 last:border-none">
                    <div className="flex justify-between items-center mb-0.5 text-[9px]">
                      <span className={`px-1.5 py-0.2 border rounded-sm font-bold tracking-widest ${getPhaseColor(log.phase)}`}>
                        {log.phase.toUpperCase()}
                      </span>
                      <span className="text-slate-600">{new Date(log.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className={`text-[10px] leading-normal ${
                      log.status === 'error' ? 'text-red-400' :
                      log.status === 'warn' ? 'text-amber-400' :
                      log.status === 'success' ? 'text-emerald-400' : 'text-slate-300'
                    }`}>
                      {log.message}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </main>

      {/* Cyber Dragon Bios footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-3 px-4 flex flex-col md:flex-row items-center justify-between text-[10px] text-slate-500 font-mono">
        <div className="flex items-center space-x-1.5">
          <HardDrive className="w-3 h-3 text-cyan-500" />
          <span>CYBER DRAGON DIGESTIVE ENGINE (STABLE RUNTIME ON ANTIX)</span>
        </div>
        <div className="mt-1 md:mt-0">
          <span>COORDINATES: PEE DUB, NEW ZEALAND / OKTOBER 2026</span>
        </div>
      </footer>
    </div>
  );
}

// Custom mini Chevron icon
function ChevronRightIcon({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      fill="none" 
      viewBox="0 0 24 24" 
      stroke="currentColor" 
      strokeWidth={2.5}
    >
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
  );
}
