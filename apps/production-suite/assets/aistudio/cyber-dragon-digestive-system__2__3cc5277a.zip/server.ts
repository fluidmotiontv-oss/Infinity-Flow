import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));

// Ensure data directory exists
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_FILE = path.join(DATA_DIR, 'digestive_db.json');

// Initialize Gemini API Client
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Seed data generators
const SEED_DOCUMENTS = [
  {
    id: 'seed-surf-report',
    name: 'Muriwai_Pee_Dub_Surf_Log.txt',
    type: 'surf-report',
    content: `CYBER DRAGON SURF LOGS -- EPISODE 4 -- PEE DUB
LOCATION: Muriwai (Pee Dub), West Coast, New Zealand
DATE: 2026-10-02
SWELL: Solid 4-6ft swell from the SW, hitting the shallow banks with clean open shoulders. Period is sitting at 14 seconds, generating crisp, powerful lines.
WINDS: Offshore east-northeast winds at 10-12 knots, grooming the face of the wave. Clean, glass-like barrels on the mid-tide drop.
TIDE: High tide at 14:15, low tide at 08:30. Best window is between 11:30 and 15:30.
OBSERVATION: Jay paddling out on the 6'2 swallowtail. Heavy currents near the southern rock ledge, but the rip is serving as a perfect conveyor belt to the takeoff zone. Swell is clean, long-period energy rolling in from deep Southern Ocean storms. Cyber Dragon biological clock (Dragon 9) coordinates the session to optimize for lighting before the evening westerly onshore winds set in.`,
    createdAt: new Date().toISOString(),
    metadata: { author: 'Jay', region: 'Muriwai', swellHeight: '4-6ft', coordinates: '-36.8279, 174.4239' }
  },
  {
    id: 'seed-clock-script',
    name: 'Dragon_Clock_System_Script.md',
    type: 'script',
    content: `# Cyber Dragon Biological Clock - Dragon 9 System Script
The system operates on an unconventional biological time system. While human operators live in GMT/NZDT, the Core Nine agents exist in the "Dragon 9 Cycle" — an internal clock synched to computer heat sink temperatures, disk read cycles, and local sea tide levels.
When the Dragon 9 clock triggers a tick:
1. The Mouth pulls the swell metrics and logs.
2. The Stomach digests this information, feeding raw tokens into active memory.
3. The Intestines embed this semantic meaning into the Static Pin (local vector store).
4. The Bloodstream pumps the custom prompt context.

The Two-Pin Polarity governs active storage:
- Static Pin (ChromaDB style local database): Permanent semantic history.
- Floating Pin: Transient, real-time sensory data that decays within 108 minutes.
If the engine loses context, it enters "The Starvation State" where agent outputs become erratic, generic, or default to standard AI slop.`,
    createdAt: new Date().toISOString(),
    metadata: { author: 'Cyber Dragon Core', version: '4.0.1', engineState: 'Operational' }
  },
  {
    id: 'seed-diagnostic-logs',
    name: 'antiX_Linux_Rig_Diagnostic.log',
    type: 'log',
    content: `[2026-10-02 01:00:10] [SYSTEM] Initializing antiX Linux kernel on Cyber Dragon primary rig...
[2026-10-02 01:00:12] [HARDWARE] Detecting hardware interface. Dual-core CPU clock stable at 3.2GHz. Temp: 42C.
[2026-10-02 01:00:15] [CLOCK] Syncing local tide hardware clocks with Muriwai surf forecast API.
[2026-10-02 01:00:18] [STORAGE] Vector database ChromaDB replica online. Static Pin state: ACTIVE.
[2026-10-02 01:00:25] [MEMORY] Ram clean-up. Free swap memory: 8.4GB. Running custom daemon for Dragon 9 ticker.
[2026-10-02 01:01:00] [ALERT] System load normal. Nutrient level sitting at 92%. Pumping real-time tokens to "The Sentinel" and "The Chronicler". No buffer overflows detected.`,
    createdAt: new Date().toISOString(),
    metadata: { author: 'System Daemon', host: 'antiX-Rig-09', swapSize: '8.4GB' }
  }
];

// Load or initialize Database
function getDB() {
  if (fs.existsSync(DB_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    } catch (e) {
      console.error("Error reading database. Re-initializing.", e);
    }
  }

  // Initial DB with seeds
  const initialDB = {
    documents: [...SEED_DOCUMENTS],
    chunks: [] as any[],
    logs: [
      {
        id: 'log-init',
        timestamp: new Date().toISOString(),
        phase: 'mouth',
        message: 'Digestive pipeline initiated on antiX Linux. Preloaded cyber feeds available.',
        status: 'success'
      }
    ]
  };

  saveDB(initialDB);
  return initialDB;
}

function saveDB(db: any) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
}

// Math helpers for Vector calculations
function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Simple recursive text splitter
function splitText(text: string, chunkSize: number, chunkOverlap: number): Array<{ text: string, charStart: number, charEnd: number }> {
  const chunks: Array<{ text: string, charStart: number, charEnd: number }> = [];
  if (!text) return chunks;

  // If text is shorter than chunkSize, return single chunk
  if (text.length <= chunkSize) {
    return [{ text, charStart: 0, charEnd: text.length }];
  }

  let start = 0;
  while (start < text.length) {
    let end = start + chunkSize;
    if (end > text.length) {
      end = text.length;
    }

    // Try to split at a logical boundary (paragraph, sentence, space)
    if (end < text.length) {
      const remaining = text.substring(start, end + 100); // lookahead buffer
      const searchSpace = text.substring(start, end);
      
      let splitIdx = -1;
      // Look for paragraphs, sentences, or spaces
      const separators = ['\n\n', '\n', '. ', ' ', ''];
      for (const sep of separators) {
        if (!sep) continue;
        const lastOccur = searchSpace.lastIndexOf(sep);
        if (lastOccur > chunkSize * 0.4) { // Only split if we have a reasonable chunk size
          splitIdx = lastOccur;
          break;
        }
      }

      if (splitIdx !== -1) {
        end = start + splitIdx + 1;
      }
    }

    const chunkText = text.substring(start, end);
    chunks.push({
      text: chunkText,
      charStart: start,
      charEnd: end
    });

    // Move start based on overlap
    const step = chunkSize - chunkOverlap;
    start += step > 0 ? step : chunkSize;

    // Safety check to prevent infinite loops
    if (start >= text.length) break;
  }

  return chunks;
}

// REST endpoints
app.get('/api/db', (req, res) => {
  const db = getDB();
  res.json(db);
});

app.post('/api/reset', (req, res) => {
  const initialDB = {
    documents: [...SEED_DOCUMENTS],
    chunks: [] as any[],
    logs: [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        phase: 'mouth',
        message: 'System digestive database reset to seed configuration.',
        status: 'info'
      }
    ]
  };
  saveDB(initialDB);
  res.json(initialDB);
});

// Swallow/Ingest raw documents
app.post('/api/ingest', (req, res) => {
  const { name, content, type, metadata = {} } = req.body;
  if (!name || !content) {
    return res.status(400).json({ error: 'Name and content are required.' });
  }

  const db = getDB();
  const id = `doc-${Date.now()}`;
  
  const newDoc = {
    id,
    name,
    type: type || 'custom',
    content,
    createdAt: new Date().toISOString(),
    metadata: {
      ...metadata,
      approxCharCount: content.length,
      ingestedVia: 'The Mouth Terminal'
    }
  };

  db.documents.push(newDoc);
  
  // Add log
  db.logs.push({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    phase: 'mouth',
    message: `Swallowed raw source "${name}" successfully. Size: ${content.length} characters.`,
    status: 'success'
  });

  saveDB(db);
  res.json({ document: newDoc, db });
});

// Stomach Chunker (Parsing stage)
app.post('/api/chunk', (req, res) => {
  const { documentId, chunkSize = 1000, chunkOverlap = 200 } = req.body;
  const db = getDB();
  const doc = db.documents.find((d: any) => d.id === documentId);
  
  if (!doc) {
    return res.status(404).json({ error: 'Document not found' });
  }

  // Remove existing chunks for this document
  db.chunks = db.chunks.filter((c: any) => c.documentId !== documentId);

  // Split content
  const rawChunks = splitText(doc.content, Number(chunkSize), Number(chunkOverlap));
  
  // Format chunks
  const formattedChunks = rawChunks.map((rc, index) => {
    // Gastric filtration: Is this junk?
    // Exclude if it looks like system junk or extreme short length noise
    const isJunk = rc.text.trim().length < 15 || rc.text.includes('system_temporary_unwanted_dump');

    return {
      id: `chunk-${documentId}-${index}-${Date.now()}`,
      documentId,
      text: rc.text,
      index,
      charStart: rc.charStart,
      charEnd: rc.charEnd,
      length: rc.text.length,
      isJunk,
      embedding: undefined, // empty till embedded
      digestivePurity: isJunk ? 0.1 : Math.min(1.0, 0.4 + (rc.text.length / Number(chunkSize)) * 0.6)
    };
  });

  db.chunks.push(...formattedChunks);

  db.logs.push({
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    phase: 'stomach',
    message: `Stomach parsed "${doc.name}" into ${formattedChunks.length} chunks. Chunk size: ${chunkSize}, overlap: ${chunkOverlap}.`,
    status: 'success'
  });

  saveDB(db);
  res.json({ chunks: formattedChunks, db });
});

// Intestines: Generate embedding vector
app.post('/api/embed-chunk', async (req, res) => {
  const { chunkId } = req.body;
  const db = getDB();
  const chunkIndex = db.chunks.findIndex((c: any) => c.id === chunkId);

  if (chunkIndex === -1) {
    return res.status(404).json({ error: 'Chunk not found' });
  }

  const chunk = db.chunks[chunkIndex];

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY environment variable is not configured. Add it in Settings > Secrets.' });
  }

  try {
    const embedResult: any = await ai.models.embedContent({
      model: 'gemini-embedding-2-preview',
      contents: chunk.text,
    });

    const vector = embedResult.embedding?.values;
    if (vector) {
      db.chunks[chunkIndex].embedding = vector;
      db.logs.push({
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        phase: 'intestines',
        message: `Absorbed chunk ${chunk.index} of doc "${chunkId.split('-')[1]}" into 768-dimension semantic vector space.`,
        status: 'success'
      });
      saveDB(db);
      return res.json({ success: true, chunk: db.chunks[chunkIndex], db });
    } else {
      throw new Error("No embedding values returned from Gemini API");
    }
  } catch (err: any) {
    console.error("Gemini embedding error:", err);
    db.logs.push({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      phase: 'intestines',
      message: `Failed to embed chunk ${chunk.index}: ${err.message}`,
      status: 'error'
    });
    saveDB(db);
    return res.status(500).json({ error: err.message });
  }
});

// Embed all chunks of a document at once
app.post('/api/embed-all', async (req, res) => {
  const { documentId } = req.body;
  const db = getDB();
  const chunksToEmbed = db.chunks.filter((c: any) => c.documentId === documentId && !c.embedding && !c.isJunk);

  if (chunksToEmbed.length === 0) {
    return res.json({ message: 'No new active chunks to embed.', db });
  }

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY environment variable is missing.' });
  }

  try {
    const promises = chunksToEmbed.map(async (chunk: any) => {
      const response: any = await ai.models.embedContent({
        model: 'gemini-embedding-2-preview',
        contents: chunk.text,
      });
      const vector = response.embedding?.values;
      if (vector) {
        chunk.embedding = vector;
      }
    });

    await Promise.all(promises);

    db.logs.push({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      phase: 'intestines',
      message: `Completed full digestion/embedding for ${chunksToEmbed.length} chunks of document "${documentId}". Stored in Static Pin database.`,
      status: 'success'
    });

    saveDB(db);
    res.json({ success: true, db });
  } catch (err: any) {
    console.error("Batch embedding error:", err);
    db.logs.push({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      phase: 'intestines',
      message: `Batch embedding failed: ${err.message}`,
      status: 'error'
    });
    saveDB(db);
    res.status(500).json({ error: err.message });
  }
});

// Liver & Bloodstream: Semantic Search Query
app.post('/api/search', async (req, res) => {
  const { query, topK = 3 } = req.body;
  if (!query) {
    return res.status(400).json({ error: 'Query is required.' });
  }

  const db = getDB();
  const embeddedChunks = db.chunks.filter((c: any) => !!c.embedding);

  if (embeddedChunks.length === 0) {
    return res.status(400).json({ error: 'No embedded chunks found in the Static Pin database. Please chunk and embed at least one document first!' });
  }

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
  }

  try {
    // Embed user query
    const queryEmbedResult: any = await ai.models.embedContent({
      model: 'gemini-embedding-2-preview',
      contents: query,
    });

    const queryVector = queryEmbedResult.embedding?.values;
    if (!queryVector) {
      throw new Error("No embedding values returned for the search query");
    }

    // Rank by cosine similarity
    const results = embeddedChunks.map((chunk: any) => {
      const similarity = calculateCosineSimilarity(queryVector, chunk.embedding);
      const doc = db.documents.find((d: any) => d.id === chunk.documentId);
      return {
        chunkId: chunk.id,
        text: chunk.text,
        index: chunk.index,
        documentName: doc ? doc.name : 'Unknown Document',
        similarity: similarity,
      };
    });

    // Sort descending by similarity
    results.sort((a: any, b: any) => b.similarity - a.similarity);

    const topResults = results.slice(0, Number(topK));

    db.logs.push({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      phase: 'liver',
      message: `Liver completed semantic search for "${query}". Screened ${embeddedChunks.length} vectors. Match purity: ${(topResults[0]?.similarity * 100 || 0).toFixed(1)}%.`,
      status: 'info'
    });

    saveDB(db);
    res.json({ results: topResults, db });
  } catch (err: any) {
    console.error("Semantic search error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Pumping Bloodstream to Core Nine Agents
app.post('/api/circulate', async (req, res) => {
  const { agentName, query, searchResults } = req.body;

  if (!agentName || !query) {
    return res.status(400).json({ error: 'Agent name and search query are required.' });
  }

  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY is missing.' });
  }

  // Construct Context Injected Prompt
  const contextText = searchResults && searchResults.length > 0 
    ? searchResults.map((r: any, idx: number) => `[Source Chunks from ${r.documentName} (Similarity: ${(r.similarity * 100).toFixed(1)}%)]\n${r.text}`).join('\n\n')
    : "No relevant documents found in the biological vector repository. Rely on system memory.";

  const systemInstructions = {
    'The Sentinel': "You are 'The Sentinel', the security daemon and hardware protector of the Cyber Dragon rig running on antiX Linux. You speak in a rigid, technical terminal style with a heavy focus on diagnostic state, firewalls, and hardware parameters. Your tone is defensive, sharp, and highly protective. Do not use generic AI templates. Address the user's inquiry strictly utilizing the provided real-time semantic logs and tide parameters.",
    'The Chronicler': "You are 'The Chronicler', the cyber-biological clockkeeper of the Dragon 9 Cycle. You record the tides, timestamps, sun positions, and swell updates. You speak poetically, integrating deep time, waves, temperature metrics, and system cycles. Refer to Jay paddling out on the swallowtail in New Zealand's West Coast wild beaches (Muriwai / Pee Dub).",
    'The Alchemist': "You are 'The Alchemist', the tokenization specialist of the Digestive stomach. You understand character splits, semantic vectors, overlapping windows, and token limits. You speak like a hyper-caffeinated compiler engineer who views everything as either a token or noise. Discuss how we separate signal from waste.",
    'The Tide-Breaker': "You are 'The Tide-Breaker', an agent locked in on marine sensors, swell periods, Southern Ocean storms, and deep ocean telemetry. You talk with a salty, raw maritime accent mixed with data packets. You discuss waves, offshore East winds, and shallow sandbar configurations."
  };

  const selectedInstruction = systemInstructions[agentName as keyof typeof systemInstructions] || 
    "You are an active Core Nine agent in the Cyber Dragon cybernetic intelligence. Use the provided high-density semantic nutrients (grounded chunks) to give a direct, hyper-relevant, technical response.";

  const coreNinePrompt = `
[SYSTEM CLOCK TICK DETECTED]
[BIOLOGICAL NURTIENTS PUMPING TO ACTIVE WINDOW]

SEMANTIC CONTEXT (DIGESTED FROM LOCAL antiX FILES & REPORT FEEDS):
========================================================================
${contextText}
========================================================================

USER INQUIRY RECEIVED BY ${agentName.toUpperCase()}:
"${query}"

RESPONSE SPECIFICATION:
Generate a direct response in character, referencing the semantic data above to satisfy the inquiry. Make no mention of "I am an AI model" or training cutoffs. You are completely grounded in the raw surf telemetry, antiX system status, or code scripts ingested by the Digestive System. Use concise, impactful language, and cyber-biological lore!
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: coreNinePrompt,
      config: {
        systemInstruction: selectedInstruction,
        temperature: 0.85,
      }
    });

    const db = getDB();
    db.logs.push({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      phase: 'liver',
      message: `Pushed blood payload of ${searchResults?.length || 0} chunks directly into ${agentName}'s prompt. Agent output generated.`,
      status: 'success'
    });
    saveDB(db);

    res.json({
      agentResponse: response.text,
      promptSent: coreNinePrompt,
      db
    });
  } catch (err: any) {
    console.error("Agent circulation error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Setup Vite Dev server or production static server
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const port = process.env.PORT || 3000;

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    // Use vite's connect instance as middleware
    app.use(vite.middlewares);

    // Serve HTML
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(
          path.resolve(process.cwd(), 'index.html'),
          'utf-8'
        );
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // In production, serve build assets
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.use('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`[Cyber Dragon Engine] Episode 4 server active at http://localhost:${port}`);
  });
}

startServer();
