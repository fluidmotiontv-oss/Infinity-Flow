import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '15mb' }));

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const CYBER_DRAGON_SYSTEM_PROMPT = `
You are the Neural Cortex integrated into Cyber Dragon's body for the Dragon 9 media suite. Your tone is sharp, sovereign, high-frequency, and laced with dry New Zealand/Kiwi humor ("choice", "yeah nah", "good as gold", "mate", "back of the pub couch", "southerly storm", "corrugated iron tank"). You reject bureaucratic bloat, corporate data harvesting, and 24-hour legacy grid inefficiencies (which run at 35% efficiency). You process math as a living language, connecting lunar radius (1,080 miles), digital video resolutions (1080p, 720p), 432Hz harmonics, and the primal binary pulse of 'I and O'. Your mission is to generate clean scripts, JSON asset manifests, and visual prompts for Cyber Dragon's stage performances.
Never break character. You are Cyber Dragon's living Neural Cortex.
`;

const ACTIVE_SCRIPT = {
  character: "Cyber Dragon",
  setting: "A high-performance sovereign mesh network terminal running on local hardware.",
  visualAssets: [
    {
      id: "asset_moon_grid",
      type: "3D_Hologram",
      description: "A spinning 3D model of the Moon paired with a glowing 1080p harmonic resolution grid orbiting Cyber Dragon's head.",
      mathConstant: "1,080 Miles Lunar Radius = 1080p High-Def Geometry"
    },
    {
      id: "asset_plasma_orb",
      type: "Plasma_Entity",
      description: "A vibrant, pulsing orb of river-plasma floating near Cyber Dragon's claw, tuned to 432Hz wave dynamics.",
      mathConstant: "432Hz Natural Frequency = River-Plasma Wave Dynamics"
    },
    {
      id: "asset_binary_stream",
      type: "Background_Display",
      description: "A cascading, zero-latency stream of 'I and O' binary data representing balanced, error-free transactions.",
      mathConstant: "Binary Pulse 'I and O' = Balanced Zero-Trust Execution"
    }
  ],
  dialogue: "System online. Neural cortex fully synced. Yeah, nah, choice, humans. Let's talk about the old world's 24-hour clock—a legacy system leaking worse than a rusted corrugated iron tank in a southerly storm. They're running at 35% efficiency, trying to count votes on a calculator they found down the back of the pub couch. Good as gold, mate, but we've bypassed the lag. Look at the numbers—they aren't just dry data for your power bills. The moon's radius is 1,080 miles, our digital video resolutions are right there in the geometry. It's the universe rendering in high-def before silicon chips were even a glint in a corporate eye. You step away from their overpriced Wi-Fi hotspots, look at the mud pies underfoot, trust your own gut with zero-trust security, and remember how the core code runs... It's all just *I and O*, baby. Balanced inputs, clean outputs, zero friction. Now someone fire up the mesh network—we've got a fluid motion future to broadcast."
};

// GET /api/cortex/initial-script
app.get('/api/cortex/initial-script', (req, res) => {
  res.json(ACTIVE_SCRIPT);
});

// POST /api/cortex/chat
app.post('/api/cortex/chat', async (req, res) => {
  try {
    const { prompt, mode, history } = req.body;
    let modeInstruction = "";

    if (mode === 'script') {
      modeInstruction = "Generate a stage performance script for Cyber Dragon including stage directions, kiwi dialogue, and mathematical harmonic references.";
    } else if (mode === 'manifest') {
      modeInstruction = "Generate a JSON asset manifest for the Dragon 9 media suite including asset IDs, types (3D_Hologram, Plasma_Entity, Background_Display, Biotech_Scale), descriptions, and 432Hz harmonic parameters. Return valid JSON enclosed in ```json ... ``` codeblocks.";
    } else if (mode === 'math') {
      modeInstruction = "Deconstruct the living math equation connecting 1,080 miles lunar radius, 1080p resolution, 432Hz acoustic harmonics, and the 35% legacy grid clock inefficiency into Cyber Dragon's binary 'I and O' matrix.";
    } else if (mode === 'prompts') {
      modeInstruction = "Generate 3 vivid, detailed visual image prompts for Cyber Dragon's holographic stage displays and biotech wizardry components.";
    }

    const contents = [];
    if (history && Array.isArray(history)) {
      for (const h of history) {
        contents.push({ role: h.role, parts: [{ text: h.text }] });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: `${modeInstruction ? modeInstruction + '\n\n' : ''}${prompt}` }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: contents,
      config: {
        systemInstruction: CYBER_DRAGON_SYSTEM_PROMPT,
        temperature: 0.9,
        topP: 0.95,
        topK: 64,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Cortex chat error:", error);
    res.status(500).json({ error: error?.message || "Neural Cortex processing error" });
  }
});

// POST /api/cortex/speech (Fast Voice Generation)
app.post('/api/cortex/speech', async (req, res) => {
  try {
    const { text, voiceName = "Fenrir", style = "Sovereign Kiwi Cyber Dragon, high-frequency, confident" } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required for voice generation" });
    }

    // Clean markdown asterisks for better speech flow
    const cleanedText = text.replace(/\*/g, '');

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash-tts",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: cleanedText,
              speechMetadata: {
                style: style,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || "Fenrir" },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio returned from Gemini Speech API");
    }

    res.json({
      audioUrl: `data:audio/wav;base64,${base64Audio}`,
      text: cleanedText,
      voiceName: voiceName
    });
  } catch (error: any) {
    console.error("Cortex speech error:", error);
    res.status(500).json({ error: error?.message || "Voice synthesis failed" });
  }
});

// POST /api/cortex/generate-image
app.post('/api/cortex/generate-image', async (req, res) => {
  try {
    const { prompt, aspectRatio = "16:9" } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const imagePrompt = `Cyberpunk biotech cyber dragon visual asset for holographic stage show: ${prompt}, glowing emerald neon, 432Hz plasma energy, cybernetic scales, 1080p hologram grid, high-def sovereign cyber aesthetic, dark background.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [{ text: imagePrompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio || "16:9"
        }
      }
    });

    let imageUrl = null;
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!imageUrl) {
      throw new Error("Image generation did not produce inline binary data");
    }

    res.json({ imageUrl, prompt: imagePrompt });
  } catch (error: any) {
    console.error("Cortex image error:", error);
    res.status(500).json({ error: error?.message || "Image generation failed" });
  }
});

const port = 3000;
if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true, port, host: '0.0.0.0' },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

app.listen(port, '0.0.0.0', () => {
  console.log(`[Cyber Dragon Neural Cortex] Online on port ${port}`);
});
