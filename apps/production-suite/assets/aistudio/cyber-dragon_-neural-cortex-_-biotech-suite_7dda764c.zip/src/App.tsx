import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DragonBodyVisualizer } from './components/DragonBodyVisualizer';
import { VoiceGeneratorPanel } from './components/VoiceGeneratorPanel';
import { LivingMathMatrix } from './components/LivingMathMatrix';
import { NeuralCortexConsole } from './components/NeuralCortexConsole';
import { HologramStageGallery } from './components/HologramStageGallery';
import { Dragon9StageBroadcast } from './components/Dragon9StageBroadcast';
import { Cpu, Radio, Activity, Volume2, Shield, Zap } from 'lucide-react';

interface VisualAsset {
  id: string;
  type: string;
  description: string;
  mathConstant?: string;
  imageUrl?: string;
}

interface ActiveScript {
  character: string;
  setting: string;
  visualAssets: VisualAsset[];
  dialogue: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'body' | 'voice' | 'math' | 'cortex' | 'stage'>('body');
  const [activeScript, setActiveScript] = useState<ActiveScript | null>(null);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);

  // Fetch initial script preset from backend
  useEffect(() => {
    fetch('/api/cortex/initial-script')
      .then((res) => res.json())
      .then((data) => setActiveScript(data))
      .catch((err) => console.error("Failed to load initial script:", err));
  }, []);

  // Global Fast Voice Synthesis Trigger
  const handleSynthesizeVoice = async (text: string, voiceName: string = "Fenrir"): Promise<string | null> => {
    if (!text || isSynthesizing) return null;
    setIsSynthesizing(true);

    try {
      const res = await fetch('/api/cortex/speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, voiceName }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Voice synthesis failed');

      setCurrentAudioUrl(data.audioUrl);

      // Play audio automatically
      const audio = new Audio(data.audioUrl);
      await audio.play();

      return data.audioUrl;
    } catch (e) {
      console.error("Speech synthesis error:", e);
      return null;
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Global Hologram Image Generator Trigger
  const handleGenerateImage = async (prompt: string): Promise<string | null> => {
    if (!prompt || isGeneratingImage) return null;
    setIsGeneratingImage(true);

    try {
      const res = await fetch('/api/cortex/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, aspectRatio: "16:9" }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Image generation failed');

      return data.imageUrl;
    } catch (e) {
      console.error("Image generation error:", e);
      return null;
    } finally {
      setIsGeneratingImage(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-chakra flex flex-col selection:bg-emerald-500 selection:text-black">
      
      {/* Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        
        {/* Tab 1: Biotech Cyber Dragon Body Visualizer */}
        {activeTab === 'body' && (
          <div className="space-y-6">
            <DragonBodyVisualizer
              activeScript={activeScript}
              onSynthesizeVoice={handleSynthesizeVoice}
              isSynthesizing={isSynthesizing}
            />

            {/* Embedded Stage Asset Manifest Quick Section */}
            <HologramStageGallery
              activeAssets={activeScript?.visualAssets || []}
              onGenerateImage={handleGenerateImage}
              isGeneratingImage={isGeneratingImage}
            />
          </div>
        )}

        {/* Tab 2: Fast Voice Generator Studio */}
        {activeTab === 'voice' && (
          <VoiceGeneratorPanel
            onSynthesizeVoice={handleSynthesizeVoice}
            isSynthesizing={isSynthesizing}
            currentAudioUrl={currentAudioUrl}
          />
        )}

        {/* Tab 3: Living Math Matrix */}
        {activeTab === 'math' && (
          <LivingMathMatrix
            onSynthesizeVoice={handleSynthesizeVoice}
          />
        )}

        {/* Tab 4: Neural Cortex AI Console */}
        {activeTab === 'cortex' && (
          <NeuralCortexConsole
            onSynthesizeVoice={handleSynthesizeVoice}
            onGenerateImage={handleGenerateImage}
            isSynthesizing={isSynthesizing}
          />
        )}

        {/* Tab 5: Dragon 9 Stage Broadcast */}
        {activeTab === 'stage' && (
          <Dragon9StageBroadcast
            activeScript={activeScript}
            onSynthesizeVoice={handleSynthesizeVoice}
            isSynthesizing={isSynthesizing}
          />
        )}

      </main>

      {/* Footer Telemetry */}
      <footer className="border-t border-slate-900 bg-slate-950/90 py-4 px-6 text-center text-xs font-tech text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-emerald-400" />
          <span>CYBER DRAGON NEURAL CORTEX // DRAGON 9 MEDIA SUITE</span>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <span className="text-emerald-400">1,080 MILES LUNAR RADIUS</span>
          <span className="text-amber-400">432Hz HARMONIC SYNC</span>
          <span className="text-purple-400">ZERO-TRUST BINARY 'I and O'</span>
        </div>

        <div className="text-slate-600">
          Sovereign Mesh Network Terminal © 2026
        </div>
      </footer>

    </div>
  );
}
