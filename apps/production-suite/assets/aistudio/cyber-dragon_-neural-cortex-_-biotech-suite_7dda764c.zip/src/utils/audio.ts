// Web Audio API helper for 432Hz Solfeggio Harmonic Synthesizer and Analyser

class AudioEngine {
  private ctx: AudioContext | null = null;
  private oscillator: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private is432HzPlaying = false;

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getContext(): AudioContext {
    this.initCtx();
    return this.ctx!;
  }

  public getAnalyser(): AnalyserNode {
    this.initCtx();
    if (!this.analyser) {
      this.analyser = this.ctx!.createAnalyser();
      this.analyser.fftSize = 128;
    }
    return this.analyser;
  }

  public toggle432HzTone(volume: number = 0.15): boolean {
    this.initCtx();
    if (this.is432HzPlaying) {
      this.stop432HzTone();
      return false;
    } else {
      this.start432HzTone(volume);
      return true;
    }
  }

  public start432HzTone(volume: number = 0.15) {
    this.initCtx();
    if (this.is432HzPlaying) return;

    try {
      const ctx = this.ctx!;
      this.analyser = this.getAnalyser();

      this.oscillator = ctx.createOscillator();
      this.gainNode = ctx.createGain();

      // 432Hz Solfeggio Harmonic Frequency
      this.oscillator.type = 'sine';
      this.oscillator.frequency.setValueAtTime(432, ctx.currentTime);

      this.gainNode.gain.setValueAtTime(0, ctx.currentTime);
      this.gainNode.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.5);

      this.oscillator.connect(this.gainNode);
      this.gainNode.connect(this.analyser);
      this.analyser.connect(ctx.destination);

      this.oscillator.start();
      this.is432HzPlaying = true;
    } catch (e) {
      console.error('Failed to start 432Hz audio oscillator:', e);
    }
  }

  public stop432HzTone() {
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.3);
      setTimeout(() => {
        if (this.oscillator) {
          this.oscillator.stop();
          this.oscillator.disconnect();
          this.oscillator = null;
        }
        this.is432HzPlaying = false;
      }, 300);
    } else {
      this.is432HzPlaying = false;
    }
  }

  public isPlaying432Hz(): boolean {
    return this.is432HzPlaying;
  }

  public setVolume(volume: number) {
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.setValueAtTime(volume, this.ctx.currentTime);
    }
  }
}

export const audioEngine = new AudioEngine();
