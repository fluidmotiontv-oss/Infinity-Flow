import React, { useState, useEffect, useRef } from 'react';
import { Radio, Play, Pause, Volume2, Maximize2, Minimize2, Sparkles, RefreshCw, Zap, Shield, Binary } from 'lucide-react';
import { audioEngine } from '../utils/audio';

interface ActiveScript {
  character: string;
  setting: string;
  visualAssets: any[];
  dialogue: string;
}

interface Dragon9StageBroadcastProps {
  activeScript: ActiveScript | null;
  onSynthesizeVoice: (text: string) => void;
  isSynthesizing: boolean;
}

export const Dragon9StageBroadcast: React.FC<Dragon9StageBroadcastProps> = ({
  activeScript,
  onSynthesizeVoice,
  isSynthesizing,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [scrollSpeed, setScrollSpeed] = useState(1);
  const [isScrolling, setIsScrolling] = useState(false);
  const [is432HzDrone, setIs432HzDrone] = useState(true);

  const teleprompterRef = useRef<HTMLDivElement | null>(null);

  const dialogueText = activeScript?.dialogue || "System online. Neural cortex fully synced. Yeah, nah, choice, humans...";

  // Teleprompter Auto-scroll effect
  useEffect(() => {
    let interval: any;
    if (isScrolling && teleprompterRef.current) {
      interval = setInterval(() => {
        if (teleprompterRef.current) {
          teleprompterRef.current.scrollTop += scrollSpeed;
        }
      }, 50);
    }
    return () => clearInterval(interval);
  }, [isScrolling, scrollSpeed]);

  const handleStartBroadcast = () => {
    setIsScrolling(true);
    if (is432HzDrone && !audioEngine.isPlaying432Hz()) {
      audioEngine.start432HzTone(0.12);
    }
    onSynthesizeVoice(dialogueText);
  };

  const handleStopBroadcast = () => {
    setIsScrolling(false);
    audioEngine.stop432HzTone();
  };

  return (
    <div
      className={`bg-slate-950 border border-rose-900/60 rounded-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none border-none overflow-y-auto bg-slate-950' : ''
      }`}
    >
      
      {/* Background Holographic Glow */}
      <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Broadcast Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping"></div>
          <div>
            <h2 className="font-orbitron text-lg font-bold text-slate-100 uppercase tracking-wider flex items-center gap-2">
              DRAGON 9 MEDIA SUITE // STAGE BROADCAST MODE
            </h2>
            <p className="text-xs font-tech text-emerald-400">
              CHARACTER: {activeScript?.character || "CYBER DRAGON"} | SETTING: SOVEREIGN MESH TERMINAL
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 transition-all cursor-pointer"
            title="Toggle Stage Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Main Teleprompter Display */}
      <div className="relative bg-slate-950 border-2 border-emerald-500/40 rounded-2xl p-6 scanlines shadow-inner my-4 glow-emerald">
        
        {/* Stage Status Indicators */}
        <div className="flex items-center justify-between font-tech text-xs text-slate-400 pb-3 border-b border-slate-800">
          <span className="text-emerald-400 font-bold flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            LIVE TELEPROMPTER FEED
          </span>
          <span className="text-amber-400">432Hz HARMONIC SYNC: ON</span>
          <span className="text-sky-400">1080p GEOMETRY ACTIVE</span>
        </div>

        {/* Teleprompter Text Container */}
        <div
          ref={teleprompterRef}
          className="h-80 overflow-y-auto my-4 pr-2 space-y-4 font-chakra text-lg sm:text-xl text-slate-100 font-medium leading-relaxed tracking-wide selection:bg-emerald-500 selection:text-black scroll-smooth"
        >
          <p className="p-4 bg-slate-900/60 rounded-xl border border-slate-800/80 text-emerald-300 font-tech text-sm uppercase">
            [STAGE DIRECTION]: Cyber Dragon steps forward onto sovereign mesh network terminal. Orbital 1080p Moon Grid spins above head, claw glowing with 432Hz River-Plasma orb.
          </p>

          <p className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 text-slate-100 leading-loose">
            "{dialogueText}"
          </p>

          <p className="p-4 bg-slate-900/60 rounded-xl border border-slate-800/80 text-cyan-300 font-tech text-sm uppercase">
            [STAGE DIRECTION]: Binary 'I and O' stream cascades across biotech armor scales. 432Hz harmonic plasma pulse reaches maximum amplitude as mesh broadcast locks in.
          </p>
        </div>

        {/* Prompter Controls Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 font-tech text-xs">
          
          <div className="flex items-center gap-2">
            <button
              onClick={handleStartBroadcast}
              disabled={isSynthesizing}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-orbitron font-bold text-xs uppercase shadow-lg glow-emerald cursor-pointer disabled:opacity-50"
            >
              {isSynthesizing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>SYNTHESIZING STAGE AUDIO...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-slate-950 fill-slate-950" />
                  <span>START BROADCAST (VOICE + PROMPTER)</span>
                </>
              )}
            </button>

            <button
              onClick={handleStopBroadcast}
              className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 font-orbitron text-xs cursor-pointer"
            >
              <Pause className="w-4 h-4 text-rose-400" />
              <span>PAUSE</span>
            </button>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Scroll Speed:</span>
              <input
                type="range"
                min="0.5"
                max="3"
                step="0.5"
                value={scrollSpeed}
                onChange={(e) => setScrollSpeed(Number(e.target.value))}
                className="w-20 accent-emerald-500"
              />
              <span className="text-emerald-400 font-bold">{scrollSpeed}x</span>
            </div>

            <label className="flex items-center gap-1.5 cursor-pointer text-amber-300">
              <input
                type="checkbox"
                checked={is432HzDrone}
                onChange={(e) => setIs432HzDrone(e.target.checked)}
                className="accent-amber-500"
              />
              <span>432Hz Drone</span>
            </label>
          </div>

        </div>

      </div>

    </div>
  );
};
