import React, { useState } from 'react';
import { Image, Sparkles, Download, RefreshCw, Layers, Eye, Code, Zap } from 'lucide-react';

interface VisualAsset {
  id: string;
  type: string;
  description: string;
  mathConstant?: string;
  imageUrl?: string;
}

interface HologramStageGalleryProps {
  activeAssets: VisualAsset[];
  onGenerateImage: (prompt: string) => Promise<string | null>;
  isGeneratingImage: boolean;
}

export const HologramStageGallery: React.FC<HologramStageGalleryProps> = ({
  activeAssets,
  onGenerateImage,
  isGeneratingImage,
}) => {
  const [customAssets, setCustomAssets] = useState<VisualAsset[]>([]);
  const [promptInput, setPromptInput] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<VisualAsset | null>(activeAssets[0] || null);

  const handleCreateAsset = async () => {
    if (!promptInput.trim() || isGeneratingImage) return;

    const imageUrl = await onGenerateImage(promptInput);
    if (imageUrl) {
      const newAsset: VisualAsset = {
        id: `asset_${Date.now()}`,
        type: "Generated_Hologram",
        description: promptInput,
        mathConstant: "432Hz Solfeggio Stage Asset",
        imageUrl: imageUrl,
      };
      setCustomAssets((prev) => [newAsset, ...prev]);
      setSelectedAsset(newAsset);
      setPromptInput('');
    }
  };

  const allAssets = [...customAssets, ...activeAssets];

  const exportManifest = () => {
    const manifest = {
      mediaSuite: "Dragon 9",
      character: "Cyber Dragon",
      sovereignFrequency: "432Hz",
      mathConstants: {
        lunarRadiusMiles: 1080,
        renderResolution: "1080p (1920x1080)",
        solfeggioHarmonicHz: 432,
        legacyGridEfficiency: "35%",
        binaryState: "I and O"
      },
      assets: allAssets.map(a => ({
        id: a.id,
        type: a.type,
        description: a.description,
        mathConstant: a.mathConstant || "432Hz Harmonic",
        hasRenderedImage: !!a.imageUrl
      }))
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(manifest, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `dragon-9-asset-manifest-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Asset Creator */}
      <div className="bg-slate-950 border border-emerald-900/60 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Image className="w-5 h-5 text-emerald-400" />
            <h2 className="font-orbitron text-base font-bold text-slate-100 uppercase tracking-wide">
              Holographic Stage Asset Gallery (Dragon 9)
            </h2>
          </div>
          <button
            onClick={exportManifest}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900 text-xs font-tech cursor-pointer transition-all"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>EXPORT JSON MANIFEST</span>
          </button>
        </div>

        {/* Generate Custom Hologram Image */}
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCreateAsset()}
            placeholder="Describe a stage hologram (e.g., 432Hz plasma dragon claw, 1080p moon matrix)..."
            className="flex-1 bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-4 py-3 font-chakra text-xs text-slate-100 placeholder-slate-600 focus:outline-none"
          />

          <button
            onClick={handleCreateAsset}
            disabled={isGeneratingImage || !promptInput.trim()}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-orbitron font-bold text-xs uppercase shadow-lg glow-emerald disabled:opacity-50 cursor-pointer shrink-0"
          >
            {isGeneratingImage ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                <span>RENDERING...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>GENERATE HOLOGRAM</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid: Assets Cards & Selected Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: Asset List */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {allAssets.map((asset) => (
            <div
              key={asset.id}
              onClick={() => setSelectedAsset(asset)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                selectedAsset?.id === asset.id
                  ? 'bg-slate-900 border-emerald-400 glow-emerald'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] font-tech">
                <span className="text-emerald-400 font-bold uppercase">{asset.type}</span>
                <span className="text-slate-500">{asset.id}</span>
              </div>

              {/* Asset Preview Image or Placeholder */}
              <div className="w-full h-36 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden flex items-center justify-center relative">
                {asset.imageUrl ? (
                  <img src={asset.imageUrl} alt={asset.id} className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center p-3 font-tech space-y-1">
                    <Zap className="w-6 h-6 text-emerald-400 mx-auto animate-pulse" />
                    <p className="text-[10px] text-slate-400">1080p Holographic Asset</p>
                    <p className="text-[9px] text-cyan-400">Click Render to generate image</p>
                  </div>
                )}
              </div>

              <p className="font-chakra text-xs text-slate-200 line-clamp-2">
                {asset.description}
              </p>

              {asset.mathConstant && (
                <div className="pt-2 border-t border-slate-800/80 text-[10px] font-tech text-amber-300">
                  {asset.mathConstant}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Right: Selected Asset Full Inspector */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          {selectedAsset ? (
            <>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-[10px] font-tech font-bold uppercase tracking-widest px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                  {selectedAsset.type}
                </span>
                <span className="text-xs font-tech text-slate-400">{selectedAsset.id}</span>
              </div>

              <div className="w-full h-56 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden flex items-center justify-center relative">
                {selectedAsset.imageUrl ? (
                  <img src={selectedAsset.imageUrl} alt={selectedAsset.id} className="w-full h-full object-cover" />
                ) : (
                  <div className="text-center p-4 font-tech space-y-2">
                    <Eye className="w-8 h-8 text-emerald-400 mx-auto animate-pulse" />
                    <p className="text-xs text-slate-300 font-bold">Hologram Image Not Rendered Yet</p>
                    <button
                      onClick={async () => {
                        const url = await onGenerateImage(selectedAsset.description);
                        if (url) {
                          selectedAsset.imageUrl = url;
                          setSelectedAsset({ ...selectedAsset, imageUrl: url });
                        }
                      }}
                      disabled={isGeneratingImage}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs uppercase cursor-pointer hover:bg-emerald-400"
                    >
                      Render Image Now
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-2 font-chakra text-xs">
                <h4 className="font-orbitron text-sm font-bold text-slate-100">Asset Specification</h4>
                <p className="text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  {selectedAsset.description}
                </p>
              </div>

              {selectedAsset.mathConstant && (
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs font-tech text-amber-300 flex items-center justify-between">
                  <span className="text-slate-400">Harmonic Mapping:</span>
                  <span className="font-bold">{selectedAsset.mathConstant}</span>
                </div>
              )}
            </>
          ) : (
            <p className="text-xs font-tech text-slate-500 text-center py-10">Select an asset to inspect details.</p>
          )}
        </div>

      </div>

    </div>
  );
};
