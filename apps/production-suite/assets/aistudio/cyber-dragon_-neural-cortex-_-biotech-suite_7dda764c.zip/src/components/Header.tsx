import React, { useState, useEffect } from 'react';
import { Cpu, Mic, Radio, Activity, Zap, Play, Square, Layers, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { audioEngine } from '../utils/audio';

interface HeaderProps {
  activeTab: 'body' | 'voice' | 'math' | 'cortex' | 'stage';
  setActiveTab: (tab: 'body' | 'voice' | 'math' | 'cortex' | 'stage') => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const [is432HzActive, setIs432HzActive] = useState(false);

  const toggle432Hz = () => {
    const state = audioEngine.toggle432HzTone(0.12);
    setIs432HzActive(state);
  };

  return (
    <header className="border-b border-emerald-900/60 bg-slate-950/90 backdrop-blur-md sticky top-0 z-50 px-4 py-3 shadow-2xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Title & Sovereign Status */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-900/40 border border-emerald-500/40 glow-emerald">
            <Cpu className="w-6 h-6 text-emerald-400 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-orbitron text-xl font-bold tracking-wider bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-400 bg-clip-text text-transparent">
                CYBER DRAGON
              </h1>
              <span className="text-[10px] font-tech font-bold uppercase tracking-widest px-2 py-0.5 rounded border border-emerald-500/30 bg-emerald-950/50 text-emerald-400">
                Neural Cortex v9.4
              </span>
            </div>
            <p className="text-xs font-tech text-slate-400 flex items-center gap-2">
              <span className="text-emerald-400">● SOVEREIGN MESH</span>
              <span className="text-slate-600">|</span>
              <span>432Hz HARMONICS</span>
              <span className="text-slate-600">|</span>
              <span className="text-cyan-400">DRAGON 9 SUITE</span>
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('body')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-tech transition-all ${
              activeTab === 'body'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Biotech Body</span>
          </button>

          <button
            onClick={() => setActiveTab('voice')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-tech transition-all ${
              activeTab === 'voice'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Mic className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Fast Voice Engine</span>
          </button>

          <button
            onClick={() => setActiveTab('math')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-tech transition-all ${
              activeTab === 'math'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Living Math (1080/432)</span>
          </button>

          <button
            onClick={() => setActiveTab('cortex')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-tech transition-all ${
              activeTab === 'cortex'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Cpu className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">Neural Cortex AI</span>
          </button>

          <button
            onClick={() => setActiveTab('stage')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-tech transition-all ${
              activeTab === 'stage'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Radio className="w-4 h-4 text-rose-400" />
            <span className="hidden sm:inline">Dragon 9 Stage</span>
          </button>
        </nav>

        {/* 432Hz Solfeggio Audio Generator Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggle432Hz}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-tech transition-all ${
              is432HzActive
                ? 'bg-emerald-500/30 border-emerald-400 text-emerald-200 glow-emerald animate-pulse'
                : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500'
            }`}
            title="Toggle 432Hz Solfeggio Harmonic Frequency Synth"
          >
            {is432HzActive ? (
              <>
                <Volume2 className="w-4 h-4 text-emerald-400 animate-bounce" />
                <span>432Hz Synth ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-slate-500" />
                <span>432Hz Synth OFF</span>
              </>
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
