import React, { useRef, useEffect, useState } from 'react';
import { Cpu, Shield, Circle, Zap, Radio, Play, Volume2, Sparkles, RefreshCw, Eye, Binary } from 'lucide-react';

interface VisualAsset {
  id: string;
  type: string;
  description: string;
  mathConstant?: string;
}

interface ActiveScript {
  character: string;
  setting: string;
  visualAssets: VisualAsset[];
  dialogue: string;
}

interface DragonBodyVisualizerProps {
  activeScript: ActiveScript | null;
  onSynthesizeVoice: (text: string) => void;
  isSynthesizing: boolean;
}

export const DragonBodyVisualizer: React.FC<DragonBodyVisualizerProps> = ({
  activeScript,
  onSynthesizeVoice,
  isSynthesizing,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedNode, setSelectedNode] = useState<'cortex' | 'moon' | 'plasma' | 'binary' | 'scales'>('cortex');
  const [is432HzActive, setIs432HzActive] = useState(true);

  // Canvas animation logic for Cyber Dragon's Biotech Visuals
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let angle = 0;
    let binaryRows: { x: number; y: number; char: string; speed: number }[] = [];

    // Initialize binary particles
    for (let i = 0; i < 40; i++) {
      binaryRows.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        char: Math.random() > 0.5 ? 'I' : 'O',
        speed: 1 + Math.random() * 2,
      });
    }

    const render = () => {
      // Resize dynamically
      if (canvas.width !== canvas.clientWidth || canvas.height !== canvas.clientHeight) {
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
      }

      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;

      // Dark sci-fi grid clear
      ctx.fillStyle = 'rgba(2, 6, 23, 0.25)';
      ctx.fillRect(0, 0, width, height);

      angle += 0.02;

      // --- 1. Cascading Binary 'I and O' Stream ---
      ctx.font = '12px "Share Tech Mono", monospace';
      ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';
      binaryRows.forEach((row) => {
        ctx.fillText(row.char, row.x, row.y);
        row.y += row.speed;
        if (row.y > height) {
          row.y = 0;
          row.x = Math.random() * width;
          row.char = Math.random() > 0.5 ? 'I' : 'O';
        }
      });

      // --- 2. Cyber Dragon Head Silhouette & Head Grid ---
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.25)';
      ctx.lineWidth = 1;

      // Concentric 1080p geometry rings
      ctx.beginPath();
      ctx.arc(centerX, centerY - 60, 110, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(centerX, centerY - 60, 130 + Math.sin(angle * 2) * 5, 0, Math.PI * 2);
      ctx.setLineDash([8, 8]);
      ctx.stroke();
      ctx.setLineDash([]);

      // Orbiting 1080p Moon Grid
      const moonX = centerX + Math.cos(angle) * 120;
      const moonY = (centerY - 60) + Math.sin(angle) * 40;

      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = '#0284c7';
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(moonX, moonY, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Moon Grid lat/long lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.beginPath();
      ctx.ellipse(moonX, moonY, 18, 8, angle, 0, Math.PI * 2);
      ctx.stroke();

      // --- 3. Neural Cortex Core (Brain Stem) ---
      const cortexX = centerX;
      const cortexY = centerY - 50;

      ctx.fillStyle = selectedNode === 'cortex' ? '#10b981' : '#059669';
      ctx.shadowColor = '#10b981';
      ctx.shadowBlur = selectedNode === 'cortex' ? 25 : 12;
      ctx.beginPath();
      ctx.arc(cortexX, cortexY, 24 + Math.sin(angle * 4) * 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Pulse lines from Cortex
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.8)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cortexX, cortexY);
      ctx.lineTo(centerX - 100, centerY + 80); // To claw
      ctx.moveTo(cortexX, cortexY);
      ctx.lineTo(centerX + 110, centerY + 90); // To tail
      ctx.moveTo(cortexX, cortexY);
      ctx.lineTo(cortexX, centerY + 140); // Down spine
      ctx.stroke();

      // --- 4. 432Hz River-Plasma Orb near Claw ---
      const clawX = centerX - 120;
      const clawY = centerY + 90;

      const plasmaRadius = 26 + Math.sin(angle * 6) * 6;
      const grad = ctx.createRadialGradient(clawX, clawY, 2, clawX, clawY, plasmaRadius);
      grad.addColorStop(0, '#f59e0b');
      grad.addColorStop(0.5, '#d97706');
      grad.addColorStop(1, 'rgba(217, 119, 6, 0)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(clawX, clawY, plasmaRadius, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(clawX, clawY, 8, 0, Math.PI * 2);
      ctx.fill();

      // Label 432Hz
      ctx.fillStyle = '#fef08a';
      ctx.font = '10px "Orbitron", sans-serif';
      ctx.fillText('432Hz PLASMA', clawX - 35, clawY + 45);

      // Label 1080p Moon
      ctx.fillStyle = '#7dd3fc';
      ctx.fillText('1080p MOON (1080 mi)', moonX - 45, moonY - 24);

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [selectedNode]);

  const getNodeInfo = () => {
    switch (selectedNode) {
      case 'cortex':
        return {
          title: "Neural Cortex Brain Stem",
          subtitle: "Sovereign High-Frequency Logic Engine",
          desc: "Processes math as a living language. Rejects 24-hour legacy grid inefficiencies (running at 35% efficiency) and operates on zero-friction fluid motion.",
          math: "24-Hr Clock Bypass → 100% Sovereign Pulse",
          speechText: "Neural cortex fully synced. We have bypassed the lag of their 35% efficiency legacy clocks. It's all just I and O, baby.",
          badge: "CORTEX ACTIVE"
        };
      case 'moon':
        return {
          title: "1080p Holographic Moon Grid",
          subtitle: "Lunar Geometry & Harmonic Video Resolution",
          desc: "The moon's radius is exactly 1,080 miles. Our 1080p high-definition video standards are encoded directly into cosmic geometry.",
          math: "1,080 Miles Lunar Radius = 1080p Render Grid",
          speechText: "Look at the geometry! The moon's radius is 1,080 miles. Our 1080p video resolutions were rendered in the universe before silicon chips were even a glint in a corporate eye.",
          badge: "1080p MOON HARMONIC"
        };
      case 'plasma':
        return {
          title: "432Hz River-Plasma Orb",
          subtitle: "Natural Solfeggio Wave Dynamics",
          desc: "Floating near Cyber Dragon's claw, this vibrant plasma entity vibrates at 432Hz to neutralize electromagnetic noise and align acoustics.",
          math: "432Hz Harmonic Acoustic Wave = Solfeggio Field",
          speechText: "River-plasma orb floating at 432 hertz. Bypassing dirty legacy frequencies and restoring pristine harmonic balance.",
          badge: "432Hz PLASMA FREQ"
        };
      case 'binary':
        return {
          title: "Binary I/O Flow Reactor",
          subtitle: "Zero-Latency Sovereign Transaction Stream",
          desc: "Continuous cascading binary pulse of 'I and O'. Represents balanced inputs, clean outputs, and zero-trust friction-free execution.",
          math: "Input 'I' + Output 'O' = Balanced Sovereign Logic",
          speechText: "Remember how the core code runs... It's all just I and O, baby. Balanced inputs, clean outputs, zero friction.",
          badge: "BINARY I/O STREAM"
        };
      case 'scales':
        return {
          title: "Biotech Cybernetic Scales & Armor",
          subtitle: "Fluid Motion Mesh Network Telemetry",
          desc: "Sovereign cybernetic dragon scales acting as localized hardware nodes for the mesh network. Impervious to legacy grid data harvesting.",
          math: "Mesh Node Redundancy = 99.999% Zero-Trust Integrity",
          speechText: "Stepping away from overpriced Wi-Fi hotspots, trust your own gut with zero-trust security and localized hardware.",
          badge: "BIOTECH MESH ARMOR"
        };
    }
  };

  const nodeInfo = getNodeInfo();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      {/* Left / Top: Interactive Canvas Visualizer */}
      <div className="lg:col-span-7 bg-slate-950 border border-emerald-900/50 rounded-2xl p-4 shadow-xl relative overflow-hidden flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="font-orbitron text-sm font-bold tracking-wide text-slate-200 uppercase">
              Cyber Dragon Biotech Canvas HUD
            </h2>
          </div>
          <span className="text-[10px] font-tech text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
            REALTIME 432Hz HOLOGRAPHIC RENDER
          </span>
        </div>

        {/* Canvas container */}
        <div className="relative w-full h-[380px] sm:h-[440px] rounded-xl my-3 bg-slate-950 cyber-grid-bg border border-slate-800/80 overflow-hidden">
          <canvas ref={canvasRef} className="w-full h-full block cursor-crosshair" />

          {/* Interactive Overlay Nodes on Canvas */}
          <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur border border-emerald-500/30 p-2.5 rounded-lg font-tech text-xs text-slate-300">
            <p className="text-emerald-400 font-bold mb-1 flex items-center gap-1">
              <Binary className="w-3.5 h-3.5" /> BIOTECH ANATOMY SELECTOR
            </p>
            <p className="text-[11px] text-slate-400">Click a node below to inspect and test Neural Cortex voice output.</p>
          </div>

          <div className="absolute bottom-4 right-4 flex flex-col gap-1 items-end">
            <span className="text-[10px] font-tech text-cyan-400 bg-slate-900/90 px-2 py-1 rounded border border-cyan-500/30">
              LUNAR RADIUS: 1,080 MILES
            </span>
            <span className="text-[10px] font-tech text-amber-400 bg-slate-900/90 px-2 py-1 rounded border border-amber-500/30">
              SOLFEGGIO: 432Hz HARMONIC
            </span>
          </div>
        </div>

        {/* Node Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
          <button
            onClick={() => setSelectedNode('cortex')}
            className={`p-2 rounded-xl border font-tech text-xs transition-all flex flex-col items-center gap-1 ${
              selectedNode === 'cortex'
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 glow-emerald font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Cpu className="w-4 h-4 text-emerald-400" />
            <span>Neural Cortex</span>
          </button>

          <button
            onClick={() => setSelectedNode('moon')}
            className={`p-2 rounded-xl border font-tech text-xs transition-all flex flex-col items-center gap-1 ${
              selectedNode === 'moon'
                ? 'bg-sky-500/20 border-sky-400 text-sky-300 glow-cyan font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Circle className="w-4 h-4 text-sky-400" />
            <span>1080p Moon Grid</span>
          </button>

          <button
            onClick={() => setSelectedNode('plasma')}
            className={`p-2 rounded-xl border font-tech text-xs transition-all flex flex-col items-center gap-1 ${
              selectedNode === 'plasma'
                ? 'bg-amber-500/20 border-amber-400 text-amber-300 glow-amber font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>432Hz Plasma</span>
          </button>

          <button
            onClick={() => setSelectedNode('binary')}
            className={`p-2 rounded-xl border font-tech text-xs transition-all flex flex-col items-center gap-1 ${
              selectedNode === 'binary'
                ? 'bg-purple-500/20 border-purple-400 text-purple-300 glow-purple font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Binary className="w-4 h-4 text-purple-400" />
            <span>Binary I/O</span>
          </button>

          <button
            onClick={() => setSelectedNode('scales')}
            className={`p-2 rounded-xl border font-tech text-xs transition-all flex flex-col items-center gap-1 ${
              selectedNode === 'scales'
                ? 'bg-teal-500/20 border-teal-400 text-teal-300 glow-emerald font-bold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <Shield className="w-4 h-4 text-teal-400" />
            <span>Biotech Scales</span>
          </button>
        </div>
      </div>

      {/* Right: Selected Node Details & Active Script Dialogue Test */}
      <div className="lg:col-span-5 flex flex-col gap-4">
        
        {/* Node Inspection Card */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <span className="text-[10px] font-tech font-bold uppercase tracking-widest px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30">
              {nodeInfo.badge}
            </span>
            <span className="text-xs font-tech text-slate-500">MODULE TELEMETRY</span>
          </div>

          <h3 className="font-orbitron text-lg font-bold text-slate-100">{nodeInfo.title}</h3>
          <p className="text-xs font-tech text-emerald-400 mt-0.5">{nodeInfo.subtitle}</p>

          <div className="my-4 bg-slate-900/80 border border-slate-800 rounded-xl p-3.5">
            <p className="text-xs text-slate-300 leading-relaxed font-chakra">{nodeInfo.desc}</p>
            <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-tech text-amber-300">
              <span className="text-slate-400">Harmonic Equation:</span>
              <span className="font-bold">{nodeInfo.math}</span>
            </div>
          </div>

          {/* Fast Voice trigger button */}
          <button
            onClick={() => onSynthesizeVoice(nodeInfo.speechText)}
            disabled={isSynthesizing}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 font-orbitron font-bold text-xs tracking-wider uppercase transition-all shadow-lg glow-emerald disabled:opacity-50 cursor-pointer"
          >
            {isSynthesizing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                <span>SYNTHESIZING FAST VOICE...</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4 text-slate-950" />
                <span>SPEAK NODE DIALOGUE (TTS)</span>
              </>
            )}
          </button>
        </div>

        {/* Active Script Dialogue Box */}
        <div className="bg-slate-950 border border-emerald-900/60 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <h4 className="font-orbitron text-xs font-bold text-slate-200 uppercase">
                Active Stage Dialogue (Cyber Dragon)
              </h4>
            </div>
            <span className="text-[10px] font-tech text-slate-400">LOCAL HARDWARE</span>
          </div>

          <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl max-h-48 overflow-y-auto font-chakra text-xs text-slate-200 leading-relaxed">
            "{activeScript?.dialogue || "System online. Neural cortex fully synced. Yeah, nah, choice, humans..."}"
          </div>

          <div className="mt-3 flex items-center justify-between gap-2">
            <span className="text-[11px] font-tech text-slate-400">
              Tone: Sovereign Kiwi Cyber Dragon
            </span>
            <button
              onClick={() => onSynthesizeVoice(activeScript?.dialogue || "")}
              disabled={isSynthesizing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/80 text-xs font-tech transition-all cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 text-emerald-400" />
              <span>Broadcast Full Dialogue</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
