import React, { useState, useRef, useEffect } from 'react';
import { Cpu, Send, Sparkles, Volume2, Copy, Check, Code, FileText, Image, RefreshCw, Radio } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'cortex';
  text: string;
  mode?: string;
  timestamp: string;
}

interface NeuralCortexConsoleProps {
  onSynthesizeVoice: (text: string) => void;
  onGenerateImage: (prompt: string) => void;
  isSynthesizing: boolean;
}

export const NeuralCortexConsole: React.FC<NeuralCortexConsoleProps> = ({
  onSynthesizeVoice,
  onGenerateImage,
  isSynthesizing,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init_1',
      sender: 'cortex',
      text: "System online. Neural cortex fully synced. Yeah, nah, choice, humans! Ready to generate stage scripts, JSON asset manifests, and visual prompts for Cyber Dragon's performance suite. What's the directive, mate?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [activeMode, setActiveMode] = useState<'general' | 'script' | 'manifest' | 'math' | 'prompts'>('general');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputText,
      mode: activeMode,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    const currentInput = inputText;
    setInputText('');
    setIsLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.sender === 'user' ? 'user' : 'model',
        text: m.text,
      }));

      const res = await fetch('/api/cortex/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: currentInput,
          mode: activeMode,
          history: history,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Cortex response error');

      const cortexMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'cortex',
        text: data.text || "Neural Cortex processed your request.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, cortexMsg]);
    } catch (e: any) {
      console.error(e);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          sender: 'cortex',
          text: `Neural Cortex error: ${e.message || 'Transmission disrupted.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-slate-950 border border-purple-900/50 rounded-2xl p-5 shadow-2xl flex flex-col h-[700px] relative overflow-hidden">
      
      {/* Header & Mode Bar */}
      <div className="pb-3 border-b border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-purple-400" />
            <h2 className="font-orbitron text-base font-bold text-slate-100 uppercase tracking-wide">
              Neural Cortex AI Terminal
            </h2>
          </div>
          <span className="text-[10px] font-tech text-purple-300 bg-purple-950/80 px-2.5 py-1 rounded border border-purple-500/30">
            MODEL: GEMINI 3.8 FLASH
          </span>
        </div>

        {/* Mode Selector */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[11px] font-tech text-slate-400 mr-1">Directives:</span>
          
          <button
            onClick={() => setActiveMode('general')}
            className={`px-3 py-1 rounded-lg text-xs font-tech transition-all cursor-pointer ${
              activeMode === 'general'
                ? 'bg-purple-500/30 text-purple-200 border border-purple-400 glow-purple font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
            }`}
          >
            Kiwi Chat
          </button>

          <button
            onClick={() => setActiveMode('script')}
            className={`px-3 py-1 rounded-lg text-xs font-tech transition-all cursor-pointer ${
              activeMode === 'script'
                ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400 glow-emerald font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
            }`}
          >
            Stage Script
          </button>

          <button
            onClick={() => setActiveMode('manifest')}
            className={`px-3 py-1 rounded-lg text-xs font-tech transition-all cursor-pointer ${
              activeMode === 'manifest'
                ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400 glow-cyan font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
            }`}
          >
            JSON Asset Manifest
          </button>

          <button
            onClick={() => setActiveMode('math')}
            className={`px-3 py-1 rounded-lg text-xs font-tech transition-all cursor-pointer ${
              activeMode === 'math'
                ? 'bg-amber-500/30 text-amber-200 border border-amber-400 glow-amber font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
            }`}
          >
            Living Math
          </button>

          <button
            onClick={() => setActiveMode('prompts')}
            className={`px-3 py-1 rounded-lg text-xs font-tech transition-all cursor-pointer ${
              activeMode === 'prompts'
                ? 'bg-rose-500/30 text-rose-200 border border-rose-400 glow-purple font-bold'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-700'
            }`}
          >
            Visual Prompts
          </button>
        </div>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto my-4 space-y-4 pr-1 font-chakra text-xs">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            <div
              className={`max-w-[88%] rounded-2xl p-4 shadow-lg border space-y-2 ${
                msg.sender === 'user'
                  ? 'bg-slate-900 border-slate-700 text-slate-100 rounded-br-none'
                  : 'bg-slate-950 border-purple-900/60 text-slate-200 rounded-bl-none glow-purple'
              }`}
            >
              <div className="flex items-center justify-between gap-4 text-[10px] font-tech text-slate-400 pb-1 border-b border-slate-800/80">
                <span className={msg.sender === 'cortex' ? 'text-purple-400 font-bold' : 'text-slate-300'}>
                  {msg.sender === 'cortex' ? 'NEURAL CORTEX (CYBER DRAGON)' : 'OPERATOR'}
                </span>
                <span>{msg.timestamp}</span>
              </div>

              <div className="whitespace-pre-wrap leading-relaxed text-xs">
                {msg.text}
              </div>

              {/* Action Buttons for Cortex Messages */}
              {msg.sender === 'cortex' && (
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    onClick={() => onSynthesizeVoice(msg.text)}
                    disabled={isSynthesizing}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900 text-[10px] font-tech cursor-pointer"
                  >
                    <Volume2 className="w-3 h-3 text-emerald-400" />
                    <span>Speak Response (TTS)</span>
                  </button>

                  <button
                    onClick={() => copyToClipboard(msg.id, msg.text)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 hover:border-slate-500 text-[10px] font-tech cursor-pointer"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-cyan-400" />
                        <span>Copy Text</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onGenerateImage(msg.text.slice(0, 200))}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-purple-950 border border-purple-500/40 text-purple-300 hover:bg-purple-900 text-[10px] font-tech cursor-pointer"
                  >
                    <Image className="w-3 h-3 text-purple-400" />
                    <span>Render Stage Image</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 p-3 bg-slate-900/80 rounded-xl border border-purple-800/50 w-fit">
            <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
            <span className="font-tech text-xs text-purple-300 animate-pulse">
              Neural Cortex processing high-frequency directive...
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={`Enter directive in ${activeMode.toUpperCase()} mode...`}
          className="flex-1 bg-slate-900 border border-slate-800 focus:border-purple-500 rounded-xl px-4 py-3 font-chakra text-xs text-slate-100 placeholder-slate-600 focus:outline-none"
        />

        <button
          onClick={handleSend}
          disabled={isLoading || !inputText.trim()}
          className="p-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-slate-950 font-bold transition-all shadow-lg glow-purple disabled:opacity-50 cursor-pointer"
        >
          <Send className="w-4 h-4 text-slate-950" />
        </button>
      </div>

    </div>
  );
};
