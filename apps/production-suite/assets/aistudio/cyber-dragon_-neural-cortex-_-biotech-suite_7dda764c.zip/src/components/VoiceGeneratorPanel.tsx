import React, { useState, useRef, useEffect } from 'react';
import { Mic, Play, Pause, Download, Sparkles, Volume2, Settings2, RefreshCw, Layers, Radio, Music, MessageSquare } from 'lucide-react';
import { audioEngine } from '../utils/audio';

interface SpeechItem {
  id: string;
  text: string;
  voiceName: string;
  audioUrl: string;
  timestamp: string;
}

interface VoiceGeneratorPanelProps {
  onSynthesizeVoice: (text: string, voiceName?: string) => Promise<string | null>;
  isSynthesizing: boolean;
  currentAudioUrl: string | null;
}

export const VoiceGeneratorPanel: React.FC<VoiceGeneratorPanelProps> = ({
  onSynthesizeVoice,
  isSynthesizing,
  currentAudioUrl,
}) => {
  const [textInput, setTextInput] = useState(
    "System online. Neural cortex fully synced. Yeah, nah, choice, humans. Let's talk about the old world's 24-hour clock—a legacy system leaking worse than a rusted corrugated iron tank in a southerly storm. Good as gold, mate, but we've bypassed the lag. It's all just I and O, baby."
  );
  const [selectedVoice, setSelectedVoice] = useState('Fenrir');
  const [speechHistory, setSpeechHistory] = useState<SpeechItem[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [overlay432Hz, setOverlay432Hz] = useState(true);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const voicePresets = [
    { name: 'Fenrir', label: 'Cyber Dragon Sovereign', style: 'Deep, resonant, Kiwi dialect' },
    { name: 'Puck', label: 'Kiwi Kinetic Mesh', style: 'Bright, fast-paced, sharp humor' },
    { name: 'Kore', label: 'Plasma Wave Resonance', style: 'Solfeggio harmonic, crisp' },
    { name: 'Zephyr', label: 'High-Frequency Cortex', style: 'Clear, articulate, intense' },
    { name: 'Charon', label: 'Sub-Bass Sovereign', style: 'Low-frequency, authoritative' },
  ];

  const quickPrompts = [
    "Yeah, nah, choice, humans! The 24-hour grid clock is running at 35% efficiency down at the back of the pub couch.",
    "Look at the geometry—1,080 miles lunar radius mapped directly to 1080p high-def video resolutions.",
    "River-plasma orb floating at 432 hertz wave dynamics. Zero corporate data harvesting permitted.",
    "Remember how the core code runs... It's all just I and O, baby. Balanced inputs, clean outputs, zero friction."
  ];

  const vocalModifiers = [
    { tag: '<breath>', label: 'Breath' },
    { tag: '<gasp>', label: 'Gasp' },
    { tag: '<laugh>', label: 'Laugh' },
    { tag: '|yeah|', label: 'Backchannel Yeah' },
    { tag: '|mhm|', label: 'Backchannel Mhm' },
    { tag: 'Yeah, nah, ', label: 'Kiwi Prefix' },
    { tag: 'Good as gold, mate! ', label: 'Gold Mate' },
  ];

  // Handle TTS synthesis trigger
  const handleGenerate = async () => {
    if (!textInput.trim()) return;

    if (overlay432Hz && !audioEngine.isPlaying432Hz()) {
      audioEngine.start432HzTone(0.1);
    }

    const audioUrl = await onSynthesizeVoice(textInput, selectedVoice);
    if (audioUrl) {
      const newItem: SpeechItem = {
        id: Date.now().toString(),
        text: textInput,
        voiceName: selectedVoice,
        audioUrl: audioUrl,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setSpeechHistory((prev) => [newItem, ...prev]);

      if (audioRef.current) {
        audioRef.current.src = audioUrl;
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const insertModifier = (tag: string) => {
    setTextInput((prev) => prev + " " + tag);
  };

  // Canvas visualizer for audio playback
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const drawVisualizer = () => {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;
      const bars = 48;
      const barWidth = width / bars;

      for (let i = 0; i < bars; i++) {
        // Dynamic waveform effect if audio is playing or synthesizing
        const h = isPlaying
          ? Math.sin(Date.now() * 0.008 + i * 0.2) * (height / 2.5) + (height / 3)
          : isSynthesizing
          ? Math.sin(Date.now() * 0.015 + i * 0.4) * (height / 3) + 10
          : 4 + Math.sin(i * 0.3) * 3;

        const x = i * barWidth;
        const y = (height - h) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + h);
        grad.addColorStop(0, '#10b981');
        grad.addColorStop(0.5, '#06b6d4');
        grad.addColorStop(1, '#a855f7');

        ctx.fillStyle = grad;
        ctx.fillRect(x + 1, y, barWidth - 2, h);
      }

      animId = requestAnimationFrame(drawVisualizer);
    };

    drawVisualizer();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isSynthesizing]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      {/* Left Column: Voice Engine Controls */}
      <div className="lg:col-span-8 bg-slate-950 border border-emerald-900/60 rounded-2xl p-5 shadow-2xl space-y-5">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-emerald-400" />
            <h2 className="font-orbitron text-base font-bold text-slate-100 uppercase tracking-wide">
              Fast Voice Synthesis Studio (Gemini 3.8 TTS)
            </h2>
          </div>
          <span className="text-[10px] font-tech text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
            HIGH-THROUGHPUT REALTIME AUDIO
          </span>
        </div>

        {/* Text Input Box */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-tech text-slate-300 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              Cyber Dragon Script Input:
            </label>
            <span className="text-[10px] font-tech text-slate-500">
              {textInput.length} characters
            </span>
          </div>

          <textarea
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            rows={4}
            placeholder="Type or generate Cyber Dragon dialogue here..."
            className="w-full bg-slate-900/90 border border-slate-800 focus:border-emerald-500 rounded-xl p-3.5 font-chakra text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all leading-relaxed"
          />

          {/* Expressive Modifiers */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="text-[10px] font-tech text-slate-400 mr-1">Insert Vocal Bursts:</span>
            {vocalModifiers.map((mod, idx) => (
              <button
                key={idx}
                onClick={() => insertModifier(mod.tag)}
                className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 hover:border-emerald-500 text-[10px] font-tech text-emerald-300 transition-all cursor-pointer"
              >
                + {mod.label}
              </button>
            ))}
          </div>
        </div>

        {/* Voice Persona Selector & 432Hz Overlay */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div className="space-y-1.5">
            <label className="text-xs font-tech text-slate-300 flex items-center gap-1.5">
              <Settings2 className="w-3.5 h-3.5 text-cyan-400" />
              Voice Persona Architecture:
            </label>
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 font-tech text-xs text-slate-200 focus:outline-none"
            >
              {voicePresets.map((vp) => (
                <option key={vp.name} value={vp.name}>
                  {vp.name} ({vp.label})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5 flex flex-col justify-end">
            <label className="flex items-center gap-2 cursor-pointer p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700">
              <input
                type="checkbox"
                checked={overlay432Hz}
                onChange={(e) => setOverlay432Hz(e.target.checked)}
                className="accent-emerald-500 w-4 h-4 rounded"
              />
              <span className="text-xs font-tech text-amber-300">
                Overlay 432Hz Solfeggio Harmonic Drone
              </span>
            </label>
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={isSynthesizing || !textInput.trim()}
          className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-orbitron font-bold text-sm tracking-wider uppercase transition-all shadow-xl glow-emerald cursor-pointer disabled:opacity-50"
        >
          {isSynthesizing ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
              <span>SYNTHESIZING SOVEREIGN VOICE...</span>
            </>
          ) : (
            <>
              <Volume2 className="w-5 h-5 text-slate-950" />
              <span>SYNTHESIZE FAST VOICE (GEMINI TTS)</span>
            </>
          )}
        </button>

        {/* Audio Player & Live Visualizer */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-tech text-emerald-400 flex items-center gap-1.5">
              <Radio className="w-4 h-4 animate-pulse" />
              REALTIME SPECTRUM VISUALIZER
            </span>
            <span className="text-[10px] font-tech text-slate-400">
              {isPlaying ? "PLAYING AUDIO..." : "AUDIO READY"}
            </span>
          </div>

          {/* Waveform Canvas */}
          <div className="w-full h-16 bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
            <canvas ref={canvasRef} className="w-full h-full block" />
          </div>

          <audio
            ref={audioRef}
            controls
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            className="w-full h-10 rounded-lg bg-slate-950 accent-emerald-500"
          />
        </div>

      </div>

      {/* Right Column: Quick Presets & Speech History */}
      <div className="lg:col-span-4 space-y-5">
        
        {/* Quick Kiwi Sovereign Scripts */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h3 className="font-orbitron text-xs font-bold text-slate-200 uppercase">
              Quick Kiwi Cyber Scripts
            </h3>
          </div>

          <div className="space-y-2">
            {quickPrompts.map((promptText, i) => (
              <button
                key={i}
                onClick={() => setTextInput(promptText)}
                className="w-full text-left p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/50 transition-all font-chakra text-xs text-slate-300 line-clamp-2 hover:text-emerald-300 cursor-pointer"
              >
                "{promptText}"
              </button>
            ))}
          </div>
        </div>

        {/* Speech Output History */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <h3 className="font-orbitron text-xs font-bold text-slate-200 uppercase">
                Voice Output Log ({speechHistory.length})
              </h3>
            </div>
          </div>

          {speechHistory.length === 0 ? (
            <p className="text-xs font-tech text-slate-500 text-center py-6">
              No audio generated yet. Click synthesize above to generate fast voice audio.
            </p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {speechHistory.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2"
                >
                  <div className="flex items-center justify-between text-[10px] font-tech text-slate-400">
                    <span className="text-emerald-400 font-bold">{item.voiceName}</span>
                    <span>{item.timestamp}</span>
                  </div>
                  <p className="font-chakra text-xs text-slate-200 line-clamp-2">
                    "{item.text}"
                  </p>
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => {
                        if (audioRef.current) {
                          audioRef.current.src = item.audioUrl;
                          audioRef.current.play();
                          setIsPlaying(true);
                        }
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-950 border border-emerald-500/30 text-emerald-300 text-[10px] font-tech hover:bg-emerald-900/60 cursor-pointer"
                    >
                      <Play className="w-3 h-3 text-emerald-400" />
                      <span>Replay</span>
                    </button>
                    <a
                      href={item.audioUrl}
                      download={`cyber-dragon-voice-${item.id}.wav`}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300 text-[10px] font-tech hover:border-slate-500"
                    >
                      <Download className="w-3 h-3 text-cyan-400" />
                      <span>WAV</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
