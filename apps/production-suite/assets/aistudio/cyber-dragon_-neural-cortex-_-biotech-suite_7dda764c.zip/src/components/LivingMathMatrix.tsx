import React, { useState } from 'react';
import { Zap, Circle, Binary, Calculator, Clock, Activity, Cpu, RefreshCw, Volume2 } from 'lucide-react';

interface LivingMathMatrixProps {
  onSynthesizeVoice: (text: string) => void;
}

export const LivingMathMatrix: React.FC<LivingMathMatrixProps> = ({ onSynthesizeVoice }) => {
  // Interactive Math Inputs
  const [lunarMiles, setLunarMiles] = useState(1080);
  const [solfeggioFreq, setSolfeggioFreq] = useState(432);
  const [legacyClockHrs, setLegacyClockHrs] = useState(24);
  const [binaryBits, setBinaryBits] = useState(['I', 'O', 'I', 'I', 'O', 'I', 'O', 'O']);

  // Calculated geometry values
  const resolutionY = lunarMiles; // 1080p
  const resolutionX = Math.round(lunarMiles * (16 / 9)); // 1920
  const legacyEfficiency = 35; // 35% efficiency
  const sovereignEfficiency = 100;
  const harmonicOctave = solfeggioFreq / 2; // 216Hz

  const toggleBit = (index: number) => {
    setBinaryBits((prev) => {
      const next = [...prev];
      next[index] = next[index] === 'I' ? 'O' : 'I';
      return next;
    });
  };

  const explainMathSpeech = `Look at the numbers—they aren't dry data for your power bills. The moon's radius is ${lunarMiles} miles, our digital video resolutions are right there in the geometry at ${resolutionX} by ${resolutionY} pixels. The 432 hertz wave dynamics align with natural river-plasma frequencies. Legacy 24-hour grid clocks leak at 35 percent efficiency. We bypass the lag with balanced I and O inputs and clean outputs.`;

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-slate-950 border border-amber-900/50 rounded-2xl p-5 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-amber-400 animate-pulse" />
            <h2 className="font-orbitron text-lg font-bold text-slate-100 uppercase tracking-wide">
              Living Math Matrix & Geometry Deconstructor
            </h2>
          </div>
          <p className="text-xs font-chakra text-slate-400 mt-1">
            Processing mathematics as a sovereign living language linking cosmic geometry, video resolutions, 432Hz harmonics, and binary 'I and O'.
          </p>
        </div>

        <button
          onClick={() => onSynthesizeVoice(explainMathSpeech)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 font-orbitron font-bold text-xs uppercase shadow-lg glow-amber cursor-pointer hover:opacity-90 transition-all shrink-0"
        >
          <Volume2 className="w-4 h-4 text-slate-950" />
          <span>Speak Math Deconstruction</span>
        </button>
      </div>

      {/* Grid of 4 Living Math Modules */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Module 1: Lunar Radius & Video Resolution Geometry */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Circle className="w-5 h-5 text-sky-400" />
              <h3 className="font-orbitron text-sm font-bold text-slate-200 uppercase">
                1,080 Miles Lunar Geometry → 1080p
              </h3>
            </div>
            <span className="text-[10px] font-tech text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-500/30">
              LUNAR HARMONIC
            </span>
          </div>

          <p className="text-xs font-chakra text-slate-300 leading-relaxed">
            The radius of the Moon is <strong>1,080 miles</strong>. Digital high-definition video standards (1080p) mirror this exact cosmic constant prior to silicon chip development.
          </p>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 font-tech text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Lunar Radius:</span>
              <input
                type="number"
                value={lunarMiles}
                onChange={(e) => setLunarMiles(Number(e.target.value) || 1080)}
                className="w-24 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-sky-300 text-right font-bold"
              />
              <span className="text-slate-400">miles</span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-slate-400">16:9 Render Geometry:</span>
              <span className="text-sky-300 font-bold text-sm">
                {resolutionX} × {resolutionY}p (FHD)
              </span>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-slate-400">720p Sub-harmonic:</span>
              <span className="text-emerald-400 font-bold">
                {Math.round(resolutionY * (2 / 3))}p (2/3 Scale)
              </span>
            </div>
          </div>
        </div>

        {/* Module 2: 432Hz Solfeggio River-Plasma Wave Dynamics */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400" />
              <h3 className="font-orbitron text-sm font-bold text-slate-200 uppercase">
                432Hz Harmonic Solfeggio Wave
              </h3>
            </div>
            <span className="text-[10px] font-tech text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-500/30">
              ACOUSTIC FREQ
            </span>
          </div>

          <p className="text-xs font-chakra text-slate-300 leading-relaxed">
            432Hz tuning connects natural mathematical wave dynamics to river-plasma oscillations, bypassing dirty 440Hz legacy noise.
          </p>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 font-tech text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Master Frequency:</span>
              <input
                type="number"
                value={solfeggioFreq}
                onChange={(e) => setSolfeggioFreq(Number(e.target.value) || 432)}
                className="w-24 bg-slate-950 border border-slate-700 rounded px-2 py-1 text-amber-300 text-right font-bold"
              />
              <span className="text-slate-400">Hz</span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <span className="text-slate-400">Sub-Octave (216Hz):</span>
              <span className="text-amber-300 font-bold">{harmonicOctave} Hz</span>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-slate-400">Harmonic Delta vs 440Hz:</span>
              <span className="text-emerald-400 font-bold">-8 Hz (Clean Wave)</span>
            </div>
          </div>
        </div>

        {/* Module 3: 24-Hour Legacy Grid Efficiency vs Sovereign Fluid Motion */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-rose-400" />
              <h3 className="font-orbitron text-sm font-bold text-slate-200 uppercase">
                24-Hr Legacy Grid Clock Deconstruction
              </h3>
            </div>
            <span className="text-[10px] font-tech text-rose-400 bg-rose-950 px-2 py-0.5 rounded border border-rose-500/30">
              35% EFFICIENCY
            </span>
          </div>

          <p className="text-xs font-chakra text-slate-300 leading-relaxed">
            The legacy 24-hour clock leaks energy like a rusted corrugated iron tank in a southerly storm—running at only 35% efficiency. Cyber Dragon bypasses legacy grid clock lag.
          </p>

          <div className="space-y-2 font-tech text-xs">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Legacy Grid Clock Efficiency:</span>
                <span className="text-rose-400 font-bold">35%</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '35%' }}></div>
              </div>
            </div>

            <div className="pt-2">
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Cyber Dragon Sovereign Mesh Clock:</span>
                <span className="text-emerald-400 font-bold">100% (Zero Friction)</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                <div className="bg-emerald-400 h-full rounded-full glow-emerald" style={{ width: '100%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Module 4: Primal Binary Pulse 'I and O' Simulator */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Binary className="w-5 h-5 text-purple-400" />
              <h3 className="font-orbitron text-sm font-bold text-slate-200 uppercase">
                Primal Binary Pulse 'I and O'
              </h3>
            </div>
            <span className="text-[10px] font-tech text-purple-400 bg-purple-950 px-2 py-0.5 rounded border border-purple-500/30">
              ZERO-TRUST PULSE
            </span>
          </div>

          <p className="text-xs font-chakra text-slate-300 leading-relaxed">
            Toggle the binary bits below to test Cyber Dragon's zero-friction input 'I' and output 'O' state engine.
          </p>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-1 sm:gap-2">
              {binaryBits.map((bit, idx) => (
                <button
                  key={idx}
                  onClick={() => toggleBit(idx)}
                  className={`w-8 h-10 rounded-lg border font-orbitron font-bold text-sm transition-all cursor-pointer ${
                    bit === 'I'
                      ? 'bg-emerald-500/30 border-emerald-400 text-emerald-300 glow-emerald'
                      : 'bg-purple-950/40 border-purple-800 text-purple-400'
                  }`}
                >
                  {bit}
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between font-tech text-xs text-slate-300">
              <span>Balanced Binary Stream:</span>
              <span className="text-emerald-400 font-bold">
                {binaryBits.join('')} ({binaryBits.filter(b => b === 'I').length} Inputs, {binaryBits.filter(b => b === 'O').length} Outputs)
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
