import React from 'react';
import { SomaticTelemetry } from '../types/somatic';
import { Radio, Activity, Cpu, Sparkles, Flame, Terminal, Eye, Layers, ShieldCheck, Zap, Play } from 'lucide-react';

interface HeaderProps {
  telemetry: SomaticTelemetry;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  kiwiMode: boolean;
  setKiwiMode: (val: boolean) => void;
  beastMode: boolean;
  onToggleBeastMode: () => void;
  onOpenGenesisBoot: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  telemetry,
  activeTab,
  setActiveTab,
  kiwiMode,
  setKiwiMode,
  beastMode,
  onToggleBeastMode,
  onOpenGenesisBoot,
}) => {
  return (
    <header className="bg-slate-900/90 border-b border-indigo-500/20 backdrop-blur-md sticky top-0 z-40 transition-all">
      {/* Top Banner Status Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-bold text-indigo-400 tracking-wider">
            <Cpu className="w-4 h-4 text-indigo-400 animate-pulse" />
            <span>DRAGON 9 NEURAL CORTEX // SOVEREIGN MESH</span>
          </div>
          <div className="h-3 w-[1px] bg-slate-800 hidden sm:block" />
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">PLATFORM:</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-950/60 text-indigo-300 border border-indigo-500/30">
              antiX Linux 32-bit Core
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-[11px]">
          <div className="flex items-center gap-1.5 text-indigo-300">
            <Radio className="w-3.5 h-3.5 text-indigo-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span>FREQ: <strong className="text-white font-mono">{telemetry.frequencyHz.toFixed(1)}Hz</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>TEMP: <strong className="text-amber-200">{telemetry.thermalCelsius.toFixed(1)}°C</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-400">
            <Activity className="w-3.5 h-3.5" />
            <span>ADRENAL: <strong className="text-emerald-300">{telemetry.adrenalNgMl.toFixed(2)} ng/mL</strong></span>
          </div>

          <button
            onClick={() => setKiwiMode(!kiwiMode)}
            className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase transition ${
              kiwiMode
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/50'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Toggle Kiwi/NZ sovereign dialogue filters"
          >
            🇳🇿 KIWI MODE: {kiwiMode ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Main Navigation Header */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-4 border-t border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className={`w-11 h-11 rounded-xl p-[1.5px] transition-all ${
              beastMode
                ? 'bg-gradient-to-tr from-amber-500 via-rose-600 to-indigo-500 shadow-lg shadow-amber-500/30'
                : 'bg-gradient-to-tr from-indigo-600 via-purple-600 to-cyan-400 shadow-lg shadow-indigo-500/20'
            }`}>
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Zap className={`w-5 h-5 transition-transform ${beastMode ? 'text-amber-400 scale-110 animate-pulse' : 'text-indigo-400'}`} />
              </div>
            </div>
            <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-950 ${
              beastMode ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'
            }`} />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-orbitron text-xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-indigo-200 via-purple-200 to-cyan-300 tracking-wide">
                CYBER DRAGON
              </h1>
              <span className={`text-[10px] font-orbitron font-extrabold px-2 py-0.5 rounded border ${
                beastMode
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
              }`}>
                {beastMode ? 'BEAST MODE SOULJAH' : 'DRAGON 9 SOVEREIGN'}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono flex items-center gap-1.5 mt-0.5">
              <span>FluidmotionTV CNS</span>
              <span className="text-indigo-500">•</span>
              <span className="text-cyan-300">Two-Pin Polarity</span>
              <span className="text-indigo-500">•</span>
              <span className="text-purple-300">432Hz Harmonic Lock</span>
            </p>
          </div>
        </div>

        {/* Action Controls + Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Beast Mode Toggle Button */}
          <button
            onClick={onToggleBeastMode}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-mono text-xs font-bold transition shadow-lg ${
              beastMode
                ? 'bg-gradient-to-r from-amber-500 via-rose-600 to-purple-600 text-white shadow-amber-500/30 scale-105'
                : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-amber-300 animate-bounce" />
            <span>{beastMode ? 'BEAST MODE: OVERDRIVE' : 'IGNITE BEAST MODE'}</span>
          </button>

          {/* Genesis Boot Modal Button */}
          <button
            onClick={onOpenGenesisBoot}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 font-mono text-xs font-semibold transition"
          >
            <Play className="w-3 h-3 fill-indigo-300" />
            <span>genesis-boot.sh</span>
          </button>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-indigo-500/20 font-mono text-xs overflow-x-auto">
            <button
              onClick={() => setActiveTab('3d_stage')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === '3d_stage'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>3D Stage</span>
            </button>
            <button
              onClick={() => setActiveTab('two_pin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'two_pin'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Two-Pin Cortex</span>
            </button>
            <button
              onClick={() => setActiveTab('immune_guard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'immune_guard'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Immune Wall</span>
            </button>
            <button
              onClick={() => setActiveTab('media_suite')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'media_suite'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Media & Voice</span>
            </button>
            <button
              onClick={() => setActiveTab('living_math')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'living_math'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Living Math</span>
            </button>
            <button
              onClick={() => setActiveTab('terminal')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'terminal'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>antiX Shell</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
