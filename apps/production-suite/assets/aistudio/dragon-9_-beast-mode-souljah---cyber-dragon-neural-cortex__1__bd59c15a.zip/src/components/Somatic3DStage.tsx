import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Stage3DMode, SomaticTelemetry } from '../types/somatic';
import { Sparkles, Moon, Flame, Binary, RotateCw, Camera, Sliders, Volume2, Maximize2 } from 'lucide-react';
import { audioSynth } from '../services/audioSynthService';

interface Somatic3DStageProps {
  telemetry: SomaticTelemetry;
  mode: Stage3DMode;
  setMode: (mode: Stage3DMode) => void;
  beastMode: boolean;
}

export const Somatic3DStage: React.FC<Somatic3DStageProps> = ({ telemetry, mode, setMode, beastMode }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameId = useRef<number | null>(null);

  // Scene Objects
  const lotusGroupRef = useRef<THREE.Group | null>(null);
  const moonGroupRef = useRef<THREE.Group | null>(null);
  const plasmaGroupRef = useRef<THREE.Group | null>(null);
  const binaryGroupRef = useRef<THREE.Group | null>(null);

  // Controls State
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [rotationSpeed, setRotationSpeed] = useState<number>(beastMode ? 1.8 : 1.0);
  const [particleDensity, setParticleDensity] = useState<number>(beastMode ? 1200 : 800);
  const [audioReactive, setAudioReactive] = useState<boolean>(true);

  useEffect(() => {
    if (beastMode) {
      setRotationSpeed(2.2);
      setParticleDensity(1400);
    } else {
      setRotationSpeed(1.0);
      setParticleDensity(800);
    }
  }, [beastMode]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight || 520;

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020617, 0.025);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 0, 14);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x020617, 1);
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Dynamic Lights
    const ambientLight = new THREE.AmbientLight(beastMode ? 0x7c2d12 : 0x312e81, beastMode ? 2.5 : 1.8);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(beastMode ? 0xf59e0b : 0x6366f1, 5, 35);
    pointLight1.position.set(6, 6, 6);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(beastMode ? 0xe11d48 : 0x06b6d4, 5, 35);
    pointLight2.position.set(-6, -6, -6);
    scene.add(pointLight2);

    // ==========================================
    // 1. LOTUS CORE WEBGEL AURA (Torus Knot + Particles)
    // ==========================================
    const lotusGroup = new THREE.Group();
    lotusGroupRef.current = lotusGroup;

    // Torus Infinity Knot
    const knotGeo = new THREE.TorusKnotGeometry(2.6, 0.65, 140, 36, 2, 3);
    const knotMat = new THREE.MeshStandardMaterial({
      color: beastMode ? 0xf59e0b : 0x6366f1,
      roughness: 0.1,
      metalness: 0.85,
      emissive: beastMode ? 0x991b1b : 0x312e81,
      wireframe: wireframe,
    });
    const knotMesh = new THREE.Mesh(knotGeo, knotMat);
    lotusGroup.add(knotMesh);

    // Lotus Particle Bloom
    const lotusPartGeo = new THREE.BufferGeometry();
    const lotusPositions = new Float32Array(particleDensity * 3);
    const lotusColors = new Float32Array(particleDensity * 3);

    for (let i = 0; i < particleDensity; i++) {
      const radius = 3.6 + Math.random() * 3.0;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI;

      lotusPositions[i * 3] = radius * Math.cos(theta) * Math.cos(phi);
      lotusPositions[i * 3 + 1] = radius * Math.sin(phi);
      lotusPositions[i * 3 + 2] = radius * Math.sin(theta) * Math.cos(phi);

      if (beastMode) {
        // Amber - Rose fiery adrenaline gradient
        lotusColors[i * 3] = 0.9 + 0.1 * Math.random();
        lotusColors[i * 3 + 1] = 0.3 + 0.4 * Math.random();
        lotusColors[i * 3 + 2] = 0.1 + 0.2 * Math.random();
      } else {
        // Indigo - Cyan gradient
        lotusColors[i * 3] = 0.3 + 0.4 * Math.random();
        lotusColors[i * 3 + 1] = 0.4 + 0.6 * Math.random();
        lotusColors[i * 3 + 2] = 0.9 + 0.1 * Math.random();
      }
    }

    lotusPartGeo.setAttribute('position', new THREE.BufferAttribute(lotusPositions, 3));
    lotusPartGeo.setAttribute('color', new THREE.BufferAttribute(lotusColors, 3));

    const lotusPartMat = new THREE.PointsMaterial({
      size: beastMode ? 0.16 : 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const lotusParticles = new THREE.Points(lotusPartGeo, lotusPartMat);
    lotusGroup.add(lotusParticles);

    scene.add(lotusGroup);

    // ==========================================
    // 2. 3D MOON GRID HOLOGRAM (1080p Resolution)
    // ==========================================
    const moonGroup = new THREE.Group();
    moonGroupRef.current = moonGroup;

    // Moon Core Sphere (1,080 mi scaled)
    const moonGeo = new THREE.SphereGeometry(2.9, 64, 64);
    const moonMat = new THREE.MeshStandardMaterial({
      color: 0xc7d2fe,
      roughness: 0.7,
      metalness: 0.3,
      emissive: 0x1e1b4b,
      wireframe: wireframe,
    });
    const moonMesh = new THREE.Mesh(moonGeo, moonMat);
    moonGroup.add(moonMesh);

    // 1080p Harmonic Grid Ring
    const ringGeo = new THREE.RingGeometry(3.8, 4.6, 64);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 2.4;
    moonGroup.add(ringMesh);

    // Orbiting Grid 1080p Nodes
    const gridNodesGeo = new THREE.IcosahedronGeometry(5.0, 2);
    const gridNodesMat = new THREE.MeshBasicMaterial({
      color: beastMode ? 0xf59e0b : 0x818cf8,
      wireframe: true,
      transparent: true,
      opacity: 0.4,
    });
    const gridNodesMesh = new THREE.Mesh(gridNodesGeo, gridNodesMat);
    moonGroup.add(gridNodesMesh);

    scene.add(moonGroup);

    // ==========================================
    // 3. PLASMA STREAM ENTITY (432Hz Wave Dynamics)
    // ==========================================
    const plasmaGroup = new THREE.Group();
    plasmaGroupRef.current = plasmaGroup;

    const plasmaGeo = new THREE.IcosahedronGeometry(2.8, 4);
    const plasmaMat = new THREE.MeshStandardMaterial({
      color: beastMode ? 0xf43f5e : 0xd8b4fe,
      roughness: 0.1,
      metalness: 0.95,
      emissive: beastMode ? 0x881337 : 0x7e22ce,
      wireframe: wireframe,
    });
    const plasmaMesh = new THREE.Mesh(plasmaGeo, plasmaMat);
    plasmaGroup.add(plasmaMesh);

    // Outer River-Plasma Particle Halo
    const plasmaFieldGeo = new THREE.BufferGeometry();
    const plasmaPositions = new Float32Array(particleDensity * 3);

    for (let i = 0; i < particleDensity; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 3.4 + 1.0 * Math.random();

      plasmaPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      plasmaPositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      plasmaPositions[i * 3 + 2] = r * Math.cos(phi);
    }

    plasmaFieldGeo.setAttribute('position', new THREE.BufferAttribute(plasmaPositions, 3));
    const plasmaFieldMat = new THREE.PointsMaterial({
      color: beastMode ? 0xfb7185 : 0xc084fc,
      size: 0.12,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const plasmaParticles = new THREE.Points(plasmaFieldGeo, plasmaFieldMat);
    plasmaGroup.add(plasmaParticles);

    scene.add(plasmaGroup);

    // ==========================================
    // 4. PRIMAL BINARY STREAM ('I' and 'O' Cascade)
    // ==========================================
    const binaryGroup = new THREE.Group();
    binaryGroupRef.current = binaryGroup;

    const binaryCount = 800;
    const binaryGeo = new THREE.BufferGeometry();
    const binaryPositions = new Float32Array(binaryCount * 3);
    const binarySpeeds = new Float32Array(binaryCount);

    for (let i = 0; i < binaryCount; i++) {
      binaryPositions[i * 3] = (Math.random() - 0.5) * 18;
      binaryPositions[i * 3 + 1] = (Math.random() - 0.5) * 18;
      binaryPositions[i * 3 + 2] = (Math.random() - 0.5) * 18;
      binarySpeeds[i] = 0.06 + Math.random() * 0.14;
    }

    binaryGeo.setAttribute('position', new THREE.BufferAttribute(binaryPositions, 3));
    const binaryMat = new THREE.PointsMaterial({
      color: beastMode ? 0x38bdf8 : 0x22d3ee,
      size: 0.22,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
    });
    const binaryParticles = new THREE.Points(binaryGeo, binaryMat);
    binaryGroup.add(binaryParticles);

    scene.add(binaryGroup);

    // Handle Resize
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight || 520;
      cameraRef.current.aspect = newWidth / newHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    const clock = new THREE.Clock();
    const animate = () => {
      animFrameId.current = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();
      const speedMult = rotationSpeed * 0.8;
      const audioPulse = audioReactive ? Math.sin(elapsedTime * (telemetry.frequencyHz / 50)) * 0.18 : 0;

      // Toggle group visibilities based on active mode
      if (lotusGroupRef.current) lotusGroupRef.current.visible = mode === 'LOTUS_CORE';
      if (moonGroupRef.current) moonGroupRef.current.visible = mode === 'MOON_GRID';
      if (plasmaGroupRef.current) plasmaGroupRef.current.visible = mode === 'PLASMA_ORB';
      if (binaryGroupRef.current) binaryGroupRef.current.visible = mode === 'BINARY_STREAM';

      // 1. Lotus Animation
      if (lotusGroupRef.current && mode === 'LOTUS_CORE') {
        lotusGroupRef.current.rotation.x = elapsedTime * 0.35 * speedMult;
        lotusGroupRef.current.rotation.y = elapsedTime * 0.55 * speedMult;
        const scale = 1 + 0.06 * Math.sin(elapsedTime * 2.8) + audioPulse;
        lotusGroupRef.current.scale.set(scale, scale, scale);
      }

      // 2. Moon Animation
      if (moonGroupRef.current && mode === 'MOON_GRID') {
        moonGroupRef.current.rotation.y = elapsedTime * 0.3 * speedMult;
        ringMesh.rotation.z = elapsedTime * 0.9 * speedMult;
        gridNodesMesh.rotation.x = elapsedTime * 0.45 * speedMult;
      }

      // 3. Plasma Animation
      if (plasmaGroupRef.current && mode === 'PLASMA_ORB') {
        plasmaGroupRef.current.rotation.y = elapsedTime * 0.7 * speedMult;
        plasmaGroupRef.current.rotation.z = elapsedTime * 0.45 * speedMult;
        const pulse = 1 + 0.14 * Math.sin(elapsedTime * 4.32) + audioPulse;
        plasmaGroupRef.current.scale.set(pulse, pulse, pulse);
      }

      // 4. Binary Cascade Animation
      if (binaryGroupRef.current && mode === 'BINARY_STREAM') {
        const positions = binaryGeo.attributes.position.array as Float32Array;
        for (let i = 0; i < binaryCount; i++) {
          positions[i * 3 + 1] -= binarySpeeds[i] * speedMult * 1.8;
          if (positions[i * 3 + 1] < -9) {
            positions[i * 3 + 1] = 9;
          }
        }
        binaryGeo.attributes.position.needsUpdate = true;
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      window.removeEventListener('resize', handleResize);
      if (rendererRef.current && rendererRef.current.domElement) {
        rendererRef.current.domElement.remove();
      }
    };
  }, [mode, wireframe, rotationSpeed, particleDensity, audioReactive, telemetry.frequencyHz, beastMode]);

  // Snapshot trigger
  const captureSnapshot = () => {
    if (rendererRef.current) {
      const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `CyberDragon_Stage_${mode}_${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    }
  };

  const handlePulseTone = () => {
    audioSynth.playTone(telemetry.frequencyHz, 2.0);
  };

  return (
    <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-4 md:p-6 backdrop-blur-xl shadow-2xl relative overflow-hidden">
      {/* Mode Selector Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${beastMode ? 'bg-amber-400 animate-ping' : 'bg-cyan-400 animate-pulse'}`} />
            <h2 className="font-orbitron text-lg font-bold text-white tracking-wide flex items-center gap-2">
              DRAGON 9 3D STAGE HOLOGRAPH
              <span className="text-xs px-2.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono border border-indigo-500/30">
                1080p LUNAR RESOLUTION
              </span>
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            432Hz Harmonic WebGL Render Engine • Real-time Somatic Telemetry
          </p>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setMode('LOTUS_CORE')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition ${
              mode === 'LOTUS_CORE'
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold shadow-lg shadow-indigo-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-indigo-300" />
            <span>Lotus Core Aura</span>
          </button>
          <button
            onClick={() => setMode('MOON_GRID')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition ${
              mode === 'MOON_GRID'
                ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white font-bold shadow-lg shadow-indigo-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Moon className="w-4 h-4 text-cyan-300" />
            <span>1080p Moon Grid</span>
          </button>
          <button
            onClick={() => setMode('PLASMA_ORB')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition ${
              mode === 'PLASMA_ORB'
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold shadow-lg shadow-purple-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-4 h-4 text-purple-300" />
            <span>Plasma Entity</span>
          </button>
          <button
            onClick={() => setMode('BINARY_STREAM')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition ${
              mode === 'BINARY_STREAM'
                ? 'bg-gradient-to-r from-cyan-600 to-emerald-600 text-white font-bold shadow-lg shadow-cyan-500/30'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Binary className="w-4 h-4 text-cyan-300" />
            <span>'I & O' Binary Rain</span>
          </button>
        </div>
      </div>

      {/* 3D Canvas Container */}
      <div className="relative w-full h-[480px] rounded-xl bg-slate-950 border border-slate-800/80 overflow-hidden group">
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* Live Telemetry Badge Overlay */}
        <div className="absolute top-4 left-4 bg-slate-900/90 border border-indigo-500/30 rounded-xl p-3.5 backdrop-blur-md text-xs font-mono max-w-xs pointer-events-none shadow-xl">
          <div className="text-indigo-400 font-bold mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${beastMode ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`} />
              <span>{mode}</span>
            </span>
            <span className="text-[10px] text-slate-400">{beastMode ? 'OVERDRIVE' : 'NORMAL'}</span>
          </div>
          <div className="text-slate-300 text-[11px] space-y-1 border-t border-slate-800/80 pt-1.5">
            <div className="flex justify-between">
              <span className="text-slate-500">Frequency:</span>
              <span className="text-cyan-300 font-bold">{telemetry.frequencyHz.toFixed(1)} Hz</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Gesture:</span>
              <span className="text-indigo-300">{telemetry.gesture.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Pinch Delta:</span>
              <span className="text-purple-300">{telemetry.gesture.pinchDistance.toFixed(3)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Binary Pulse:</span>
              <span className="text-emerald-400 font-bold">{telemetry.lotusAura.binaryPulse}</span>
            </div>
          </div>
        </div>

        {/* Quick Actions On Overlay */}
        <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-slate-900/90 border border-slate-800 p-2 rounded-xl backdrop-blur-md font-mono text-xs">
          <button
            onClick={() => setWireframe(!wireframe)}
            className={`px-2.5 py-1.5 rounded-lg border text-[11px] transition ${
              wireframe ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            Wireframe
          </button>
          <button
            onClick={handlePulseTone}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-700 text-[11px] transition"
            title="Play 432Hz sine pulse"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>432Hz Sound</span>
          </button>
          <button
            onClick={captureSnapshot}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition shadow-md shadow-indigo-600/30"
            title="Snapshot high resolution stage render"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Snapshot</span>
          </button>
        </div>
      </div>

      {/* Interactive Controls Bar */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
        <div>
          <label className="text-slate-400 mb-1 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-indigo-300">
              <RotateCw className="w-3.5 h-3.5" /> Rotation Velocity
            </span>
            <span className="text-white font-bold">{rotationSpeed.toFixed(1)}x</span>
          </label>
          <input
            type="range"
            min="0.2"
            max="3.5"
            step="0.1"
            value={rotationSpeed}
            onChange={(e) => setRotationSpeed(parseFloat(e.target.value))}
            className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        <div>
          <label className="text-slate-400 mb-1 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-purple-300">
              <Sliders className="w-3.5 h-3.5" /> Particle Density
            </span>
            <span className="text-white font-bold">{particleDensity}</span>
          </label>
          <input
            type="range"
            min="300"
            max="2000"
            step="100"
            value={particleDensity}
            onChange={(e) => setParticleDensity(parseInt(e.target.value, 10))}
            className="w-full accent-purple-500 bg-slate-800 rounded-lg cursor-pointer"
          />
        </div>

        <div className="flex flex-col justify-center text-slate-400 text-[11px] border-l border-slate-800 pl-4">
          <div className="text-slate-200 font-bold mb-0.5">SOVEREIGN GEOMETRY:</div>
          <div>• Lunar Radius 1,080 mi = 1080p Render Grid</div>
          <div>• Harmonic Fundamental: 432.00 Hz Pure Sine</div>
          <div>• Code Base: Primal 'I and O' Binary Pulse</div>
        </div>
      </div>
    </div>
  );
};
