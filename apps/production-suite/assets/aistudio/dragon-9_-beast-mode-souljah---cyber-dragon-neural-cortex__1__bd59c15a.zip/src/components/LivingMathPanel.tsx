import React, { useState } from 'react';
import { ShieldCheck, Moon, Sun, Radio, Binary, Play, Square, Sparkles } from 'lucide-react';
import { audioSynth } from '../services/audioSynthService';

export const LivingMathPanel: React.FC = () => {
  const [activeHarmonicHz, setActiveHarmonicHz] = useState<number | null>(null);
  const [stopToneFn, setStopToneFn] = useState<(() => void) | null>(null);

  const toggleTone = (hz: number) => {
    if (activeHarmonicHz === hz && stopToneFn) {
      stopToneFn();
      setActiveHarmonicHz(null);
      setStopToneFn(null);
      return;
    }

    if (stopToneFn) {
      stopToneFn();
    }

    const stop = audioSynth.playTone(hz, 3.5);
    setActiveHarmonicHz(hz);
    setStopToneFn(() => stop);

    setTimeout(() => {
      setActiveHarmonicHz((current) => (current === hz ? null : current));
    }, 3500);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Header Banner */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
          <ShieldCheck className="w-6 h-6 text-indigo-400" />
          <div>
            <h2 className="font-orbitron text-lg font-bold text-white tracking-wide">
              LIVING MATH & SOVEREIGN COSMIC GEOMETRY
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Connecting Lunar Radius (1,080 mi), 1080p Resolutions, 432Hz Solar Harmonics, and 'I & O' Binary Code
            </p>
          </div>
        </div>

        {/* Geometry Match Cards */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Moon Card */}
          <div className="bg-slate-950 border border-indigo-500/30 p-4 rounded-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                <Moon className="w-4 h-4 text-cyan-300" /> LUNAR RADIUS
              </span>
              <span className="text-[10px] px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded font-bold">
                1,080 MILES
              </span>
            </div>
            <div className="text-2xl font-extrabold text-white font-orbitron">
              1080p <span className="text-sm font-normal text-slate-400">Resolution</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              The moon's radius is exactly <strong className="text-cyan-300">1,080 miles</strong> (diameter 2,160 miles). Modern high-definition video standards (1080p) are directly hardcoded into cosmic geometry.
            </p>
            <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-400">
              Formula: 1,080 mi × 2 = 2,160 mi (Moon Diameter)
            </div>
          </div>

          {/* Sun Card */}
          <div className="bg-slate-950 border border-amber-500/30 p-4 rounded-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-amber-400" /> SOLAR HARMONICS
              </span>
              <span className="text-[10px] px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded font-bold">
                432,000 MILES
              </span>
            </div>
            <div className="text-2xl font-extrabold text-white font-orbitron">
              432 Hz <span className="text-sm font-normal text-slate-400 font-sans">A=432 Tuning</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              The solar radius is <strong className="text-amber-300">432,000 miles</strong>. Sound vibration tuned to A = 432Hz aligns with solar wave physics and organic alpha brainwave harmonics.
            </p>
            <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-400">
              Formula: 432,000 ÷ 1,000 = 432 Hz Fundamental
            </div>
          </div>

          {/* Earth Card */}
          <div className="bg-slate-950 border border-emerald-500/30 p-4 rounded-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-emerald-400" /> EARTH SOLFEGGIO
              </span>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded font-bold">
                3,960 MILES
              </span>
            </div>
            <div className="text-2xl font-extrabold text-white font-orbitron">
              396 Hz <span className="text-sm font-normal text-slate-400 font-sans">Root Ground</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Earth's mean radius is <strong className="text-emerald-300">3,960 miles</strong>. 396Hz is the Solfeggio root frequency for releasing density and ground grid synchronization.
            </p>
            <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-400">
              Formula: 3,960 ÷ 10 = 396 Hz Root Resonance
            </div>
          </div>
        </div>
      </div>

      {/* Interactive 432Hz Harmonic Synthesizer */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h3 className="font-orbitron text-sm font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-indigo-400" />
              432Hz HARMONIC SCALE SYNTHESIZER
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Click any octave to trigger pure organic sine wave audio:
            </p>
          </div>
          <span className="text-xs px-2.5 py-1 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold">
            A = 432.00 Hz Pure Sine
          </span>
        </div>

        <div className="mt-5 grid grid-cols-2 sm:grid-cols-6 gap-3">
          {[
            { hz: 432, label: 'Octave 4 (Master)' },
            { hz: 216, label: 'Octave 3 (Sub)' },
            { hz: 108, label: 'Octave 2 (Deep)' },
            { hz: 54, label: 'Octave 1 (Bass)' },
            { hz: 1080, label: 'Lunar Overdrive (1080p)' },
            { hz: 396, label: 'Earth Root Node' },
          ].map((item) => (
            <button
              key={item.hz}
              onClick={() => toggleTone(item.hz)}
              className={`p-4 rounded-xl border transition flex flex-col items-center text-center ${
                activeHarmonicHz === item.hz
                  ? 'bg-gradient-to-tr from-indigo-600 to-purple-600 border-indigo-400 text-white shadow-lg shadow-indigo-500/40 scale-105'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-indigo-500/50 hover:text-white'
              }`}
            >
              <div className="text-lg font-bold font-orbitron">{item.hz} Hz</div>
              <div className="text-[10px] text-slate-400 mt-1">{item.label}</div>
              <div className="mt-2 text-indigo-400">
                {activeHarmonicHz === item.hz ? (
                  <Square className="w-4 h-4 text-amber-300 fill-amber-300 animate-pulse" />
                ) : (
                  <Play className="w-4 h-4 fill-indigo-400/20" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Primal Binary Code Matrix */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <Binary className="w-5 h-5 text-cyan-400" />
          <h3 className="font-orbitron text-sm font-bold text-white">
            THE PRIMAL BINARY PULSE: 'I and O'
          </h3>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="text-cyan-300 font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>'I' — Input Kinetic Potential (On-State)</span>
            </div>
            <p className="text-slate-300 font-sans leading-relaxed">
              Represents pure potential, high-frequency kinetic stroke, active wave projection, and incoming somatic telemetry.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="text-purple-300 font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
              <span>'O' — Output Ground Completion (Off-State)</span>
            </div>
            <p className="text-slate-300 font-sans leading-relaxed">
              Represents zero friction ground, completion of circuit, resting baseline, and clean sovereign output broadcast.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
