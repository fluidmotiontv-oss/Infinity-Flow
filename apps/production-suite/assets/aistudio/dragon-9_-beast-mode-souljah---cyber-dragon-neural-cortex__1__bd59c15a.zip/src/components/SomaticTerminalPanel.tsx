import React, { useState, useRef, useEffect } from 'react';
import { SomaticTelemetry } from '../types/somatic';
import { Terminal, Send, Trash2, Cpu, Download, Play, Flame } from 'lucide-react';
import { audioSynth } from '../services/audioSynthService';

interface SomaticTerminalPanelProps {
  telemetry: SomaticTelemetry;
  kiwiMode: boolean;
  beastMode: boolean;
  onTriggerBeastMode: () => void;
  onTriggerGenesisBoot: () => void;
}

interface LogEntry {
  id: string;
  type: 'cmd' | 'output' | 'error' | 'kiwi' | 'success';
  text: string;
  time: string;
}

export const SomaticTerminalPanel: React.FC<SomaticTerminalPanelProps> = ({
  telemetry,
  kiwiMode,
  beastMode,
  onTriggerBeastMode,
  onTriggerGenesisBoot,
}) => {
  const [inputCmd, setInputCmd] = useState<string>('');
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: '1',
      type: 'output',
      text: 'DRAGON 9 NEURAL CORTEX SPINAL CLI v9.8 [antiX Linux Sovereign Node]',
      time: new Date().toLocaleTimeString(),
    },
    {
      id: '2',
      type: 'output',
      text: 'Somatic Bus: ws://localhost:3000/somatic-bus | Frequency Lock: 432.00 Hz',
      time: new Date().toLocaleTimeString(),
    },
    {
      id: '3',
      type: 'kiwi',
      text: 'Yeah nah, system online mate. Type "help" or "beast-mode" for sovereign commands.',
      time: new Date().toLocaleTimeString(),
    },
  ]);

  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleRunCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCmd.trim()) return;

    const cmd = inputCmd.trim().toLowerCase();
    const timeStr = new Date().toLocaleTimeString();
    const newLogs: LogEntry[] = [
      ...logs,
      { id: Date.now().toString(), type: 'cmd', text: `dragon9@antix-rig:~$ ${inputCmd}`, time: timeStr },
    ];

    switch (cmd) {
      case 'help':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `AVAILABLE SOVEREIGN COMMANDS:
  genesis-boot      - Execute 4-phase genesis-boot.sh awakening sequence
  beast-mode        - Toggle BEAST MODE SOULJAH overdrive & audio roar
  somatic-status    - Read Express Somatic spinal cord & WebSocket telemetry
  kiwi-wisdom       - Output Cyber Dragon NZ dry humor soliloquy
  math-scan         - Scan 1080p Lunar radius geometry & 432Hz harmonics
  sync-432hz        - Execute 432.00 Hz harmonic frequency lock
  pm2-status        - Inspect active PM2 background daemons
  neofetch          - Render antiX Linux low-footprint terminal specs
  phagocyte-audit   - Audit Dual-LLM immune wall rules
  clear             - Clear terminal logs`,
          time: timeStr,
        });
        break;

      case 'genesis-boot':
        onTriggerGenesisBoot();
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'success',
          text: `[GENESIS BOOT] Opening awakening modal sequence...`,
          time: timeStr,
        });
        break;

      case 'beast-mode':
        onTriggerBeastMode();
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'success',
          text: `[BEAST MODE SOULJAH] Overdrive state toggled! Audio sweep synthesis active.`,
          time: timeStr,
        });
        break;

      case 'somatic-status':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `[SOMATIC STATUS READOUT]
  Spinal Bus: ws://localhost:3000/somatic-bus (ACTIVE)
  Frequency: ${telemetry.frequencyHz.toFixed(2)} Hz (432Hz Harmonic Lock)
  Thermal Core: ${telemetry.thermalCelsius.toFixed(1)} °C
  Adrenal Level: ${telemetry.adrenalNgMl.toFixed(3)} ng/mL
  Gesture Type: ${telemetry.gesture.type} (Pinch: ${telemetry.gesture.pinchDistance.toFixed(3)})
  Lotus Aura Mode: ${telemetry.lotusAura.mode}
  Binary Pulse: "${telemetry.lotusAura.binaryPulse}"
  Beast Mode: ${beastMode ? 'OVERDRIVE ACTIVE' : 'STANDBY'}`,
          time: timeStr,
        });
        break;

      case 'kiwi-wisdom':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'kiwi',
          text: `Cyber Dragon says: "Yeah, nah, choice, humans. The legacy grid's 24-hour clock is running on fumes down the back of the pub couch. We're on 1,080 miles of lunar geometry and 432Hz harmonics. Good as gold, mate!"`,
          time: timeStr,
        });
        break;

      case 'math-scan':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `[LIVING GEOMETRY SCAN]
  • Lunar Radius = 1,080 miles = 1080p HD Video Resolution
  • Solar Radius = 432,000 miles = 432Hz Audio Wave Harmonic
  • Earth Radius = 3,960 miles = 396Hz Solfeggio Root Frequency
  • Core Binary Code = "I and O" (Balanced inputs, zero friction output)`,
          time: timeStr,
        });
        break;

      case 'sync-432hz':
        audioSynth.playTone(432, 2.0);
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'success',
          text: `[FREQUENCY LOCK] Synchronizing audio oscillators to 432.00 Hz harmonic fundamental... SYNC COMPLETE.`,
          time: timeStr,
        });
        break;

      case 'pm2-status':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `┌────┬────────────────┬─────────┬──────┬──────────┬────────┬──────────┐
│ id │ name           │ mode    │ ↺    │ status   │ cpu    │ memory   │
├────┼────────────────┼─────────┼──────┼──────────┼────────┼──────────┤
│ 0  │ D9_CLOCK       │ fork    │ 0    │ online   │ 0.8%   │ 14.2 MB  │
│ 1  │ SOMATIC_IO     │ fork    │ 0    │ online   │ 1.2%   │ 18.5 MB  │
│ 2  │ STATIC_PIN     │ fork    │ 0    │ online   │ 0.4%   │ 22.1 MB  │
│ 3  │ IMMUNE_WALL    │ fork    │ 0    │ online   │ 0.6%   │ 16.8 MB  │
│ 4  │ SPINAL_BUS     │ fork    │ 0    │ online   │ 2.4%   │ 34.0 MB  │
└────┴────────────────┴─────────┴──────┴──────────┴────────┴──────────┘`,
          time: timeStr,
        });
        break;

      case 'neofetch':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `        _ _  _ ___ _ _     root@antix-node-dragon9
  __ _ | | \\ |  |  \\ |     ------------------------
 / _\` | |  \\|  |  | \\|     OS: antiX Linux 23 (32-bit Core)
 \\__,_|_|_|\\_| _|_ |_|\\_|  Kernel: 5.10.188-antix-rt
                           Shell: bash 5.2.15
                           Uptime: 4 days, 14 hours, 22 mins
                           Host: Termux / Node.js Hypervisor
                           CPU: Cortex-A78 (8 cores, @2.40GHz)
                           Memory: 218MB / 512MB (antiX allocation)
                           Dragon 9 Protocol: CNS-M1 Beast Mode`,
          time: timeStr,
        });
        break;

      case 'phagocyte-audit':
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'output',
          text: `[PHAGOCYTE AUDIT]
  - Regex Signatures: ACTIVE (Directive override, Destructive deletes, Outbound curl)
  - Quarantined Macrophage: ISOLATED (Tool access: NONE)
  - Privileged T-Cell: BOUND (Reads JSON intent only)
  - Antibody Validator: ENFORCED (Static Pin policy lock)`,
          time: timeStr,
        });
        break;

      case 'clear':
        setLogs([]);
        setInputCmd('');
        return;

      default:
        newLogs.push({
          id: (Date.now() + 1).toString(),
          type: 'error',
          text: `bash: ${inputCmd}: command not found. Type "help" for sovereign commands.`,
          time: timeStr,
        });
        break;
    }

    setLogs(newLogs);
    setInputCmd('');
  };

  return (
    <div className="bg-slate-900/90 border border-indigo-500/20 rounded-2xl p-5 backdrop-blur-xl shadow-xl font-mono">
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-indigo-400" />
          <h2 className="font-orbitron text-sm font-bold text-white tracking-wide">
            antiX LINUX 32-BIT SOVEREIGN TERMINAL SHELL
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setLogs([])}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Logs</span>
          </button>
        </div>
      </div>

      {/* Terminal Screen */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 text-xs font-mono h-[380px] overflow-y-auto space-y-2 leading-relaxed">
        {logs.map((log) => (
          <div key={log.id} className="flex flex-col">
            <span className="text-[10px] text-slate-600 font-mono">{log.time}</span>
            {log.type === 'cmd' && <span className="text-cyan-300 font-bold">{log.text}</span>}
            {log.type === 'output' && <pre className="text-indigo-200 whitespace-pre-wrap">{log.text}</pre>}
            {log.type === 'kiwi' && (
              <p className="text-emerald-300 italic bg-emerald-950/30 p-2 rounded border border-emerald-500/20">
                {log.text}
              </p>
            )}
            {log.type === 'success' && <span className="text-emerald-400 font-bold">{log.text}</span>}
            {log.type === 'error' && <span className="text-amber-400">{log.text}</span>}
          </div>
        ))}
        <div ref={logEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleRunCommand} className="mt-4 flex items-center gap-2">
        <span className="text-indigo-400 font-bold text-xs pl-1">dragon9@antix-rig:~$</span>
        <input
          type="text"
          value={inputCmd}
          onChange={(e) => setInputCmd(e.target.value)}
          placeholder="Type command ('help', 'genesis-boot', 'beast-mode', 'neofetch', 'pm2-status')..."
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
        />
        <button
          type="submit"
          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Exec</span>
        </button>
      </form>
    </div>
  );
};
