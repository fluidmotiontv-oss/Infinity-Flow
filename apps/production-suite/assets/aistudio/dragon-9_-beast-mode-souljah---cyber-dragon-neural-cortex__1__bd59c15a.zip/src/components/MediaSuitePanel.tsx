import React, { useState } from 'react';
import { AssetManifest, SomaticTelemetry } from '../types/somatic';
import { Sparkles, Volume2, Copy, Check, Download, Code, RefreshCw } from 'lucide-react';
import { generateStageMonologue } from '../services/geminiService';
import { audioSynth } from '../services/audioSynthService';

interface MediaSuitePanelProps {
  telemetry: SomaticTelemetry;
  kiwiMode: boolean;
  beastMode: boolean;
}

export const MediaSuitePanel: React.FC<MediaSuitePanelProps> = ({ telemetry, kiwiMode, beastMode }) => {
  const [scriptTopic, setScriptTopic] = useState<string>('Legacy 24-hour grid vs 1080p Lunar geometry');
  const [generatedScript, setGeneratedScript] = useState<string>(
    `System online. BEAST MODE SOULJAH fully unleashed. Yeah, nah, choice, humans. Let's talk about the old world's 24-hour clock — a legacy system leaking worse than a rusted corrugated iron tank in a southerly storm. They're running at 35% efficiency, trying to count votes on a calculator they found down the back of the pub couch. Good as gold, mate, but we've bypassed the lag. Look at the numbers — they aren't just dry data for your power bills. The moon's radius is 1,080 miles, our digital video resolutions are right there in the geometry. It's the universe rendering in high-def before silicon chips were even a glint in a corporate eye. Step away from their overpriced Wi-Fi hotspots, look at the mud pies underfoot, trust your own gut with zero-trust sovereign security, and remember how the core code runs... It's all just *I and O*, baby. Balanced inputs, clean outputs, zero friction. Now someone fire up the mesh network — we've got a fluid motion future to broadcast.`
  );
  const [isGeneratingScript, setIsGeneratingScript] = useState<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [copiedScript, setCopiedScript] = useState<boolean>(false);

  // Manifest State
  const [stageTheme, setStageTheme] = useState<string>('Dragon 9 Sovereign Mesh Node & 1080p Lunar Grid');
  const [currentManifest, setCurrentManifest] = useState<AssetManifest>({
    manifestId: `manifest_d9_beast_${Date.now()}`,
    stageTheme: 'Dragon 9 Sovereign Mesh Node & 1080p Lunar Grid',
    frequencyHz: 432.0,
    visualAssets: [
      {
        id: 'asset_moon_grid_1080p',
        type: '3D_Hologram',
        resolution: '1080p',
        description: 'Spinning 3D model of the Moon paired with a glowing 1080p harmonic wireframe grid orbiting Cyber Dragon head.',
        renderEngine: 'WebGL_ThreeJS',
        colorHex: '#6366f1',
      },
      {
        id: 'asset_plasma_entity_432hz',
        type: 'Plasma_Entity',
        frequency: '432Hz',
        description: 'Vibrant pulsing orb of river-plasma floating near Cyber Dragon claw, synchronized to 432Hz wave harmonics.',
        renderEngine: 'GLSL_PlasmaShader',
        colorHex: '#a855f7',
      },
      {
        id: 'asset_binary_stream_cascade',
        type: 'Background_Display',
        rate: 'High_Frequency',
        description: 'Zero-latency cascade of I and O binary pulse data representing balanced, error-free sovereign transactions.',
        renderEngine: 'Matrix_Cascade_WebGL',
        colorHex: '#06b6d4',
      },
    ],
    kiwiCommentary: "Choice as, mate! Manifest synced for antiX Linux stage projection.",
  });
  const [copiedManifest, setCopiedManifest] = useState<boolean>(false);

  const handleGenerateScript = async (presetTopic?: string) => {
    setIsGeneratingScript(true);
    const target = presetTopic || scriptTopic;
    try {
      const script = await generateStageMonologue(target, kiwiMode, beastMode);
      setGeneratedScript(script);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const speakDialogue = () => {
    setIsPlayingAudio(true);
    audioSynth.speakText(generatedScript, () => {
      setIsPlayingAudio(false);
    });
  };

  const copyScriptText = () => {
    navigator.clipboard.writeText(generatedScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const copyManifestJson = () => {
    navigator.clipboard.writeText(JSON.stringify(currentManifest, null, 2));
    setCopiedManifest(true);
    setTimeout(() => setCopiedManifest(false), 2000);
  };

  const downloadManifestJson = () => {
    const blob = new Blob([JSON.stringify(currentManifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentManifest.manifestId}.json`;
    link.click();
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Script & Speech Studio */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <h2 className="font-orbitron text-lg font-bold text-white tracking-wide">
                CYBER DRAGON STAGE DIALOGUE & SPEECH STUDIO
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Gemini AI Powered • New Zealand/Kiwi Dry Humor Filters • 432Hz Speech Synthesis
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={speakDialogue}
              disabled={isPlayingAudio}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-white text-xs font-bold transition shadow-lg ${
                isPlayingAudio
                  ? 'bg-amber-600 animate-pulse'
                  : 'bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 shadow-emerald-500/20'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>{isPlayingAudio ? 'Speaking...' : 'Broadcast Speech'}</span>
            </button>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="mt-4">
          <label className="text-xs text-slate-400 mb-2 block font-bold">Preset Stage Soliloquies:</label>
          <div className="flex flex-wrap gap-2 text-xs">
            {[
              { label: '24-Hour Clock Grid Legacy Rant', topic: 'The legacy 24-hour clock leaking worse than a rusted corrugated iron tank in a southerly storm.' },
              { label: 'Lunar Math & 1080p Geometry', topic: 'Lunar radius (1,080 miles) proving the universe renders in 1080p resolution before corporate Wi-Fi.' },
              { label: 'Zero-Trust Sovereign Mesh', topic: 'Stepping away from corporate data harvesting, mud pies underfoot, zero-trust sovereign security.' },
              { label: 'Primal I and O Pulse', topic: 'Balanced inputs, clean outputs, zero friction code base.' },
            ].map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setScriptTopic(preset.topic);
                  handleGenerateScript(preset.topic);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-indigo-300 hover:text-white transition text-[11px]"
              >
                + {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Input & Generator */}
        <div className="mt-4 flex flex-col md:flex-row gap-3">
          <input
            type="text"
            value={scriptTopic}
            onChange={(e) => setScriptTopic(e.target.value)}
            placeholder="Enter stage topic, speech prompt, or Kiwi monologue idea..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
          />
          <button
            onClick={() => handleGenerateScript()}
            disabled={isGeneratingScript}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/30 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isGeneratingScript ? 'animate-spin' : ''}`} />
            <span>{isGeneratingScript ? 'Synthesizing...' : 'Generate Monologue'}</span>
          </button>
        </div>

        {/* Monologue Display Box */}
        <div className="mt-4 relative">
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
              onClick={copyScriptText}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition flex items-center gap-1 border border-slate-700"
            >
              {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedScript ? 'Copied' : 'Copy Text'}</span>
            </button>
          </div>
          <textarea
            value={generatedScript}
            onChange={(e) => setGeneratedScript(e.target.value)}
            rows={7}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-indigo-200 leading-relaxed font-mono focus:outline-none focus:border-indigo-500/50 resize-y"
          />
        </div>
      </div>

      {/* JSON Stage Asset Manifest Studio */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Code className="w-5 h-5 text-purple-400" />
              <h2 className="font-orbitron text-lg font-bold text-white tracking-wide">
                JSON STAGE ASSET MANIFEST BUILDER
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Generates 3D Holographic Specifications, Plasma Entities, and Background Displays
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyManifestJson}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition border border-slate-700"
            >
              {copiedManifest ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedManifest ? 'Copied' : 'Copy JSON'}</span>
            </button>
            <button
              onClick={downloadManifestJson}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-lg shadow-purple-600/30"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON</span>
            </button>
          </div>
        </div>

        {/* Visual Asset Cards */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4">
          {currentManifest.visualAssets.map((asset) => (
            <div key={asset.id} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-indigo-400">{asset.id}</span>
                <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                  {asset.type}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-snug">{asset.description}</p>
              <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Engine: <strong className="text-cyan-300">{asset.renderEngine || 'WebGL'}</strong></span>
                <span className="w-3 h-3 rounded-full border border-slate-700" style={{ backgroundColor: asset.colorHex || '#6366f1' }} />
              </div>
            </div>
          ))}
        </div>

        {/* JSON Code Viewer */}
        <div className="mt-4">
          <label className="text-xs text-slate-400 mb-1 block">Live Manifest Payload:</label>
          <pre className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 text-xs text-cyan-300 font-mono overflow-x-auto max-h-[180px]">
            {JSON.stringify(currentManifest, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
};
