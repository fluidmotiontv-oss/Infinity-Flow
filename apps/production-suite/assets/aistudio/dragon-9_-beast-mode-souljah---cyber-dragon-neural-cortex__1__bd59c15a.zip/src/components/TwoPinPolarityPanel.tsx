import React, { useState } from 'react';
import {
  SovereignDirective,
  AgentProfile,
  FoundationalParams,
  MemoryLog,
  SomaticTelemetry
} from '../types/somatic';
import {
  Database,
  Brain,
  Zap,
  Send,
  Plus,
  Trash2,
  RefreshCw,
  CheckCircle2,
  ChevronRight,
  Shield,
  Activity,
  Tv,
  Waves,
  Clock,
  Network,
  Terminal,
  Compass,
  Cpu,
  Lock,
  Unlock,
  HardDrive
} from 'lucide-react';
import { executeDynamicCortex } from '../services/geminiService';
import { audioSynth } from '../services/audioSynthService';

interface TwoPinPolarityPanelProps {
  directives: SovereignDirective[];
  setDirectives: React.Dispatch<React.SetStateAction<SovereignDirective[]>>;
  agents: AgentProfile[];
  setAgents: React.Dispatch<React.SetStateAction<AgentProfile[]>>;
  params: FoundationalParams;
  memories: MemoryLog[];
  setMemories: React.Dispatch<React.SetStateAction<MemoryLog[]>>;
  telemetry: SomaticTelemetry;
  beastMode: boolean;
}

export const TwoPinPolarityPanel: React.FC<TwoPinPolarityPanelProps> = ({
  directives,
  setDirectives,
  agents,
  setAgents,
  params,
  memories,
  setMemories,
  telemetry,
  beastMode,
}) => {
  const [sourceInput, setSourceInput] = useState<string>('pee dub Telemetry');
  const [textInput, setTextInput] = useState<string>(
    'Swell: 13.5ft @ 16s WNW. Offshore Wind: ENE 12kts. Tide: Low Incoming. Class-5 wave energy profile.'
  );
  const [selectedAgent, setSelectedAgent] = useState<AgentProfile>(agents[0] || null);
  const [cortexLoading, setCortexLoading] = useState<boolean>(false);
  const [latestReaction, setLatestReaction] = useState<{
    cortexOutput: string;
    agentsDispatched: string[];
    driftCalculated: number;
    cognitiveLoads: Record<string, number>;
    simulated: boolean;
  } | null>(null);

  // New Directive Modal/Form
  const [isAddingDir, setIsAddingDir] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newDesc, setNewDesc] = useState<string>('');
  const [newCategory, setNewCategory] = useState<'Operational' | 'Security' | 'Identity' | 'Data Integrity'>('Operational');

  // Spinal Bus Step Tracker
  const [busSteps, setBusSteps] = useState<{ phase: string; msg: string; status: 'idle' | 'pending' | 'success' }[]>([
    { phase: '1. INGEST', msg: 'Spinal Bus listening for sensory ingress & telemetry...', status: 'idle' },
    { phase: '2. ANCHOR', msg: 'Anchor unyielding truth from Static Pin (Hippocampus)...', status: 'idle' },
    { phase: '3. SYNTHESIZE', msg: 'Synthetix combines sovereign invariants with dynamic signal...', status: 'idle' },
    { phase: '4. REACT', msg: 'Dynamic Pin (Cerebral Cortex) executes high compute...', status: 'idle' },
    { phase: '5. ETCH & ROUTE', msg: 'Cryptographic memory etch written back to Static Pin...', status: 'idle' }
  ]);

  const handleFireCortex = async () => {
    if (!textInput.trim()) return;
    setCortexLoading(true);

    audioSynth.playTone(432, 1.2);

    // Animate bus steps
    setBusSteps([
      { phase: '1. INGEST', msg: `Ingested signal from [${sourceInput}]: "${textInput.slice(0, 32)}..."`, status: 'success' },
      { phase: '2. ANCHOR', msg: `Anchoring ${directives.length} sovereign directives & 9 agent profiles...`, status: 'pending' },
      { phase: '3. SYNTHESIZE', msg: 'Building zero-leak prompt packet...', status: 'idle' },
      { phase: '4. REACT', msg: 'Firing neural impulse to Dynamic Pin...', status: 'idle' },
      { phase: '5. ETCH & ROUTE', msg: 'Awaiting cryptographic memory write...', status: 'idle' }
    ]);

    await new Promise(r => setTimeout(r, 600));

    setBusSteps(prev => [
      prev[0],
      { ...prev[1], status: 'success' },
      { phase: '3. SYNTHESIZE', msg: 'Synthetix mapped context into strict JSON contract.', status: 'pending' },
      prev[3],
      prev[4]
    ]);

    await new Promise(r => setTimeout(r, 500));

    setBusSteps(prev => [
      prev[0],
      prev[1],
      { ...prev[2], status: 'success' },
      { phase: '4. REACT', msg: 'Cortex computing fluid vectors & dispatch paths (gemini-3.8-flash)...', status: 'pending' },
      prev[4]
    ]);

    try {
      const result = await executeDynamicCortex(
        sourceInput,
        textInput,
        directives,
        agents,
        params,
        memories.slice(-3),
        beastMode
      );

      setLatestReaction(result);

      // Update agent loads
      setAgents(prev =>
        prev.map(agent => {
          if (result.cognitiveLoads[agent.name] !== undefined) {
            return {
              ...agent,
              cognitiveLoad: result.cognitiveLoads[agent.name],
              status: 'Active'
            };
          }
          return {
            ...agent,
            cognitiveLoad: Math.max(5, Math.floor(agent.cognitiveLoad * 0.85))
          };
        })
      );

      // Create new permanent memory log
      const newMemory: MemoryLog = {
        timestamp: new Date().toISOString(),
        source: sourceInput,
        input: textInput,
        cortexOutput: result.cortexOutput,
        agentsDispatched: result.agentsDispatched,
        driftCalculated: result.driftCalculated,
        beastModeEtched: beastMode
      };

      setMemories(prev => [...prev, newMemory]);

      setBusSteps(prev => [
        prev[0],
        prev[1],
        prev[2],
        { phase: '4. REACT', msg: `Cortex computed drift ${result.driftCalculated.toFixed(3)}. Dispatched: [${result.agentsDispatched.join(', ')}]`, status: 'success' },
        { phase: '5. ETCH & ROUTE', msg: 'Memory log etched to Static Pin. Polarity state synchronized.', status: 'success' }
      ]);
    } catch (e: any) {
      console.error('Cortex error:', e);
      setBusSteps(prev => prev.map(s => s.status === 'pending' ? { ...s, status: 'idle', msg: 'Error: ' + e.message } : s));
    } finally {
      setCortexLoading(false);
    }
  };

  const handleAddDirective = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const newDir: SovereignDirective = {
      id: `DIR-00${directives.length + 1}`,
      title: newTitle,
      description: newDesc,
      category: newCategory,
      immutable: false
    };

    setDirectives(prev => [...prev, newDir]);
    setNewTitle('');
    setNewDesc('');
    setIsAddingDir(false);
  };

  const handleDeleteDirective = (id: string) => {
    setDirectives(prev => prev.filter(d => d.id !== id));
  };

  const getAgentIcon = (icon: string) => {
    switch (icon) {
      case 'ShieldAlert': return <Shield className="w-4 h-4 text-emerald-400" />;
      case 'Tv': return <Tv className="w-4 h-4 text-cyan-400" />;
      case 'Waves': return <Waves className="w-4 h-4 text-blue-400" />;
      case 'Activity': return <Activity className="w-4 h-4 text-pink-400" />;
      case 'Clock': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'Network': return <Network className="w-4 h-4 text-purple-400" />;
      case 'Terminal': return <Terminal className="w-4 h-4 text-green-400" />;
      case 'Compass': return <Compass className="w-4 h-4 text-indigo-400" />;
      case 'Cpu': return <Cpu className="w-4 h-4 text-rose-400" />;
      default: return <Cpu className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* 1. ARCHITECTURE SCHEMATIC HEADER */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-indigo-400" />
              <h2 className="font-orbitron text-lg font-bold text-white tracking-wide">
                TWO-PIN POLARITY MASTER ORCHESTRATOR
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Static Pin (Hippocampus Vector DB) ⇄ Spinal Bus (14ms) ⇄ Dynamic Pin (Cerebral Cortex Reactor)
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs px-3 py-1.5 rounded-xl bg-indigo-500/10 text-indigo-300 border border-indigo-500/30">
              Clock: {params.baseFrequency}
            </span>
          </div>
        </div>

        {/* Polarity Oscillation Schematic */}
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-11 items-center gap-4 bg-slate-950 p-5 rounded-xl border border-slate-800">
          {/* Static Pin */}
          <div className="lg:col-span-4 bg-slate-900/90 border border-blue-500/30 p-4 rounded-xl text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-blue-950/60 border border-blue-500/40 flex items-center justify-center mb-2">
              <Database className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xs font-bold text-blue-300 uppercase">THE STATIC PIN (HIPPOCAMPUS)</h3>
            <p className="text-[11px] text-slate-400 font-sans mt-1 leading-normal">
              Sovereign truth anchor. Persistent Directives, Agent Profiles, and Cryptographic Memory Logs.
            </p>
            <div className="mt-2 text-[10px] text-blue-400 font-bold bg-blue-950/60 px-2.5 py-0.5 rounded border border-blue-900">
              {directives.length} DIRECTIVES • {memories.length} MEMORIES
            </div>
          </div>

          {/* Spinal Bus */}
          <div className="lg:col-span-3 flex flex-col items-center justify-center py-2 text-center">
            <div className="w-full relative flex items-center justify-center my-2">
              <div className="w-full h-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-amber-500 opacity-40" />
              <div
                className={`absolute w-3 h-3 rounded-full bg-cyan-400 shadow-md shadow-cyan-400/50 ${
                  cortexLoading ? 'animate-bounce' : 'animate-pulse'
                }`}
              />
            </div>
            <span className="text-[11px] text-indigo-300 font-bold">SPINAL BUS ROUTING</span>
            <span className="text-[9px] text-slate-500 font-sans">14ms latency • Zero-trust packet transfer</span>
          </div>

          {/* Dynamic Pin */}
          <div className="lg:col-span-4 bg-slate-900/90 border border-purple-500/30 p-4 rounded-xl text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-purple-950/60 border border-purple-500/40 flex items-center justify-center mb-2">
              <Brain className={`w-6 h-6 text-purple-400 ${cortexLoading ? 'animate-spin' : ''}`} />
            </div>
            <h3 className="text-xs font-bold text-purple-300 uppercase">THE DYNAMIC PIN (CEREBRAL CORTEX)</h3>
            <p className="text-[11px] text-slate-400 font-sans mt-1 leading-normal">
              Active reasoning reactor. Powered by Gemini 3.8 Flash. Zero permanent state. Pure compute.
            </p>
            <div className="mt-2 text-[10px] text-purple-400 font-bold bg-purple-950/60 px-2.5 py-0.5 rounded border border-purple-900">
              {beastMode ? 'BEAST MODE OVERDRIVE' : 'CORTEX READY'}
            </div>
          </div>
        </div>
      </div>

      {/* 2. SPINAL INGRESS & CORTEX DISPATCH CONTROL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ingress Input & Step Tracker (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 backdrop-blur-xl shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                SPINAL SIGNAL INGRESS & TELEMETRY INJECTOR
              </h3>
            </div>

            {/* Presets */}
            <div className="flex flex-wrap gap-2 mb-3">
              {[
                { label: 'pee dub Surf Swell', source: 'pee dub Telemetry', text: 'Swell: 13.5ft @ 16s WNW. Offshore Wind: ENE 12kts. Tide: Low Incoming. High energy class rating.' },
                { label: 'Soma Hardware Check', source: 'Soma Sentinel', text: 'antiX 32-bit container health: CPU 32%, Synapse Temp: 41.8C, Mem: 184MB. 432Hz loop synced.' },
                { label: 'Aegis Security Audit', source: 'Aegis Sentry', text: 'Audit of sovereign directives and boundary guardrails. Cognitive drift check initiated.' },
                { label: 'Kinesis Gesture Capture', source: 'Kinesis Kinematics', text: 'Biomechanical wrist landmark stroke. Lotus open gesture identified. Wavelet index 1.45.' }
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSourceInput(p.source);
                    setTextInput(p.text);
                  }}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] transition ${
                    sourceInput === p.source
                      ? 'bg-indigo-600 border-indigo-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Ingress Source:</span>
                <input
                  type="text"
                  value={sourceInput}
                  onChange={(e) => setSourceInput(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-cyan-300 flex-1 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <textarea
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                rows={3}
                placeholder="Enter telemetry stream or command packet..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 font-mono focus:outline-none focus:border-indigo-500 resize-none"
              />

              <div className="flex justify-between items-center">
                <span className="text-[10px] text-slate-500">
                  Packet Size: {textInput.length} bytes • 14ms spinal bus pipe
                </span>

                <button
                  onClick={handleFireCortex}
                  disabled={cortexLoading || !textInput.trim()}
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/30 disabled:opacity-50"
                >
                  {cortexLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Computing Impulse...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Fire Dynamic Cortex</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Bus Step Pipeline Tracker */}
          <div className="mt-4 pt-3 border-t border-slate-800/80">
            <span className="text-[10px] text-slate-500 uppercase font-bold block mb-2">Spinal Bus Packet Flow:</span>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-[10px]">
              {busSteps.map((step, idx) => (
                <div
                  key={idx}
                  className={`p-2 rounded-lg border flex flex-col justify-between ${
                    step.status === 'success'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : step.status === 'pending'
                      ? 'bg-indigo-950/50 border-indigo-400 text-indigo-200 animate-pulse'
                      : 'bg-slate-950 border-slate-800 text-slate-500'
                  }`}
                >
                  <div className="font-bold flex items-center justify-between">
                    <span>{step.phase}</span>
                    {step.status === 'success' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                  </div>
                  <p className="text-[9px] font-sans mt-1 text-slate-300 line-clamp-2">{step.msg}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Dynamic Pin Live Output & Agent Allocation (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 backdrop-blur-xl shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Brain className="w-4 h-4 text-purple-400" />
                CEREBRAL CORTEX ACTIVE REASONING
              </h3>
              {latestReaction && (
                <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                  latestReaction.simulated ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                }`}>
                  {latestReaction.simulated ? 'DETERMINISTIC REACTOR' : 'GEMINI 3.8 FLASH'}
                </span>
              )}
            </div>

            {latestReaction ? (
              <div className="space-y-3">
                <div className="bg-slate-950 border border-purple-500/30 p-3.5 rounded-xl text-xs text-purple-200 leading-relaxed font-sans max-h-[160px] overflow-y-auto">
                  {latestReaction.cortexOutput}
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Drift Calculation:</span>
                    <span className={`text-lg font-bold font-orbitron ${
                      latestReaction.driftCalculated > 0.1 ? 'text-red-400' : 'text-emerald-400'
                    }`}>
                      {(latestReaction.driftCalculated * 100).toFixed(1)}%
                    </span>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-400 h-full rounded-full transition-all"
                        style={{ width: `${Math.min(100, (latestReaction.driftCalculated / 0.15) * 100)}%` }}
                      />
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block">Dispatched Nodes:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {latestReaction.agentsDispatched.map((name, i) => (
                        <span key={i} className="px-2 py-0.5 bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded text-[10px] font-bold">
                          {name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-950/60 border border-dashed border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs">
                <Brain className="w-8 h-8 mx-auto mb-2 text-slate-700 animate-pulse" />
                <span>Dynamic Cortex is standing by. Ingest a telemetry packet on the left to fire live reasoning.</span>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Cryptographic State:</span>
            <span className="text-emerald-400 font-bold">Permanent Etch Synchronized</span>
          </div>
        </div>
      </div>

      {/* 3. CORE NINE AGENTS DIRECTORY & STATIC PIN DIRECTIVES */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Core Nine Agents (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Network className="w-4 h-4 text-indigo-400" />
              THE CORE NINE AGENTS REGISTRY
            </h3>
            <span className="text-xs text-slate-400">9/9 Nodes Active</span>
          </div>

          <div className="grid grid-cols-3 gap-2.5 mb-4">
            {agents.map((agent) => (
              <button
                key={agent.id}
                onClick={() => setSelectedAgent(agent)}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between transition ${
                  selectedAgent?.id === agent.id
                    ? 'bg-gradient-to-tr from-indigo-950 to-purple-950 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                    {getAgentIcon(agent.icon)}
                  </div>
                  <span className={`w-2 h-2 rounded-full ${agent.cognitiveLoad > 20 ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
                </div>
                <div className="mt-2">
                  <div className="font-bold text-xs text-slate-200">{agent.name}</div>
                  <div className="text-[10px] text-slate-400 flex items-center justify-between mt-0.5">
                    <span>Load:</span>
                    <strong className={agent.cognitiveLoad > 20 ? 'text-amber-300' : 'text-indigo-300'}>
                      {agent.cognitiveLoad}%
                    </strong>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Selected Agent Inspector */}
          {selectedAgent && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
                  {getAgentIcon(selectedAgent.icon)}
                </div>
                <div>
                  <h4 className="font-bold text-indigo-300">{selectedAgent.name} Agent</h4>
                  <p className="text-[10px] text-slate-400 font-sans">{selectedAgent.role}</p>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Assigned Responsibilities:</span>
                <ul className="space-y-1 text-slate-300 font-sans text-[11px]">
                  {selectedAgent.responsibilities.map((r, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <ChevronRight className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Static Pin Directives Registry (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 backdrop-blur-xl shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-400" />
                SOVEREIGN DIRECTIVES (STATIC PIN)
              </h3>
              <button
                onClick={() => setIsAddingDir(!isAddingDir)}
                className="text-[11px] px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1 transition"
              >
                <Plus className="w-3 h-3" />
                <span>Add Rule</span>
              </button>
            </div>

            {/* In-App Directives Form */}
            {isAddingDir && (
              <form onSubmit={handleAddDirective} className="bg-slate-950 p-3 rounded-xl border border-indigo-500/40 mb-3 space-y-2 text-xs">
                <input
                  type="text"
                  placeholder="Directive Title..."
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
                  required
                />
                <textarea
                  placeholder="Unyielding policy constraint description..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 resize-none"
                  required
                />
                <div className="flex justify-between items-center">
                  <select
                    value={newCategory}
                    onChange={(e: any) => setNewCategory(e.target.value)}
                    className="bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-300"
                  >
                    <option value="Operational">Operational</option>
                    <option value="Security">Security</option>
                    <option value="Identity">Identity</option>
                    <option value="Data Integrity">Data Integrity</option>
                  </select>
                  <button
                    type="submit"
                    className="px-3 py-1 rounded-lg bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-500"
                  >
                    Etch to Pin
                  </button>
                </div>
              </form>
            )}

            {/* Directives List */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {directives.map((dir) => (
                <div key={dir.id} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-cyan-400 font-bold">{dir.id}</span>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[9px] px-2 py-0.5 rounded font-bold ${
                        dir.immutable ? 'bg-blue-500/20 text-blue-300' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {dir.immutable ? 'IMMUTABLE' : 'MUTABLE'}
                      </span>
                      {!dir.immutable && (
                        <button
                          onClick={() => handleDeleteDirective(dir.id)}
                          className="text-slate-500 hover:text-red-400 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">{dir.title}</h4>
                  <p className="text-[11px] text-slate-400 font-sans leading-normal">{dir.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between">
            <span>Integrity Check:</span>
            <span className="text-emerald-400 font-bold">100% Verified by Aegis</span>
          </div>
        </div>
      </div>

      {/* 4. PERMANENT MEMORY LOGS */}
      <div className="bg-slate-900/80 border border-indigo-500/20 rounded-2xl p-5 md:p-6 backdrop-blur-xl shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-indigo-400" />
            <h3 className="font-orbitron text-sm font-bold text-white tracking-wide">
              CRYPTOGRAPHIC MEMORY LOGS (ETCHED TO HIPPOCAMPUS)
            </h3>
          </div>
          <span className="text-xs text-slate-400">{memories.length} Etched Memories</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-1">
          {[...memories].reverse().map((mem, idx) => (
            <div key={idx} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-cyan-300">[{mem.source}]</span>
                <span className="text-[10px] text-slate-500">{new Date(mem.timestamp).toLocaleTimeString()}</span>
              </div>
              <p className="text-slate-300 font-sans italic text-[11px]">"{mem.input}"</p>
              <div className="pt-1.5 border-t border-slate-900 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Dispatched: <strong className="text-indigo-300">{mem.agentsDispatched.join(', ')}</strong></span>
                <span className="text-emerald-400 font-bold">Drift: {(mem.driftCalculated * 100).toFixed(1)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
