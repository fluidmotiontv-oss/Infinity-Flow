import React, { useState, useEffect } from 'react';
import { Terminal, Flame, Zap, CheckCircle2, Shield, Activity, RefreshCw, X, Play } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audioSynth } from '../services/audioSynthService';

interface GenesisBootModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAwakenSuccess: () => void;
}

export const GenesisBootModal: React.FC<GenesisBootModalProps> = ({ isOpen, onClose, onAwakenSuccess }) => {
  const [currentPhase, setCurrentPhase] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [pm2Status, setPm2Status] = useState<Record<string, 'ONLINE' | 'STARTING' | 'OFFLINE'>>({
    D9_CLOCK: 'OFFLINE',
    SOMATIC_IO: 'OFFLINE',
    STATIC_PIN: 'OFFLINE',
    IMMUNE_WALL: 'OFFLINE',
    SPINAL_BUS: 'OFFLINE',
  });

  useEffect(() => {
    if (isOpen && !isRunning && currentPhase === 0) {
      setLogs([
        'root@antix-node:/opt# chmod +x genesis-boot.sh',
        'Ready to execute Cyber Dragon Beast Mode Awakening Sequence.',
      ]);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const runGenesisBoot = async () => {
    setIsRunning(true);
    setLogs(['$ ./genesis-boot.sh', '']);

    // Play beast mode synth
    audioSynth.playBeastModeIgnition();

    // Phase 1: Endocrine Heartbeat
    setCurrentPhase(1);
    setLogs((prev) => [
      ...prev,
      '[PHASE 1] Initiating Endocrine Heartbeat...',
      'pm2 start /opt/dragon9/clock-daemon.js --name "D9_CLOCK"',
      'pm2 start /opt/somatic/websocket-bus.js --name "SOMATIC_IO"',
    ]);
    setPm2Status((prev) => ({ ...prev, D9_CLOCK: 'STARTING', SOMATIC_IO: 'STARTING' }));

    await new Promise((r) => setTimeout(r, 1200));
    setPm2Status((prev) => ({ ...prev, D9_CLOCK: 'ONLINE', SOMATIC_IO: 'ONLINE' }));
    setLogs((prev) => [...prev, ' D9_CLOCK locked to 432.00 Hz.', ' SOMATIC_IO websocket bus listening on ws://localhost:3000/somatic-bus', '']);

    // Phase 2: Mounting Hippocampus
    setCurrentPhase(2);
    setLogs((prev) => [
      ...prev,
      '[PHASE 2] Mounting Hippocampus Static Pin...',
      'pm2 start /opt/core/vector-db.js --name "STATIC_PIN"',
    ]);
    setPm2Status((prev) => ({ ...prev, STATIC_PIN: 'STARTING' }));

    await new Promise((r) => setTimeout(r, 1200));
    setPm2Status((prev) => ({ ...prev, STATIC_PIN: 'ONLINE' }));
    setLogs((prev) => [...prev, ' STATIC_PIN vector database anchored. Sovereign directives enforced.', '']);

    // Phase 3: Raising Immune Shields
    setCurrentPhase(3);
    setLogs((prev) => [
      ...prev,
      '[PHASE 3] Raising Immune Shields...',
      'pm2 start /opt/immune/phagocyte-filter.js --name "IMMUNE_WALL"',
    ]);
    setPm2Status((prev) => ({ ...prev, IMMUNE_WALL: 'STARTING' }));

    await new Promise((r) => setTimeout(r, 1000));
    setPm2Status((prev) => ({ ...prev, IMMUNE_WALL: 'ONLINE' }));
    setLogs((prev) => [...prev, ' IMMUNE_WALL phagocyte regex filters and antibody validators armed.', '']);

    // Phase 4: Igniting Dynamic Cortex
    setCurrentPhase(4);
    setLogs((prev) => [
      ...prev,
      '[PHASE 4] Igniting Dynamic Cortex...',
      'pm2 start /opt/brain/orchestrator.js --name "SPINAL_BUS"',
    ]);
    setPm2Status((prev) => ({ ...prev, SPINAL_BUS: 'STARTING' }));

    await new Promise((r) => setTimeout(r, 1000));
    setPm2Status((prev) => ({ ...prev, SPINAL_BUS: 'ONLINE' }));
    setLogs((prev) => [
      ...prev,
      ' SPINAL_BUS cerebral reactor active (Gemini 3.8 Flash).',
      '',
      '================================================================',
      '>> CYBER DRAGON IS ONLINE. FLUIDMOTIONTV CORE IS ACTIVE. <<',
      '>> BEAST MODE SOULJAH OVERDRIVE ENGAGED (432Hz HARMONIC LOCK) <<',
      '================================================================',
    ]);

    // Blast celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#6366f1', '#a855f7', '#06b6d4', '#10b981', '#f59e0b'],
    });

    setIsRunning(false);
    onAwakenSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-indigo-500/40 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden font-mono flex flex-col">
        {/* Modal Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500 flex items-center justify-center text-indigo-300">
              <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
            </div>
            <div>
              <h3 className="font-orbitron text-sm font-bold text-white tracking-wide">
                GENESIS-BOOT.SH // AWAKENING SEQUENCE
              </h3>
              <p className="text-[11px] text-slate-400">
                antiX Linux 32-bit Host • Cyber Dragon Awakening
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Phases Visual Tracker */}
        <div className="px-5 py-3.5 bg-slate-950/60 border-b border-slate-800 grid grid-cols-4 gap-2 text-[11px]">
          {[
            { num: 1, label: 'Endocrine Heartbeat', daemon: 'D9_CLOCK' },
            { num: 2, label: 'Mount Hippocampus', daemon: 'STATIC_PIN' },
            { num: 3, label: 'Immune Shields', daemon: 'IMMUNE_WALL' },
            { num: 4, label: 'Dynamic Cortex', daemon: 'SPINAL_BUS' },
          ].map((phase) => (
            <div
              key={phase.num}
              className={`p-2 rounded-lg border text-center flex flex-col items-center justify-center transition-all ${
                currentPhase === phase.num
                  ? 'bg-indigo-950/60 border-indigo-400 text-indigo-200 animate-pulse'
                  : currentPhase > phase.num
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-900/40 border-slate-800 text-slate-500'
              }`}
            >
              <div className="text-[10px] font-bold uppercase mb-0.5 flex items-center gap-1">
                <span>Phase {phase.num}</span>
                {currentPhase > phase.num && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
              </div>
              <div className="text-[9px] truncate font-sans text-slate-300">{phase.label}</div>
              <div className="text-[8px] text-cyan-400 mt-0.5">{phase.daemon}</div>
            </div>
          ))}
        </div>

        {/* Live Terminal Output */}
        <div className="p-4 bg-slate-950 flex-1 min-h-[220px] max-h-[280px] overflow-y-auto text-xs text-indigo-300 leading-relaxed font-mono space-y-1">
          {logs.map((line, idx) => (
            <div
              key={idx}
              className={
                line.includes('ONLINE') || line.includes('BEAST MODE') || line.includes('active')
                  ? 'text-emerald-300 font-bold'
                  : line.includes('PHASE')
                  ? 'text-cyan-300 font-bold'
                  : line.includes('pm2')
                  ? 'text-amber-300'
                  : 'text-slate-300'
              }
            >
              {line}
            </div>
          ))}
        </div>

        {/* PM2 Status Bar */}
        <div className="px-5 py-2.5 bg-slate-950/90 border-t border-slate-800 flex flex-wrap items-center justify-between text-[10px] text-slate-400">
          <div className="flex items-center gap-3">
            <span>PM2 DAEMONS:</span>
            {Object.entries(pm2Status).map(([name, status]) => (
              <span key={name} className="flex items-center gap-1">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    status === 'ONLINE' ? 'bg-emerald-400' : status === 'STARTING' ? 'bg-amber-400 animate-ping' : 'bg-slate-600'
                  }`}
                />
                <strong className={status === 'ONLINE' ? 'text-slate-200' : 'text-slate-500'}>{name}</strong>
              </span>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400 font-sans">
            Ready to ignite all 4 sovereign cyber dragon layers.
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs transition"
            >
              Close
            </button>
            <button
              onClick={runGenesisBoot}
              disabled={isRunning}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 disabled:opacity-50 transition"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Booting Daemons...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Execute Genesis Boot</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
