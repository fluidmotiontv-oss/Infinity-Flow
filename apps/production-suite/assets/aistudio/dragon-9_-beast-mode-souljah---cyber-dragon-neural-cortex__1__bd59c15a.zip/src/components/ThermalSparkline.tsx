import React from 'react';

interface ThermalSparklineProps {
  data: number[];
  width?: number;
  height?: number;
  lineColor?: string;
  fillColor?: string;
  unit?: string;
}

export const ThermalSparkline: React.FC<ThermalSparklineProps> = ({
  data,
  width = 130,
  height = 28,
  lineColor = '#f59e0b',
  unit = '°C',
}) => {
  if (!data || data.length === 0) {
    return (
      <div className="text-[10px] text-slate-500 font-mono animate-pulse">
        Sampling thermal current...
      </div>
    );
  }

  const points = data.length === 1 ? [data[0], data[0]] : data;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min === 0 ? 1 : max - min;

  const padTop = 3;
  const padBottom = 3;
  const usableHeight = height - padTop - padBottom;
  const stepX = width / (points.length - 1 || 1);

  const coords = points.map((val, idx) => {
    const x = idx * stepX;
    const normalizedY = (val - min) / range;
    const y = height - padBottom - normalizedY * usableHeight;
    return { x, y };
  });

  const linePath = coords.reduce((acc, pt, i) => {
    return i === 0 ? `M ${pt.x.toFixed(1)},${pt.y.toFixed(1)}` : `${acc} L ${pt.x.toFixed(1)},${pt.y.toFixed(1)}`;
  }, '');

  const areaPath = `${linePath} L ${width.toFixed(1)},${height} L 0,${height} Z`;
  const latestPoint = coords[coords.length - 1];
  const latestValue = points[points.length - 1];

  return (
    <div className="flex items-center gap-2">
      <div className="relative inline-block" style={{ width, height }}>
        <svg width={width} height={height} className="overflow-visible">
          <defs>
            <linearGradient id={`thermalGrad-${lineColor.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={lineColor} stopOpacity={0.4} />
              <stop offset="100%" stopColor={lineColor} stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <path d={areaPath} fill={`url(#thermalGrad-${lineColor.replace('#', '')})`} />
          <path
            d={linePath}
            fill="none"
            stroke={lineColor}
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {latestPoint && (
            <g>
              <circle
                cx={latestPoint.x}
                cy={latestPoint.y}
                r="3.5"
                fill={lineColor}
                className="animate-ping opacity-75"
              />
              <circle
                cx={latestPoint.x}
                cy={latestPoint.y}
                r="2"
                fill="#ffffff"
                stroke={lineColor}
                strokeWidth="1"
              />
            </g>
          )}
        </svg>
      </div>
      <div className="text-[10px] font-mono leading-tight text-slate-400 border-l border-slate-800 pl-2">
        <div className="text-amber-300 font-bold">{latestValue.toFixed(1)}{unit}</div>
        <div className="text-[8px] text-slate-500 uppercase">trend</div>
      </div>
    </div>
  );
};
