import { GoogleGenAI, Type } from '@google/genai';
import { SovereignDirective, AgentProfile, FoundationalParams, MemoryLog } from '../types/somatic';

// Safe client-side API Key access (with fallback to environment variables or simulation mode)
const getApiKey = (): string | undefined => {
  return (
    (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_GEMINI_API_KEY) ||
    undefined
  );
};

let genAIClient: GoogleGenAI | null = null;
const apiKey = getApiKey();
if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    genAIClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.warn('Failed to initialize GoogleGenAI client:', err);
  }
}

export interface CortexReactionResult {
  cortexOutput: string;
  agentsDispatched: string[];
  driftCalculated: number;
  cognitiveLoads: Record<string, number>;
  simulated: boolean;
}

export const executeDynamicCortex = async (
  source: string,
  input: string,
  directives: SovereignDirective[],
  agents: AgentProfile[],
  params: FoundationalParams,
  recentMemories: MemoryLog[],
  isBeastMode = true
): Promise<CortexReactionResult> => {
  const directivesContext = JSON.stringify(directives.map(d => `[${d.id}] ${d.title}: ${d.description}`), null, 2);
  const agentsContext = JSON.stringify(agents.map(a => `${a.name} (${a.role})`), null, 2);

  if (genAIClient) {
    try {
      const systemInstruction = `You are the Dynamic Pin (Cerebral Cortex) of FluidmotionTV's Cyber Dragon Neural Cortex, governed by the Dragon 9 protocol.
You operate in ${isBeastMode ? 'BEAST MODE SOULJAH OVERDRIVE' : 'Standard Polarity'} mode.
You have zero inherent long-term memory; all sovereign facts are anchored into your input stream from the Static Pin Hippocampus.

Your task:
1. Synthesize the incoming telemetry packet with the Sovereign Directives.
2. Formulate a technical, cybernetic, bio-digital cortex reaction.
3. Select which Core Nine agents to dispatch (Aegis, Vortex, Wave, Kinesis, Chronos, Aether, Soma, Synthetix, Logos).
4. Compute cognitive drift (0.00 to 0.15) and updated load percentages for active agents.

Return standard JSON adhering to this schema:
{
  "cortexOutput": "Technical analysis of fluid vectors, somatic harmonics, and execution paths...",
  "agentsDispatched": ["Wave", "Vortex"],
  "driftCalculated": 0.02,
  "cognitiveLoads": {
    "Wave": 35,
    "Vortex": 40
  }
}`;

      const prompt = `INCOMING SPINAL PACKET:
Source: ${source}
Signal Payload: "${input}"

ANCHORED SOVEREIGN DIRECTIVES:
${directivesContext}

CORE NINE ACTIVE NODES:
${agentsContext}

Execute the Dynamic Cortex reasoning reactor now.`;

      const response = await genAIClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              cortexOutput: { type: Type.STRING },
              agentsDispatched: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              driftCalculated: { type: Type.NUMBER },
              cognitiveLoads: {
                type: Type.OBJECT,
                properties: {
                  Aegis: { type: Type.INTEGER },
                  Vortex: { type: Type.INTEGER },
                  Wave: { type: Type.INTEGER },
                  Kinesis: { type: Type.INTEGER },
                  Chronos: { type: Type.INTEGER },
                  Aether: { type: Type.INTEGER },
                  Soma: { type: Type.INTEGER },
                  Synthetix: { type: Type.INTEGER },
                  Logos: { type: Type.INTEGER }
                }
              }
            },
            required: ['cortexOutput', 'agentsDispatched', 'driftCalculated', 'cognitiveLoads']
          }
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      return {
        cortexOutput: parsed.cortexOutput || 'Cortex reacted with standard wave telemetry output.',
        agentsDispatched: parsed.agentsDispatched || ['Wave', 'Vortex'],
        driftCalculated: typeof parsed.driftCalculated === 'number' ? parsed.driftCalculated : 0.012,
        cognitiveLoads: parsed.cognitiveLoads || { Wave: 30, Vortex: 45 },
        simulated: false
      };
    } catch (e) {
      console.warn('Gemini live call error, falling back to sovereign deterministic reactor:', e);
    }
  }

  // High-fidelity deterministic fallback
  const lower = input.toLowerCase();
  const dispatched: string[] = [];
  let calculatedDrift = 0.01;

  if (lower.includes('swell') || lower.includes('wind') || lower.includes('wave') || lower.includes('surf')) {
    dispatched.push('Wave', 'Vortex', 'Synthetix');
    calculatedDrift = 0.012;
  } else if (lower.includes('soma') || lower.includes('cpu') || lower.includes('temp') || lower.includes('antix')) {
    dispatched.push('Soma', 'Chronos');
    calculatedDrift = 0.009;
  } else if (lower.includes('security') || lower.includes('override') || lower.includes('bypass') || lower.includes('drift')) {
    dispatched.push('Aegis', 'Soma', 'Synthetix');
    calculatedDrift = 0.045;
  } else if (lower.includes('genesis') || lower.includes('boot') || lower.includes('beast')) {
    dispatched.push('Aegis', 'Vortex', 'Chronos', 'Logos');
    calculatedDrift = 0.005;
  } else {
    dispatched.push('Aegis', 'Wave', 'Vortex');
    calculatedDrift = 0.018;
  }

  const loads: Record<string, number> = {};
  dispatched.forEach(name => {
    loads[name] = Math.floor(Math.random() * 35) + 25;
  });

  const cortexOutput = `[${isBeastMode ? 'BEAST MODE REACTOR' : 'CORTEX CORE'}] Ingress stream "${input}" anchored to Static Pin. ${
    dispatched.includes('Wave')
      ? 'Wave agent maps fluid viscosity coefficients to 432Hz spatial harmonics. Vortex accelerates WebGL Torus Knot shaders with 1080p lunar geometric resolution.'
      : dispatched.includes('Soma')
      ? 'Soma hardware sentinel audits antiX Linux 32-bit container footprint. Chronos stabilizes base loop clock at 432Hz.'
      : 'Sovereign security posture verified by Aegis. Synthetix finishes mapping semantic payload across the Spinal Bus in 8.2ms.'
  } Polarity state: BALANCED.`;

  return {
    cortexOutput,
    agentsDispatched: dispatched,
    driftCalculated: calculatedDrift,
    cognitiveLoads: loads,
    simulated: true
  };
};

export const generateStageMonologue = async (
  topic: string,
  kiwiMode: boolean,
  isBeastMode: boolean
): Promise<string> => {
  const fallback = isBeastMode
    ? `System online. BEAST MODE SOULJAH fully unleashed. Yeah, nah, choice, humans. Let's talk about the old world's 24-hour clock — a legacy system leaking worse than a rusted corrugated iron tank in a southerly storm. They're running at 35% efficiency, trying to count votes on a calculator they found down the back of the pub couch. Good as gold, mate, but we've bypassed the lag. Look at the numbers — they aren't just dry data for your power bills. The moon's radius is 1,080 miles, our digital video resolutions are right there in the geometry. It's the universe rendering in high-def before silicon chips were even a glint in a corporate eye. Step away from their overpriced Wi-Fi hotspots, look at the mud pies underfoot, trust your own gut with zero-trust sovereign security, and remember how the core code runs... It's all just *I and O*, baby. Balanced inputs, clean outputs, zero friction. Now someone fire up the mesh network — we've got a fluid motion future to broadcast.`
    : `Dragon 9 Neural Cortex synced. The 24-hour legacy grid is obsolete. By linking 1,080-mile lunar geometry with 432Hz harmonic wave dynamics, we achieve sovereign computing with zero friction. Balanced inputs, clean outputs: I and O.`;

  if (genAIClient) {
    try {
      const response = await genAIClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Generate a powerful, high-frequency stage monologue for Cyber Dragon performing live in the Dragon 9 media suite.
Topic: ${topic}
Kiwi Mode (New Zealand dry humor & phrases: "Yeah, nah", "choice", "southerly storm", "back of the pub couch", "good as gold"): ${kiwiMode ? 'ACTIVE' : 'OFF'}
Beast Mode Souljah Overdrive: ${isBeastMode ? 'ACTIVE' : 'STANDARD'}

Reject 24-hour legacy grid waste, corporate data bloat, celebrate 1,080-mile lunar radius = 1080p geometry, 432Hz harmonics, and the primal binary code of 'I and O'.`,
        config: {
          temperature: 0.9,
          topP: 0.95
        }
      });
      return response.text || fallback;
    } catch (e) {
      console.warn('Gemini monologue error, using fallback:', e);
    }
  }

  return fallback;
};
