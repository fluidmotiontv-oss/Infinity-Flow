class AudioSynthService {
  private ctx: AudioContext | null = null;
  private activeOscillator: OscillatorNode | null = null;
  private activeGain: GainNode | null = null;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Play a clean harmonic tone with organic envelope
   */
  public playTone(freqHz: number, durationSec = 2.5, type: OscillatorType = 'sine'): () => void {
    try {
      const ctx = this.getContext();
      this.stopTone();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freqHz, ctx.currentTime);

      // Smooth attack and exponential decay
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + durationSec);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + durationSec);

      this.activeOscillator = osc;
      this.activeGain = gain;

      return () => {
        this.stopTone();
      };
    } catch (e) {
      console.warn('Audio playback error:', e);
      return () => {};
    }
  }

  public stopTone(): void {
    if (this.activeOscillator) {
      try {
        this.activeOscillator.stop();
        this.activeOscillator.disconnect();
      } catch {
        // ignore already stopped
      }
      this.activeOscillator = null;
    }
  }

  /**
   * Cyber Dragon Beast Mode ignition synth surge
   */
  public playBeastModeIgnition(): void {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;

      // 1. Sub-bass sweep (54Hz -> 432Hz -> 1080Hz)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';

      osc.frequency.setValueAtTime(54, now);
      osc.frequency.exponentialRampToValueAtTime(432, now + 0.4);
      osc.frequency.exponentialRampToValueAtTime(1080, now + 0.8);
      osc.frequency.exponentialRampToValueAtTime(432, now + 1.4);

      // Filter
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(200, now);
      filter.frequency.exponentialRampToValueAtTime(3200, now + 0.6);
      filter.frequency.exponentialRampToValueAtTime(432, now + 1.4);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.25, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 1.8);

      // 2. Chime harmonic burst at 432Hz
      const chime = ctx.createOscillator();
      const chimeGain = ctx.createGain();
      chime.type = 'sine';
      chime.frequency.setValueAtTime(432 * 2, now + 0.2);

      chimeGain.gain.setValueAtTime(0.001, now + 0.2);
      chimeGain.gain.exponentialRampToValueAtTime(0.12, now + 0.3);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);

      chime.connect(chimeGain);
      chimeGain.connect(ctx.destination);

      chime.start(now + 0.2);
      chime.stop(now + 1.5);
    } catch (e) {
      console.warn('Beast mode audio error:', e);
    }
  }

  /**
   * Speak monologue text with Cyber Dragon Kiwi tone
   */
  public speakText(text: string, onEnd?: () => void): void {
    if (!('speechSynthesis' in window)) {
      onEnd?.();
      return;
    }
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.pitch = 0.88; // Deep dragon cybernetic resonance
    utterance.rate = 1.04;

    const voices = window.speechSynthesis.getVoices();
    // Prefer English NZ / AU / GB voice
    const preferredVoice = voices.find(
      (v) => v.lang.includes('en-NZ') || v.lang.includes('en-AU') || v.lang.includes('en-GB') || v.name.includes('Daniel')
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onend = () => onEnd?.();
    utterance.onerror = () => onEnd?.();

    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking(): void {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}

export const audioSynth = new AudioSynthService();
