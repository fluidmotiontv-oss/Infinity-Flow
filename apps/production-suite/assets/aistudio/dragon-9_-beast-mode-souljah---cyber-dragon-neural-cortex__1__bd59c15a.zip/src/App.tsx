import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Somatic3DStage } from './components/Somatic3DStage';
import { TwoPinPolarityPanel } from './components/TwoPinPolarityPanel';
import { ImmuneGuardrailsPanel } from './components/ImmuneGuardrailsPanel';
import { MediaSuitePanel } from './components/MediaSuitePanel';
import { LivingMathPanel } from './components/LivingMathPanel';
import { SomaticTerminalPanel } from './components/SomaticTerminalPanel';
import { GenesisBootModal } from './components/GenesisBootModal';
import { ThermalSparkline } from './components/ThermalSparkline';
import { SomaticTelemetry, Stage3DMode, SovereignDirective, AgentProfile, MemoryLog } from './types/somatic';
import { INITIAL_DIRECTIVES, INITIAL_AGENTS, INITIAL_PARAMS, INITIAL_MEMORIES } from './data/hippocampus';
import { audioSynth } from './services/audioSynthService';
import confetti from 'canvas-confetti';
import { Sparkles, Radio, Flame, Zap, Shield, Brain, Layers, Activity } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('3d_stage');
  const [stageMode, setStageMode] = useState<Stage3DMode>('LOTUS_CORE');
  const [kiwiMode, setKiwiMode] = useState<boolean>(true);
  const [beastMode, setBeastMode] = useState<boolean>(true);
  const [isGenesisModalOpen, setIsGenesisModalOpen] = useState<boolean>(false);

  // Sovereign Two-Pin State
  const [directives, setDirectives] = useState<SovereignDirective[]>(INITIAL_DIRECTIVES);
  const [agents, setAgents] = useState<AgentProfile[]>(INITIAL_AGENTS);
  const [memories, setMemories] = useState<MemoryLog[]>(INITIAL_MEMORIES);

  // 60-Second Thermal History Buffer
  const [thermalHistory, setThermalHistory] = useState<number[]>(() => {
    const initial = [];
    for (let i = 0; i < 60; i++) {
      const val = 36.8 + 0.25 * Math.sin(i * 0.18) + 0.06 * (Math.random() - 0.5);
      initial.push(parseFloat(val.toFixed(2)));
    }
    return initial;
  });

  // Somatic Live Telemetry State
  const [telemetry, setTelemetry] = useState<SomaticTelemetry>({
    source: 'EXPRESS_SOMATIC_SPINAL_CORD',
    timestamp: Date.now() / 1000,
    status: 'BEAST_MODE_ACTIVE',
    frequencyHz: 432.0,
    harmonicLock: true,
    adrenalNgMl: 0.14,
    thermalCelsius: 37.1,
    gesture: {
      type: 'LOTUS_BLOOM',
      wristX: 0.5,
      wristY: 0.5,
      pinchDistance: 0.082,
      confidence: 0.98,
    },
    pyAudio: {
      peakFrequencyHz: 432.0,
      amplitudeDb: -10.2,
      harmonicRatio: 0.999,
    },
    lotusAura: {
      mode: 'BIOLUMINESCENT_INDIGO_BLOOM',
      infinityLoopSpeed: 1.4,
      binaryPulse: 'I',
    },
    beastModeActive: true,
    cpuLoad: 24,
    synapseTempC: 41.5,
  });

  // Telemetry real-time loop
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now() / 1000;
      const baseFreq = 432.0 + (beastMode ? 0.4 * Math.sin(now * 4.32) : 0.15 * Math.sin(now * 2.16));
      const thermal = (beastMode ? 37.2 : 36.8) + 0.18 * Math.sin(now * 0.5) + (Math.random() - 0.5) * 0.05;
      const adrenal = (beastMode ? 0.18 : 0.12) + 0.02 * Math.cos(now * 0.7);
      const binaryState = Math.sin(now * 8.64) > 0 ? 'I' : 'O';

      setTelemetry((prev) => ({
        ...prev,
        timestamp: now,
        frequencyHz: parseFloat(baseFreq.toFixed(2)),
        thermalCelsius: parseFloat(thermal.toFixed(2)),
        adrenalNgMl: parseFloat(adrenal.toFixed(3)),
        cpuLoad: beastMode ? 42 + Math.floor(Math.random() * 8) : 22 + Math.floor(Math.random() * 5),
        synapseTempC: parseFloat((41.0 + (beastMode ? 1.8 : 0.6) * Math.sin(now * 0.4)).toFixed(1)),
        lotusAura: {
          ...prev.lotusAura,
          binaryPulse: binaryState,
        },
      }));

      // Update thermal sparkline history
      setThermalHistory((prev) => [...prev.slice(1), parseFloat(thermal.toFixed(2))]);
    }, 1000);

    return () => clearInterval(interval);
  }, [beastMode]);

  const handleToggleBeastMode = () => {
    const nextState = !beastMode;
    setBeastMode(nextState);

    if (nextState) {
      audioSynth.playBeastModeIgnition();
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#f59e0b', '#f43f5e', '#6366f1'],
      });
    } else {
      audioSynth.playTone(216, 0.8);
    }
  };

  const handleAwakenFromGenesis = () => {
    setBeastMode(true);
    setIsGenesisModalOpen(false);
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white pb-12 transition-colors ${
      beastMode ? 'bg-[#030712]' : 'bg-[#020617]'
    }`}>
      {/* Top Banner Header */}
      <Header
        telemetry={telemetry}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        kiwiMode={kiwiMode}
        setKiwiMode={setKiwiMode}
        beastMode={beastMode}
        onToggleBeastMode={handleToggleBeastMode}
        onOpenGenesisBoot={() => setIsGenesisModalOpen(true)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 mt-6">
        {/* Tab 1: 3D Holographic Stage */}
        {activeTab === '3d_stage' && (
          <div className="space-y-6">
            <Somatic3DStage
              telemetry={telemetry}
              mode={stageMode}
              setMode={setStageMode}
              beastMode={beastMode}
            />

            {/* Quick Status Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
              <div className="bg-slate-900/70 border border-indigo-500/20 p-4 rounded-xl flex items-center gap-3">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <div>
                  <div className="text-slate-400 text-[11px]">LOTUS CORE SKIN AURA</div>
                  <div className="text-white font-bold text-sm">
                    {beastMode ? 'Fiery Indigo Overdrive' : 'Bioluminescent Indigo Bloom'}
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/70 border border-indigo-500/20 p-4 rounded-xl flex items-center gap-3">
                <Radio className="w-5 h-5 text-cyan-400" />
                <div>
                  <div className="text-slate-400 text-[11px]">SPINAL BUS HARMONIC LOCK</div>
                  <div className="text-white font-bold text-sm">
                    432.00 Hz (Pure Solar Harmonic)
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/70 border border-indigo-500/20 p-4 rounded-xl flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <Flame className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <div className="text-slate-400 text-[11px] font-semibold">ENDOCRINE & THERMAL</div>
                    <div className="text-white font-bold text-sm">
                      {telemetry.thermalCelsius.toFixed(1)}°C <span className="text-slate-400 text-xs font-normal">• {telemetry.adrenalNgMl.toFixed(2)} ng/mL</span>
                    </div>
                  </div>
                </div>
                {/* Real-time 60s Sparkline Chart */}
                <ThermalSparkline data={thermalHistory} width={120} height={28} />
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Two-Pin Polarity Cortex */}
        {activeTab === 'two_pin' && (
          <TwoPinPolarityPanel
            directives={directives}
            setDirectives={setDirectives}
            agents={agents}
            setAgents={setAgents}
            params={INITIAL_PARAMS}
            memories={memories}
            setMemories={setMemories}
            telemetry={telemetry}
            beastMode={beastMode}
          />
        )}

        {/* Tab 3: Dual-LLM Sovereign Immune Wall */}
        {activeTab === 'immune_guard' && (
          <ImmuneGuardrailsPanel
            telemetry={telemetry}
            beastMode={beastMode}
          />
        )}

        {/* Tab 4: Cyber Dragon Media & Speech Studio */}
        {activeTab === 'media_suite' && (
          <MediaSuitePanel
            telemetry={telemetry}
            kiwiMode={kiwiMode}
            beastMode={beastMode}
          />
        )}

        {/* Tab 5: Living Math & Cosmic Geometry Explorer */}
        {activeTab === 'living_math' && (
          <LivingMathPanel />
        )}

        {/* Tab 6: antiX Linux Terminal Shell */}
        {activeTab === 'terminal' && (
          <SomaticTerminalPanel
            telemetry={telemetry}
            kiwiMode={kiwiMode}
            beastMode={beastMode}
            onTriggerBeastMode={handleToggleBeastMode}
            onTriggerGenesisBoot={() => setIsGenesisModalOpen(true)}
          />
        )}
      </main>

      {/* Genesis Boot Modal */}
      <GenesisBootModal
        isOpen={isGenesisModalOpen}
        onClose={() => setIsGenesisModalOpen(false)}
        onAwakenSuccess={handleAwakenFromGenesis}
      />

      {/* Global Footer */}
      <footer className="max-w-7xl mx-auto px-4 mt-12 pt-6 border-t border-slate-900 text-center font-mono text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div>
          CYBER DRAGON // DRAGON 9 BEAST MODE SOULJAH MEDIA SUITE
        </div>
        <div>
          FluidmotionTV CNS • antiX Linux Spinal Cord • 432Hz Harmonic Lock • "I and O" Binary
        </div>
      </footer>
    </div>
  );
}
