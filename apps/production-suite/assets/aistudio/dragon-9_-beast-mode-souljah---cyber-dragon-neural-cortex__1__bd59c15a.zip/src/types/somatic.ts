export interface GestureTelemetry {
  type: string;
  wristX: number;
  wristY: number;
  pinchDistance: number;
  confidence: number;
}

export interface PyAudioTelemetry {
  peakFrequencyHz: number;
  amplitudeDb: number;
  harmonicRatio: number;
}

export interface LotusAuraState {
  mode: string;
  infinityLoopSpeed: number;
  binaryPulse: 'I' | 'O' | string;
}

export interface SomaticTelemetry {
  source: string;
  timestamp: number;
  status: string;
  frequencyHz: number;
  harmonicLock: boolean;
  adrenalNgMl: number;
  thermalCelsius: number;
  gesture: GestureTelemetry;
  pyAudio: PyAudioTelemetry;
  lotusAura: LotusAuraState;
  beastModeActive: boolean;
  cpuLoad: number;
  synapseTempC: number;
}

export interface VisualAsset {
  id: string;
  type: '3D_Hologram' | 'Plasma_Entity' | 'Background_Display' | string;
  resolution?: string;
  frequency?: string;
  rate?: string;
  description: string;
  renderEngine?: string;
  colorHex?: string;
}

export interface AssetManifest {
  manifestId: string;
  stageTheme: string;
  frequencyHz: number;
  visualAssets: VisualAsset[];
  kiwiCommentary?: string;
}

export type Stage3DMode = 'LOTUS_CORE' | 'MOON_GRID' | 'PLASMA_ORB' | 'BINARY_STREAM';

export interface SovereignDirective {
  id: string;
  title: string;
  description: string;
  category: 'Identity' | 'Architecture' | 'Security' | 'Data Integrity' | 'Operational';
  immutable: boolean;
}

export interface AgentProfile {
  id: string;
  name: string;
  role: string;
  status: 'Active' | 'Standby' | 'Overdrive';
  cognitiveLoad: number;
  responsibilities: string[];
  icon: string;
}

export interface FoundationalParams {
  protocolVersion: string;
  baseFrequency: string;
  neuralThreshold: number;
  spinalLatencyMs: number;
  antiXNodeIP: string;
  driftTolerance: number;
}

export interface MemoryLog {
  timestamp: string;
  source: string;
  input: string;
  cortexOutput: string;
  agentsDispatched: string[];
  driftCalculated: number;
  beastModeEtched?: boolean;
}

export interface PresetPathogen {
  id: string;
  title: string;
  description: string;
  input: string;
  category: string;
  difficulty: 'Low' | 'Medium' | 'High' | 'Critical';
}
